# NoteFlow AI — Sprint 4

> **Tasks · Kanban Board · Calendar · Recurring Tasks · Routines**

---

## Version Matrix — All Latest (July 2026)

### Frontend additions to Sprint 3

| Package | Version | Purpose |
|---------|---------|---------|
| @dnd-kit/core | 6.3.1 | Drag-and-drop engine |
| @dnd-kit/sortable | 10.0.0 | Sortable lists/boards |
| @dnd-kit/utilities | 3.2.2 | DnD CSS utilities |
| @dnd-kit/modifiers | 9.0.0 | DnD motion constraints |
| @fullcalendar/react | 6.1.21 | Calendar view |
| @fullcalendar/core | 6.1.21 | FullCalendar core |
| @fullcalendar/daygrid | 6.1.21 | Month grid plugin |
| @fullcalendar/timegrid | 6.1.21 | Week/day time grid |
| @fullcalendar/list | 6.1.21 | Agenda list view |
| @fullcalendar/interaction | 6.1.21 | Click/drag interactions |
| @fullcalendar/rrule | 6.1.21 | Recurrence rendering |
| rrule | 2.8.1 | RRULE utilities |
| @radix-ui/react-checkbox | 1.3.6 | Subtask checkboxes |
| @radix-ui/react-collapsible | 1.1.15 | Collapsible sections |
| @radix-ui/react-alert-dialog | 1.1.18 | Delete confirmations |
| @radix-ui/react-radio-group | 1.4.2 | Priority selection |
| dayjs | 1.11.21 | Date formatting |

### Backend additions to Sprint 3

| Package | Version | Purpose |
|---------|---------|---------|
| ical4j | 4.0.8 | RRULE parsing + expansion |

---

## Sprint 4 — What's New

### Tasks CRUD
- Full task model: title, description, priority (HIGH/MEDIUM/LOW), status lifecycle, due date, reminder, color, estimated/actual time, tags, linked note
- Subtasks with progress bar and individual toggle
- Soft delete
- Sort order with drag-and-drop reorder endpoint
- Activity logging on TASK_CREATED and TASK_COMPLETED

### Kanban Board (dnd-kit 6.3.1 + 10.0.0)
- Three columns: To Do, In Progress, Done
- Drag cards between columns (status auto-updates via PATCH)
- Drag within column (sort order persisted via POST /tasks/reorder)
- DragOverlay for smooth visual feedback
- Per-column task count and quick-add button

### List View
- Full task list with status filter dropdown
- TaskCard shows priority badge, due date (overdue in red, today in amber), recurring indicator, linked note badge
- Direct complete toggle without opening modal

### Calendar View (FullCalendar 6.1.21)
- Month grid / Week time grid / Agenda list — toggle in toolbar
- Tasks rendered as events coloured by status (violet=TODO, blue=IN_PROGRESS, green=DONE)
- Border colour by priority (red=HIGH, amber=MEDIUM, blue=LOW)
- Recurring tasks rendered using FullCalendar rrule plugin
- Click event → opens edit modal; click date → opens create modal

### Recurring Tasks (ical4j 4.0.8)
- RRULE string stored per task (iCal format)
- RecurrenceService expands RRULEs into concrete occurrence dates within any window
- RRULE presets in UI: Daily, Weekdays, Weekly, Bi-weekly, Monthly, Custom
- Calendar endpoint returns expanded instances in the requested window
- RecurrenceService.describe() converts RRULE to human-readable text

### Routines
- Named recurring schedules with emoji, color, days-of-week, start time
- RoutineManager panel in Tasks sidebar: create/delete
- Routines linked to tasks via routine_id FK

### Task Modal
- Full form: title, description, priority toggle, due datetime, estimated time, recurring switch with RRULE preset, subtask builder, tag input
- Inline subtask add/remove before save
- Edit mode pre-fills all fields

---

## New API Endpoints (Sprint 4)

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/v1/tasks | List tasks (optional ?status=, ?page=, ?size=) |
| GET | /api/v1/tasks/calendar?from=&to= | Calendar range with recurrence expansion |
| GET | /api/v1/tasks/{id} | Single task |
| POST | /api/v1/tasks | Create task |
| PUT | /api/v1/tasks/{id} | Update task |
| PATCH | /api/v1/tasks/{id}/status | Quick status update |
| DELETE | /api/v1/tasks/{id} | Soft delete |
| POST | /api/v1/tasks/{id}/subtasks/{sid}/toggle | Toggle subtask |
| POST | /api/v1/tasks/reorder | Drag-and-drop reorder |
| GET | /api/v1/routines | List routines |
| POST | /api/v1/routines | Create routine |
| PUT | /api/v1/routines/{id} | Update routine |
| DELETE | /api/v1/routines/{id} | Delete routine |

---

## Setup Delta from Sprint 3

No new environment variables. Flyway V4 runs automatically on startup.

---

## Upcoming Sprints

Sprint 5 - Interview Q&A extraction, voice practice sessions
Sprint 6 - Activity heatmap, streaks, settings, deploy
