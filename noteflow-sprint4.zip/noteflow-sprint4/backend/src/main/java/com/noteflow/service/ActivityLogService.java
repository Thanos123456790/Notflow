package com.noteflow.service;

import com.noteflow.entity.ActivityLog;
import com.noteflow.entity.User;
import com.noteflow.repository.ActivityLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class ActivityLogService {

    private final ActivityLogRepository activityLogRepository;

    /**
     * Record an activity event asynchronously so it doesn't block request processing.
     */
    @Async
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(User user, String activityType, UUID entityId) {
        try {
            LocalDate today = LocalDate.now(ZoneId.of(user.getTimezone() != null ? user.getTimezone() : "UTC"));
            ActivityLog log = ActivityLog.builder()
                    .user(user)
                    .activityType(activityType)
                    .entityId(entityId)
                    .activityDate(today)
                    .build();
            activityLogRepository.save(log);
        } catch (Exception e) {
            log.error("Failed to record activity for userId={}: {}", user.getId(), e.getMessage());
        }
    }

    @Transactional(readOnly = true)
    public int calculateCurrentStreak(User user) {
        LocalDate today = LocalDate.now(ZoneId.of(user.getTimezone() != null ? user.getTimezone() : "UTC"));
        List<LocalDate> activeDates = activityLogRepository.findDistinctActiveDates(user, today.minusDays(365));

        if (activeDates.isEmpty()) return 0;

        int streak = 0;
        LocalDate expected = today;

        for (LocalDate date : activeDates) {
            if (date.equals(expected) || date.equals(expected.minusDays(1))) {
                streak++;
                expected = date.minusDays(1);
            } else {
                break;
            }
        }

        return streak;
    }
}
