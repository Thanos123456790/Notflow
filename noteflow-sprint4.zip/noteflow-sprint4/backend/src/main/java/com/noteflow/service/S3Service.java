package com.noteflow.service;

import com.noteflow.dto.NoteDto;
import com.noteflow.entity.Note;
import com.noteflow.entity.NoteAttachment;
import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.NoteAttachmentRepository;
import com.noteflow.repository.NoteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import software.amazon.awssdk.services.s3.presigner.S3Presigner;
import software.amazon.awssdk.services.s3.presigner.model.PresignedPutObjectRequest;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;

import java.time.Duration;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class S3Service {

    private final S3Presigner s3Presigner;
    private final NoteRepository noteRepository;
    private final NoteAttachmentRepository attachmentRepository;

    @Value("${aws.s3.bucket-name}")
    private String bucketName;

    @Value("${aws.s3.cloudfront-domain}")
    private String cloudfrontDomain;

    @Value("${aws.s3.presign-ttl-minutes:15}")
    private int presignTtlMinutes;

    /**
     * Generate a pre-signed S3 PUT URL and create a PENDING attachment record.
     */
    @Transactional
    public NoteDto.PresignResponse generateUploadUrl(User user, NoteDto.PresignRequest req) {
        Note note = noteRepository.findByIdAndUserAndIsDeletedFalse(req.getNoteId(), user)
                .orElseThrow(() -> new ResourceNotFoundException("Note not found: " + req.getNoteId()));

        // Build S3 key
        String ext = extractExtension(req.getFilename());
        String fileKey = String.format("users/%s/notes/%s/attachments/%s%s",
                user.getClerkUserId(),
                note.getId(),
                UUID.randomUUID(),
                ext.isEmpty() ? "" : "." + ext);

        // Generate pre-signed URL
        PutObjectRequest putRequest = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(fileKey)
                .contentType(req.getContentType())
                .build();

        PresignedPutObjectRequest presigned = s3Presigner.presignPutObject(r ->
                r.putObjectRequest(putRequest)
                        .signatureDuration(Duration.ofMinutes(presignTtlMinutes)));

        String cdnUrl = cloudfrontDomain + "/" + fileKey;

        // Persist PENDING attachment record
        NoteAttachment attachment = NoteAttachment.builder()
                .note(note)
                .fileName(req.getFilename())
                .fileType(req.getContentType())
                .s3Key(fileKey)
                .cdnUrl(cdnUrl)
                .uploadStatus("PENDING")
                .build();
        NoteAttachment saved = attachmentRepository.save(attachment);

        log.info("Generated pre-signed URL for noteId={}, attachmentId={}", note.getId(), saved.getId());

        NoteDto.PresignResponse response = new NoteDto.PresignResponse();
        response.setUploadUrl(presigned.url().toString());
        response.setFileKey(fileKey);
        response.setAttachmentId(saved.getId());
        return response;
    }

    private String extractExtension(String filename) {
        if (filename == null || !filename.contains(".")) return "";
        return filename.substring(filename.lastIndexOf('.') + 1);
    }
}
