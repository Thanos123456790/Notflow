package com.noteflow.ai;

import com.google.genai.Client;
import com.google.genai.types.Content;
import com.google.genai.types.GenerateContentConfig;
import com.google.genai.types.GenerateContentResponse;
import com.google.genai.types.Part;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

/**
 * Gemini provider using Google GenAI Java SDK (google-genai 1.7.0).
 * Model: gemini-3.5-flash (Gemini 2.0 Flash was shut down June 1 2026).
 */
@Component
@Slf4j
public class GeminiProvider implements AiProvider {

    private final Client client;
    private final String model;
    private final ObjectMapper mapper = new ObjectMapper();

    public GeminiProvider(
            @Value("${ai.gemini.api-key}") String apiKey,
            @Value("${ai.gemini.model:gemini-3.5-flash}") String model
    ) {
        this.model = model;
        this.client = Client.builder().apiKey(apiKey).build();
    }

    @Override
    public AiTypes.Provider getProvider() {
        return AiTypes.Provider.GEMINI;
    }

    @Override
    public AiTypes.RefactorResult refactor(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options
    ) {
        String userPrompt = PromptBuilder.buildUserPrompt(noteTitle, noteContent, options);

        GenerateContentConfig config = GenerateContentConfig.builder()
                .systemInstruction(Content.fromParts(Part.fromText(PromptBuilder.SYSTEM_PROMPT)))
                .responseMimeType("application/json")
                .temperature(0.3f)
                .maxOutputTokens(4096)
                .build();

        GenerateContentResponse response = client.models().generateContent(
                model,
                Content.fromParts(Part.fromText(userPrompt)),
                config
        );

        String raw = response.text();
        int inputTokens  = response.usageMetadata() != null ? response.usageMetadata().promptTokenCount() : 0;
        int outputTokens = response.usageMetadata() != null ? response.usageMetadata().candidatesTokenCount() : 0;

        AiTypes.RefactorResult result = ResultParser.parse(raw);
        result.setInputTokens(inputTokens);
        result.setOutputTokens(outputTokens);
        result.setProviderModel(model);

        log.info("Gemini refactor complete: in={} out={} tokens", inputTokens, outputTokens);
        return result;
    }

    @Override
    public void refactorStream(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options,
            SseEmitter emitter
    ) {
        String userPrompt = PromptBuilder.buildUserPrompt(noteTitle, noteContent, options);

        GenerateContentConfig config = GenerateContentConfig.builder()
                .systemInstruction(Content.fromParts(Part.fromText(PromptBuilder.SYSTEM_PROMPT)))
                .responseMimeType("application/json")
                .temperature(0.3f)
                .maxOutputTokens(4096)
                .build();

        StringBuilder fullResponse = new StringBuilder();

        try {
            var stream = client.models().generateContentStream(
                    model,
                    Content.fromParts(Part.fromText(userPrompt)),
                    config
            );

            for (GenerateContentResponse chunk : stream) {
                String delta = chunk.text();
                if (delta != null && !delta.isEmpty()) {
                    fullResponse.append(delta);
                    AiTypes.StreamChunk sseChunk = AiTypes.StreamChunk.builder()
                            .type(AiTypes.StreamChunk.Type.DELTA)
                            .field("raw")
                            .delta(delta)
                            .build();
                    emitter.send(SseEmitter.event()
                            .name("chunk")
                            .data(mapper.writeValueAsString(sseChunk)));
                }
            }

            // Parse the full accumulated JSON and emit structured DONE event
            AiTypes.RefactorResult result = ResultParser.parse(fullResponse.toString());
            result.setProviderModel(model);
            emitter.send(SseEmitter.event()
                    .name("done")
                    .data(mapper.writeValueAsString(result)));
            emitter.complete();

        } catch (Exception e) {
            log.error("Gemini stream error: {}", e.getMessage(), e);
            try {
                AiTypes.StreamChunk err = AiTypes.StreamChunk.builder()
                        .type(AiTypes.StreamChunk.Type.ERROR)
                        .error(e.getMessage())
                        .build();
                emitter.send(SseEmitter.event().name("error").data(mapper.writeValueAsString(err)));
            } catch (Exception ignored) {}
            emitter.completeWithError(e);
        }
    }
}
