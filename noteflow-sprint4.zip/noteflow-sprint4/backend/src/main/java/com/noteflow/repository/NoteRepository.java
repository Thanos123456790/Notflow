package com.noteflow.repository;

import com.noteflow.entity.Note;
import com.noteflow.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface NoteRepository extends JpaRepository<Note, UUID> {

    Page<Note> findByUserAndIsArchivedFalseAndIsDeletedFalseOrderByIsPinnedDescUpdatedAtDesc(
            User user, Pageable pageable);

    Page<Note> findByUserAndFolderIdAndIsDeletedFalseOrderByIsPinnedDescUpdatedAtDesc(
            User user, UUID folderId, Pageable pageable);

    @Query("""
        SELECT n FROM Note n
        WHERE n.user = :user
          AND n.isDeleted = false
          AND EXISTS (
              SELECT 1 FROM n.tags t WHERE t IN :tags
          )
        ORDER BY n.updatedAt DESC
    """)
    Page<Note> findByUserAndTagsContainingAndIsDeletedFalseOrderByUpdatedAtDesc(
            @Param("user") User user,
            @Param("tags") String[] tags,
            Pageable pageable);

    Optional<Note> findByIdAndUserAndIsDeletedFalse(UUID id, User user);

    @Query(value = """
        SELECT n.* FROM notes n
        WHERE n.user_id = :userId
          AND n.is_deleted = false
          AND n.content_vector @@ plainto_tsquery('english', :query)
        ORDER BY ts_rank(n.content_vector, plainto_tsquery('english', :query)) DESC
        LIMIT 20
    """, nativeQuery = true)
    List<Note> fullTextSearch(@Param("userId") UUID userId, @Param("query") String query);

    long countByUserAndIsDeletedFalse(User user);
}
