package com.noteflow.controller;

import com.noteflow.dto.TaskDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.TaskService;
import com.noteflow.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/tasks")
@RequiredArgsConstructor
public class TaskController {

    private final TaskService taskService;
    private final UserService userService;
    private final SecurityUtils securityUtils;

    /** List tasks with optional status filter and pagination */
    @GetMapping
    public ResponseEntity<TaskDto.PageResponse> listTasks(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "50") int size
    ) {
        return ResponseEntity.ok(taskService.listTasks(currentUser(), status, page, size));
    }

    /** Calendar range query — returns tasks + expanded recurrence instances */
    @GetMapping("/calendar")
    public ResponseEntity<List<TaskDto.Response>> calendarTasks(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to
    ) {
        return ResponseEntity.ok(taskService.listForCalendar(currentUser(), from, to));
    }

    @GetMapping("/{id}")
    public ResponseEntity<TaskDto.Response> getTask(@PathVariable UUID id) {
        return ResponseEntity.ok(taskService.getTask(currentUser(), id));
    }

    @PostMapping
    public ResponseEntity<TaskDto.Response> createTask(@Valid @RequestBody TaskDto.CreateRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(taskService.createTask(currentUser(), req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<TaskDto.Response> updateTask(
            @PathVariable UUID id,
            @Valid @RequestBody TaskDto.UpdateRequest req
    ) {
        return ResponseEntity.ok(taskService.updateTask(currentUser(), id, req));
    }

    /** Quick-complete: PATCH /tasks/{id}/status */
    @PatchMapping("/{id}/status")
    public ResponseEntity<TaskDto.Response> updateStatus(
            @PathVariable UUID id,
            @RequestBody java.util.Map<String, String> body
    ) {
        TaskDto.UpdateRequest req = new TaskDto.UpdateRequest();
        req.setStatus(body.get("status"));
        return ResponseEntity.ok(taskService.updateTask(currentUser(), id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTask(@PathVariable UUID id) {
        taskService.deleteTask(currentUser(), id);
        return ResponseEntity.noContent().build();
    }

    /** Toggle a subtask completed/uncompleted */
    @PostMapping("/{id}/subtasks/{subtaskId}/toggle")
    public ResponseEntity<TaskDto.Response> toggleSubtask(
            @PathVariable UUID id,
            @PathVariable UUID subtaskId
    ) {
        return ResponseEntity.ok(taskService.toggleSubtask(currentUser(), id, subtaskId));
    }

    /** Drag-and-drop reorder */
    @PostMapping("/reorder")
    public ResponseEntity<Void> reorderTasks(@RequestBody TaskDto.ReorderRequest req) {
        taskService.reorderTasks(currentUser(), req);
        return ResponseEntity.ok().build();
    }

    private User currentUser() {
        return userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
    }
}
