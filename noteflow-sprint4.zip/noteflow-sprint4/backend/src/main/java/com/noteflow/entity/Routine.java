package com.noteflow.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.time.LocalTime;
import java.util.UUID;

@Entity
@Table(name = "routines")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Routine {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String name;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(name = "start_time")
    private LocalTime startTime;

    @Column(columnDefinition = "TEXT[]", name = "days_of_week")
    private String[] daysOfWeek = new String[]{}; // ["MON","TUE","WED","THU","FRI","SAT","SUN"]

    @Column(name = "is_active")
    private boolean active = true;

    private String color;   // hex color e.g. "#7C3AED"
    private String emoji;   // e.g. "🌅"

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;
}
