package com.noteflow.ai;

import lombok.Data;
import lombok.Builder;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;

import java.util.List;

/**
 * Shared domain types for the AI refactor pipeline.
 */
public final class AiTypes {

    public enum Provider {
        GEMINI,
        OPENAI
    }

    /**
     * Which analysis modes to run. Clients send a subset of these flags.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RefactorOptions {
        private boolean refactor    = true;   // Rewrite the note for clarity
        private boolean keyPoints   = true;   // Bullet-point key takeaways
        private boolean questions   = true;   // Interview / study questions
        private boolean suggestions = true;   // Actionable suggestions
    }

    /**
     * The structured result streamed from the AI.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class RefactorResult {
        private String refactoredContent;   // Improved rewrite of the note
        private List<String> keyPoints;     // Key bullet points
        private List<String> questions;     // Extracted Q&A questions
        private List<String> suggestions;   // Action items / improvement tips
        private int inputTokens;
        private int outputTokens;
        private String providerModel;       // e.g. "gemini-3.5-flash"
    }

    /**
     * A single SSE chunk sent to the frontend during streaming.
     */
    @Data
    @Builder
    @NoArgsConstructor
    @AllArgsConstructor
    public static class StreamChunk {
        public enum Type { DELTA, DONE, ERROR }

        private Type type;
        private String field;   // "refactoredContent" | "keyPoints" | "questions" | "suggestions"
        private String delta;   // The text fragment
        private String error;   // Only set when type=ERROR
    }

    private AiTypes() {}
}
