package com.noteflow.security;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

@Component
public class SecurityUtils {

    /**
     * Returns the Clerk user ID (JWT "sub" claim) for the currently
     * authenticated user, or throws if not authenticated.
     */
    public String getCurrentClerkUserId() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth instanceof JwtAuthenticationToken jwtAuth) {
            return jwtAuth.getName(); // set to jwt.sub in ClerkJwtAuthConverter
        }
        throw new IllegalStateException("No authenticated user in security context");
    }
}
