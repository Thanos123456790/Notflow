package com.noteflow.controller;

import com.noteflow.ai.AiTypes;
import com.noteflow.dto.AiRefactorDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.AiRefactorService;
import com.noteflow.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;
import java.util.UUID;

/**
 * AI Refactor REST + SSE endpoints.
 *
 * POST /api/v1/ai/refactor/stream  → SSE stream of AI-generated refactor
 * GET  /api/v1/ai/jobs             → Job history (all or by noteId)
 * GET  /api/v1/ai/jobs/{id}        → Single job status + result
 */
@RestController
@RequestMapping("/api/v1/ai")
@RequiredArgsConstructor
@Slf4j
public class AiRefactorController {

    private final AiRefactorService aiRefactorService;
    private final UserService userService;
    private final SecurityUtils securityUtils;

    /**
     * SSE streaming endpoint.
     * Client connects and receives a stream of text-event-stream chunks.
     *
     * Expected body:
     * {
     *   "noteId": "uuid",
     *   "provider": "GEMINI" | "OPENAI",   (optional)
     *   "options": {
     *     "refactor": true,
     *     "keyPoints": true,
     *     "questions": true,
     *     "suggestions": true
     *   }
     * }
     */
    @PostMapping(value = "/refactor/stream", produces = MediaType.TEXT_EVENT_STREAM_VALUE)
    public SseEmitter streamRefactor(@RequestBody AiRefactorDto.StreamRequest req) {
        User user = currentUser();
        log.info("AI stream refactor: noteId={}, provider={}, userId={}",
                req.getNoteId(), req.getProvider(), user.getId());

        AiTypes.RefactorOptions options = req.getOptions() != null
                ? req.getOptions()
                : new AiTypes.RefactorOptions(true, true, true, true);

        return aiRefactorService.streamRefactor(user, req.getNoteId(), req.getProvider(), options);
    }

    /**
     * List job history. Pass ?noteId=<uuid> to filter to a specific note.
     */
    @GetMapping("/jobs")
    public ResponseEntity<List<AiRefactorDto.JobResponse>> listJobs(
            @RequestParam(required = false) UUID noteId
    ) {
        return ResponseEntity.ok(aiRefactorService.listJobs(currentUser(), noteId));
    }

    /**
     * Get a single job by ID (poll for status or fetch result).
     */
    @GetMapping("/jobs/{id}")
    public ResponseEntity<AiRefactorDto.JobResponse> getJob(@PathVariable UUID id) {
        return ResponseEntity.ok(aiRefactorService.getJob(currentUser(), id));
    }

    private User currentUser() {
        return userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
    }
}
