package com.noteflow.service;

import com.noteflow.dto.TaskDto;
import com.noteflow.entity.*;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class TaskService {

    private final TaskRepository taskRepository;
    private final SubtaskRepository subtaskRepository;
    private final NoteRepository noteRepository;
    private final RoutineRepository routineRepository;
    private final RecurrenceService recurrenceService;
    private final ActivityLogService activityLogService;

    // ── List ──────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public TaskDto.PageResponse listTasks(User user, String status, int page, int size) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Task> taskPage = (status != null && !status.isBlank())
                ? taskRepository.findByUserAndStatusAndDeletedFalseOrderBySortOrderAsc(user, status.toUpperCase(), pageable)
                : taskRepository.findByUserAndDeletedFalseOrderBySortOrderAscCreatedAtDesc(user, pageable);

        return buildPageResponse(taskPage.getContent(), taskPage.getTotalElements(), page, size);
    }

    @Transactional(readOnly = true)
    public List<TaskDto.Response> listForCalendar(User user, LocalDate from, LocalDate to) {
        Instant fromInstant = from.atStartOfDay(ZoneOffset.UTC).toInstant();
        Instant toInstant   = to.plusDays(1).atStartOfDay(ZoneOffset.UTC).toInstant();

        List<Task> tasks = taskRepository
                .findByUserAndDeletedFalseAndDueDateBetweenOrderByDueDateAsc(user, fromInstant, toInstant);

        // Also expand recurring tasks that have no due_date in range but recur within it
        List<Task> recurring = taskRepository.findByUserAndRecurringTrueAndDeletedFalse(user);
        for (Task t : recurring) {
            if (tasks.contains(t)) continue;
            if (t.getRecurrenceRule() == null) continue;
            LocalDate taskStart = t.getCreatedAt().atZone(ZoneOffset.UTC).toLocalDate();
            List<LocalDate> occurrences = recurrenceService.expand(t.getRecurrenceRule(), taskStart, from, to);
            if (!occurrences.isEmpty()) tasks.add(t);
        }

        return tasks.stream().map(t -> toResponse(t, from, to)).collect(Collectors.toList());
    }

    // ── Get ───────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public TaskDto.Response getTask(User user, UUID taskId) {
        return toResponse(findOrThrow(user, taskId), null, null);
    }

    // ── Create ────────────────────────────────────────────────────

    @Transactional
    public TaskDto.Response createTask(User user, TaskDto.CreateRequest req) {
        Task task = Task.builder()
                .user(user)
                .title(req.getTitle())
                .description(req.getDescription())
                .priority(req.getPriority() != null ? req.getPriority().toUpperCase() : "MEDIUM")
                .status("TODO")
                .dueDate(req.getDueDate())
                .reminderAt(req.getReminderAt())
                .recurring(req.isRecurring())
                .recurrenceRule(req.getRecurrenceRule())
                .tags(req.getTags() != null ? req.getTags().toArray(new String[0]) : new String[]{})
                .estimatedMins(req.getEstimatedMins())
                .color(req.getColor())
                .build();

        if (req.getLinkedNoteId() != null) {
            noteRepository.findById(req.getLinkedNoteId()).ifPresent(task::setLinkedNote);
        }
        if (req.getRoutineId() != null) {
            routineRepository.findById(req.getRoutineId()).ifPresent(task::setRoutine);
        }

        Task saved = taskRepository.save(task);

        // Create subtasks if provided
        if (req.getSubtasks() != null) {
            for (int i = 0; i < req.getSubtasks().size(); i++) {
                TaskDto.SubtaskRequest sr = req.getSubtasks().get(i);
                subtaskRepository.save(Subtask.builder()
                        .task(saved)
                        .title(sr.getTitle())
                        .sortOrder(i)
                        .build());
            }
        }

        activityLogService.record(user, "TASK_CREATED", saved.getId());
        log.info("Created task id={} for userId={}", saved.getId(), user.getId());
        return toResponse(taskRepository.findById(saved.getId()).orElse(saved), null, null);
    }

    // ── Update ────────────────────────────────────────────────────

    @Transactional
    public TaskDto.Response updateTask(User user, UUID taskId, TaskDto.UpdateRequest req) {
        Task task = findOrThrow(user, taskId);

        if (req.getTitle() != null)          task.setTitle(req.getTitle());
        if (req.getDescription() != null)    task.setDescription(req.getDescription());
        if (req.getPriority() != null)       task.setPriority(req.getPriority().toUpperCase());
        if (req.getDueDate() != null)        task.setDueDate(req.getDueDate());
        if (req.getReminderAt() != null)     task.setReminderAt(req.getReminderAt());
        if (req.getRecurring() != null)      task.setRecurring(req.getRecurring());
        if (req.getRecurrenceRule() != null) task.setRecurrenceRule(req.getRecurrenceRule());
        if (req.getTags() != null)           task.setTags(req.getTags().toArray(new String[0]));
        if (req.getEstimatedMins() != null)  task.setEstimatedMins(req.getEstimatedMins());
        if (req.getActualMins() != null)     task.setActualMins(req.getActualMins());
        if (req.getColor() != null)          task.setColor(req.getColor());
        if (req.getSortOrder() != null)      task.setSortOrder(req.getSortOrder());

        if (req.getLinkedNoteId() != null) {
            noteRepository.findById(req.getLinkedNoteId()).ifPresent(task::setLinkedNote);
        }

        // Status transition
        if (req.getStatus() != null) {
            String newStatus = req.getStatus().toUpperCase();
            task.setStatus(newStatus);
            if ("DONE".equals(newStatus) && task.getCompletedAt() == null) {
                task.setCompletedAt(Instant.now());
                activityLogService.record(user, "TASK_COMPLETED", taskId);
            } else if (!"DONE".equals(newStatus)) {
                task.setCompletedAt(null);
            }
        }

        return toResponse(taskRepository.save(task), null, null);
    }

    // ── Delete ────────────────────────────────────────────────────

    @Transactional
    public void deleteTask(User user, UUID taskId) {
        Task task = findOrThrow(user, taskId);
        task.setDeleted(true);
        taskRepository.save(task);
    }

    // ── Subtask toggle ────────────────────────────────────────────

    @Transactional
    public TaskDto.Response toggleSubtask(User user, UUID taskId, UUID subtaskId) {
        findOrThrow(user, taskId);
        Subtask sub = subtaskRepository.findByIdAndTaskId(subtaskId, taskId)
                .orElseThrow(() -> new ResourceNotFoundException("Subtask not found: " + subtaskId));
        sub.setCompleted(!sub.isCompleted());
        subtaskRepository.save(sub);
        return toResponse(findOrThrow(user, taskId), null, null);
    }

    // ── Reorder ───────────────────────────────────────────────────

    @Transactional
    public void reorderTasks(User user, TaskDto.ReorderRequest req) {
        List<UUID> ids = req.getOrderedIds();
        for (int i = 0; i < ids.size(); i++) {
            taskRepository.updateSortOrder(ids.get(i), user, i);
        }
    }

    // ── Helpers ───────────────────────────────────────────────────

    private Task findOrThrow(User user, UUID taskId) {
        return taskRepository.findByIdAndUserAndDeletedFalse(taskId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Task not found: " + taskId));
    }

    private TaskDto.PageResponse buildPageResponse(List<Task> tasks, long total, int page, int size) {
        TaskDto.PageResponse r = new TaskDto.PageResponse();
        r.setTasks(tasks.stream().map(t -> toResponse(t, null, null)).collect(Collectors.toList()));
        r.setTotal(total);
        r.setPage(page);
        r.setPageSize(size);
        return r;
    }

    public TaskDto.Response toResponse(Task task, LocalDate windowFrom, LocalDate windowTo) {
        TaskDto.Response r = new TaskDto.Response();
        r.setId(task.getId());
        r.setUserId(task.getUser().getId());
        r.setTitle(task.getTitle());
        r.setDescription(task.getDescription());
        r.setPriority(task.getPriority());
        r.setStatus(task.getStatus());
        r.setDueDate(task.getDueDate());
        r.setReminderAt(task.getReminderAt());
        r.setRecurring(task.isRecurring());
        r.setRecurrenceRule(task.getRecurrenceRule());
        r.setTags(task.getTags() != null ? Arrays.asList(task.getTags()) : List.of());
        r.setSortOrder(task.getSortOrder());
        r.setEstimatedMins(task.getEstimatedMins());
        r.setActualMins(task.getActualMins());
        r.setColor(task.getColor());
        r.setCompletedAt(task.getCompletedAt());
        r.setCreatedAt(task.getCreatedAt());
        r.setUpdatedAt(task.getUpdatedAt());

        if (task.getLinkedNote() != null) r.setLinkedNoteId(task.getLinkedNote().getId());
        if (task.getRoutine() != null)    r.setRoutineId(task.getRoutine().getId());

        if (task.getSubtasks() != null) {
            r.setSubtasks(task.getSubtasks().stream().map(s -> {
                TaskDto.SubtaskResponse sr = new TaskDto.SubtaskResponse();
                sr.setId(s.getId());
                sr.setTitle(s.getTitle());
                sr.setCompleted(s.isCompleted());
                sr.setSortOrder(s.getSortOrder());
                return sr;
            }).collect(Collectors.toList()));
        }

        // Expand recurrence for calendar window
        if (task.isRecurring() && task.getRecurrenceRule() != null && windowFrom != null && windowTo != null) {
            LocalDate start = task.getCreatedAt().atZone(ZoneOffset.UTC).toLocalDate();
            List<LocalDate> occurrences = recurrenceService.expand(task.getRecurrenceRule(), start, windowFrom, windowTo);
            r.setRecurrenceInstances(occurrences.stream().map(d -> {
                TaskDto.RecurrenceInstance ri = new TaskDto.RecurrenceInstance();
                ri.setInstanceDate(d.format(DateTimeFormatter.ISO_LOCAL_DATE));
                ri.setCompleted("DONE".equals(task.getStatus()));
                return ri;
            }).collect(Collectors.toList()));
        }

        return r;
    }
}
