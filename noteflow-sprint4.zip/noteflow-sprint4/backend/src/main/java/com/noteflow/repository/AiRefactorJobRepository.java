package com.noteflow.repository;

import com.noteflow.entity.AiRefactorJob;
import com.noteflow.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface AiRefactorJobRepository extends JpaRepository<AiRefactorJob, UUID> {

    List<AiRefactorJob> findByUserOrderByCreatedAtDesc(User user);

    List<AiRefactorJob> findByUserAndNoteIdOrderByCreatedAtDesc(User user, UUID noteId);

    Optional<AiRefactorJob> findByIdAndUser(UUID id, User user);
}
