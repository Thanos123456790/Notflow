package com.noteflow.service;

import com.noteflow.dto.NoteDto;
import com.noteflow.entity.Folder;
import com.noteflow.entity.Note;
import com.noteflow.entity.NoteAttachment;
import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.FolderRepository;
import com.noteflow.repository.NoteAttachmentRepository;
import com.noteflow.repository.NoteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class NoteService {

    private final NoteRepository noteRepository;
    private final NoteAttachmentRepository attachmentRepository;
    private final FolderRepository folderRepository;
    private final ActivityLogService activityLogService;

    // ── List / Search ─────────────────────────────────────────────

    @Transactional(readOnly = true)
    public NoteDto.PageResponse listNotes(User user, String search, UUID folderId, List<String> tags, int page, int size) {
        // Full-text search takes priority
        if (search != null && !search.isBlank()) {
            List<Note> results = noteRepository.fullTextSearch(user.getId(), search.trim());
            return toPageResponse(results, results.size(), page, size);
        }

        Pageable pageable = PageRequest.of(page, size);
        Page<Note> notePage;

        if (folderId != null) {
            notePage = noteRepository.findByUserAndFolderIdAndIsDeletedFalseOrderByIsPinnedDescUpdatedAtDesc(user, folderId, pageable);
        } else if (!tags.isEmpty()) {
            notePage = noteRepository.findByUserAndTagsContainingAndIsDeletedFalseOrderByUpdatedAtDesc(user, tags.toArray(new String[0]), pageable);
        } else {
            notePage = noteRepository.findByUserAndIsArchivedFalseAndIsDeletedFalseOrderByIsPinnedDescUpdatedAtDesc(user, pageable);
        }

        return toPageResponse(notePage.getContent(), (int) notePage.getTotalElements(), page, size);
    }

    // ── Get ───────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public NoteDto.Response getNote(User user, UUID noteId) {
        return toResponse(findNoteOrThrow(user, noteId));
    }

    // ── Create ────────────────────────────────────────────────────

    @Transactional
    public NoteDto.Response createNote(User user, NoteDto.CreateRequest req) {
        Folder folder = null;
        if (req.getFolderId() != null) {
            folder = folderRepository.findByIdAndUser(req.getFolderId(), user)
                    .orElseThrow(() -> new ResourceNotFoundException("Folder not found: " + req.getFolderId()));
        }

        Note note = Note.builder()
                .user(user)
                .folder(folder)
                .title(req.getTitle() != null ? req.getTitle() : "Untitled Note")
                .content(req.getContent())
                .contentText(req.getContentText())
                .tags(req.getTags() != null ? req.getTags().toArray(new String[0]) : new String[]{})
                .build();

        Note saved = noteRepository.save(note);
        activityLogService.record(user, "NOTE_CREATED", saved.getId());
        log.info("Created note id={} for userId={}", saved.getId(), user.getId());
        return toResponse(saved);
    }

    // ── Update ────────────────────────────────────────────────────

    @Transactional
    public NoteDto.Response updateNote(User user, UUID noteId, NoteDto.UpdateRequest req) {
        Note note = findNoteOrThrow(user, noteId);

        if (req.getTitle() != null)       note.setTitle(req.getTitle());
        if (req.getContent() != null)     note.setContent(req.getContent());
        if (req.getContentText() != null) note.setContentText(req.getContentText());
        if (req.getTags() != null)        note.setTags(req.getTags().toArray(new String[0]));
        if (req.getIsPinned() != null)    note.setPinned(req.getIsPinned());
        if (req.getIsArchived() != null)  note.setArchived(req.getIsArchived());

        if (req.getFolderId() != null) {
            Folder folder = folderRepository.findByIdAndUser(req.getFolderId(), user)
                    .orElseThrow(() -> new ResourceNotFoundException("Folder not found"));
            note.setFolder(folder);
        }

        return toResponse(noteRepository.save(note));
    }

    // ── Soft Delete ───────────────────────────────────────────────

    @Transactional
    public void deleteNote(User user, UUID noteId) {
        Note note = findNoteOrThrow(user, noteId);
        note.setDeleted(true);
        noteRepository.save(note);
    }

    // ── Pin Toggle ────────────────────────────────────────────────

    @Transactional
    public NoteDto.Response togglePin(User user, UUID noteId) {
        Note note = findNoteOrThrow(user, noteId);
        note.setPinned(!note.isPinned());
        return toResponse(noteRepository.save(note));
    }

    // ── Attachment confirm ─────────────────────────────────────────

    @Transactional
    public void confirmAttachment(User user, UUID attachmentId, String fileKey) {
        NoteAttachment attachment = attachmentRepository.findById(attachmentId)
                .orElseThrow(() -> new ResourceNotFoundException("Attachment not found: " + attachmentId));
        if (!attachment.getNote().getUser().getId().equals(user.getId())) {
            throw new ResourceNotFoundException("Attachment not found: " + attachmentId);
        }
        attachment.setUploadStatus("CONFIRMED");
        attachmentRepository.save(attachment);
    }

    // ── Helpers ───────────────────────────────────────────────────

    private Note findNoteOrThrow(User user, UUID noteId) {
        return noteRepository.findByIdAndUserAndIsDeletedFalse(noteId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Note not found: " + noteId));
    }

    private NoteDto.PageResponse toPageResponse(List<Note> notes, long total, int page, int size) {
        NoteDto.PageResponse r = new NoteDto.PageResponse();
        r.setNotes(notes.stream().map(this::toResponse).collect(Collectors.toList()));
        r.setTotal(total);
        r.setPage(page);
        r.setPageSize(size);
        return r;
    }

    public NoteDto.Response toResponse(Note note) {
        NoteDto.Response r = new NoteDto.Response();
        r.setId(note.getId());
        r.setUserId(note.getUser().getId());
        if (note.getFolder() != null) r.setFolderId(note.getFolder().getId());
        r.setTitle(note.getTitle());
        r.setContent(note.getContent());
        r.setContentText(note.getContentText());
        r.setTags(note.getTags() != null ? Arrays.asList(note.getTags()) : List.of());
        r.setPinned(note.isPinned());
        r.setArchived(note.isArchived());
        r.setCreatedAt(note.getCreatedAt());
        r.setUpdatedAt(note.getUpdatedAt());
        if (note.getAttachments() != null) {
            r.setAttachments(note.getAttachments().stream().map(a -> {
                NoteDto.AttachmentResponse ar = new NoteDto.AttachmentResponse();
                ar.setId(a.getId());
                ar.setNoteId(note.getId());
                ar.setFileName(a.getFileName());
                ar.setFileType(a.getFileType());
                ar.setS3Key(a.getS3Key());
                ar.setCdnUrl(a.getCdnUrl());
                ar.setSizeBytes(a.getSizeBytes());
                ar.setUploadStatus(a.getUploadStatus());
                ar.setCreatedAt(a.getCreatedAt());
                return ar;
            }).collect(Collectors.toList()));
        }
        return r;
    }
}
