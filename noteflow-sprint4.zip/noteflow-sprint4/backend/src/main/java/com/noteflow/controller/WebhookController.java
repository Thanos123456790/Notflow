package com.noteflow.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.noteflow.service.UserService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Handles Clerk webhook events.
 *
 * Clerk uses Svix to deliver webhooks with HMAC-SHA256 signatures.
 * We validate: svix-id + svix-timestamp + body → compare with svix-signature.
 *
 * Endpoint: POST /api/v1/webhooks/clerk
 * Security: Permit-all (validated by signature, not JWT)
 */
@RestController
@RequestMapping("/api/v1/webhooks")
@RequiredArgsConstructor
@Slf4j
public class WebhookController {

    private final UserService userService;
    private final ObjectMapper objectMapper;

    @Value("${clerk.webhook-secret:}")
    private String webhookSecret;

    @PostMapping("/clerk")
    public ResponseEntity<String> handleClerkWebhook(
            @RequestHeader("svix-id") String svixId,
            @RequestHeader("svix-timestamp") String svixTimestamp,
            @RequestHeader("svix-signature") String svixSignature,
            @RequestBody String rawBody
    ) {
        // Validate Svix signature
        if (!isValidSignature(svixId, svixTimestamp, rawBody, svixSignature)) {
            log.warn("Clerk webhook signature validation failed");
            return ResponseEntity.status(401).body("Invalid signature");
        }

        try {
            JsonNode payload = objectMapper.readTree(rawBody);
            String eventType = payload.path("type").asText();
            JsonNode data = payload.path("data");

            log.info("Received Clerk webhook: type={}", eventType);

            switch (eventType) {
                case "user.created", "user.updated" -> syncUser(data);
                default -> log.debug("Ignored Clerk webhook type: {}", eventType);
            }

            return ResponseEntity.ok("OK");
        } catch (Exception e) {
            log.error("Error processing Clerk webhook: {}", e.getMessage(), e);
            return ResponseEntity.status(500).body("Internal error");
        }
    }

    private void syncUser(JsonNode data) {
        String clerkUserId = data.path("id").asText();
        String firstName = data.path("first_name").asText("");
        String lastName = data.path("last_name").asText("");
        String fullName = (firstName + " " + lastName).trim();
        String avatarUrl = data.path("image_url").asText(null);

        // Extract primary email
        String email = "unknown@noteflow.app";
        JsonNode emailAddresses = data.path("email_addresses");
        if (emailAddresses.isArray() && !emailAddresses.isEmpty()) {
            email = emailAddresses.get(0).path("email_address").asText(email);
        }

        userService.syncFromClerk(clerkUserId, email, fullName.isEmpty() ? null : fullName, avatarUrl);
    }

    private boolean isValidSignature(String svixId, String svixTimestamp, String body, String svixSignature) {
        if (webhookSecret == null || webhookSecret.isBlank()) {
            log.warn("CLERK_WEBHOOK_SECRET not configured — skipping signature check in dev mode");
            return true; // Allow in dev; must be set in production
        }

        try {
            String toSign = svixId + "." + svixTimestamp + "." + body;
            // Remove "whsec_" prefix from Clerk webhook secret if present
            String secret = webhookSecret.startsWith("whsec_")
                    ? webhookSecret.substring(6)
                    : webhookSecret;
            byte[] keyBytes = Base64.getDecoder().decode(secret);
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(keyBytes, "HmacSHA256"));
            byte[] computed = mac.doFinal(toSign.getBytes(StandardCharsets.UTF_8));
            String computedB64 = Base64.getEncoder().encodeToString(computed);
            String expectedSig = "v1," + computedB64;

            // svixSignature may contain multiple space-separated "v1,..." entries
            for (String sig : svixSignature.split(" ")) {
                if (sig.equals(expectedSig)) return true;
            }
            return false;
        } catch (Exception e) {
            log.error("Signature validation error: {}", e.getMessage());
            return false;
        }
    }
}
