package com.noteflow.controller;

import com.noteflow.dto.RoutineDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.RoutineService;
import com.noteflow.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/routines")
@RequiredArgsConstructor
public class RoutineController {

    private final RoutineService routineService;
    private final UserService userService;
    private final SecurityUtils securityUtils;

    @GetMapping
    public ResponseEntity<List<RoutineDto.Response>> listRoutines() {
        return ResponseEntity.ok(routineService.listRoutines(currentUser()));
    }

    @PostMapping
    public ResponseEntity<RoutineDto.Response> createRoutine(@Valid @RequestBody RoutineDto.CreateRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED).body(routineService.createRoutine(currentUser(), req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<RoutineDto.Response> updateRoutine(
            @PathVariable UUID id,
            @Valid @RequestBody RoutineDto.UpdateRequest req
    ) {
        return ResponseEntity.ok(routineService.updateRoutine(currentUser(), id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRoutine(@PathVariable UUID id) {
        routineService.deleteRoutine(currentUser(), id);
        return ResponseEntity.noContent().build();
    }

    private User currentUser() {
        return userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
    }
}
