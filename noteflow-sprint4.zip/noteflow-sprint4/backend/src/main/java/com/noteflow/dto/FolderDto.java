package com.noteflow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

public class FolderDto {

    @Data
    public static class CreateRequest {
        @NotBlank
        @Size(max = 255)
        private String name;

        @Size(max = 7)
        private String color; // hex color e.g. "#7C3AED"

        private UUID parentFolderId;
    }

    @Data
    public static class UpdateRequest {
        @Size(max = 255)
        private String name;

        @Size(max = 7)
        private String color;
    }

    @Data
    public static class Response {
        private UUID id;
        private UUID userId;
        private String name;
        private String color;
        private UUID parentFolderId;
        private long noteCount;
        private Instant createdAt;
    }
}
