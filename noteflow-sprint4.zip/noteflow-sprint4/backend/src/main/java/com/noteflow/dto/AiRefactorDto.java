package com.noteflow.dto;

import com.noteflow.ai.AiTypes;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class AiRefactorDto {

    @Data
    public static class StreamRequest {
        private UUID noteId;
        private AiTypes.Provider provider;   // GEMINI | OPENAI (optional, falls back to default)
        private AiTypes.RefactorOptions options;
    }

    @Data
    public static class RefactorResultDto {
        private String refactoredContent;
        private List<String> keyPoints;
        private List<String> questions;
        private List<String> suggestions;
    }

    @Data
    public static class JobResponse {
        private UUID id;
        private UUID noteId;
        private String provider;
        private String status;
        private Integer inputTokens;
        private Integer outputTokens;
        private String providerModel;
        private String errorMessage;
        private RefactorResultDto result;
        private Instant createdAt;
        private Instant completedAt;
    }
}
