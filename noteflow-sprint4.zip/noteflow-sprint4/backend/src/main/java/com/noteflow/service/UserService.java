package com.noteflow.service;

import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserService {

    private final UserRepository userRepository;

    /**
     * Looks up a User by their Clerk user ID.
     * Creates a minimal user record if one doesn't exist yet
     * (first-login race condition before webhook fires).
     */
    @Transactional
    public User getOrCreateUser(String clerkUserId) {
        return userRepository.findByClerkUserId(clerkUserId)
                .orElseGet(() -> {
                    log.info("Auto-creating user record for clerkUserId={}", clerkUserId);
                    User user = User.builder()
                            .clerkUserId(clerkUserId)
                            .email("pending@noteflow.app")
                            .timezone("UTC")
                            .build();
                    return userRepository.save(user);
                });
    }

    @Transactional(readOnly = true)
    public User getByClerkUserId(String clerkUserId) {
        return userRepository.findByClerkUserId(clerkUserId)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + clerkUserId));
    }

    /**
     * Called from the Clerk webhook when a new user is created or updated.
     */
    @Transactional
    public User syncFromClerk(String clerkUserId, String email, String fullName, String avatarUrl) {
        Optional<User> existing = userRepository.findByClerkUserId(clerkUserId);

        if (existing.isPresent()) {
            User user = existing.get();
            user.setEmail(email);
            user.setFullName(fullName);
            user.setAvatarUrl(avatarUrl);
            log.info("Updated user from Clerk webhook: clerkUserId={}", clerkUserId);
            return userRepository.save(user);
        } else {
            User user = User.builder()
                    .clerkUserId(clerkUserId)
                    .email(email)
                    .fullName(fullName)
                    .avatarUrl(avatarUrl)
                    .timezone("UTC")
                    .build();
            log.info("Created user from Clerk webhook: clerkUserId={}", clerkUserId);
            return userRepository.save(user);
        }
    }
}
