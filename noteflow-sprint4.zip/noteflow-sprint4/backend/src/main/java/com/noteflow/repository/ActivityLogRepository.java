package com.noteflow.repository;

import com.noteflow.entity.ActivityLog;
import com.noteflow.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

@Repository
public interface ActivityLogRepository extends JpaRepository<ActivityLog, UUID> {

    List<ActivityLog> findByUserAndActivityDateBetweenOrderByActivityDateDesc(
            User user, LocalDate from, LocalDate to);

    @Query("""
        SELECT a.activityDate FROM ActivityLog a
        WHERE a.user = :user
          AND a.activityDate >= :from
        GROUP BY a.activityDate
        ORDER BY a.activityDate DESC
    """)
    List<LocalDate> findDistinctActiveDates(@Param("user") User user, @Param("from") LocalDate from);

    boolean existsByUserAndActivityDate(User user, LocalDate date);
}
