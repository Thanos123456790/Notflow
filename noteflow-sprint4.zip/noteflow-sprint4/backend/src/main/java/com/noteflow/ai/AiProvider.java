package com.noteflow.ai;

import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

/**
 * Common contract for all AI providers.
 * Each provider must support both full (blocking) and streaming (SSE) modes.
 */
public interface AiProvider {

    AiTypes.Provider getProvider();

    /**
     * Blocking call — returns the full refactor result.
     * Used for background jobs and webhook-style triggers.
     */
    AiTypes.RefactorResult refactor(String noteTitle, String noteContent, AiTypes.RefactorOptions options);

    /**
     * Streaming call — writes SSE chunks to the emitter as tokens arrive.
     * The emitter is completed (or errored) by the implementation.
     */
    void refactorStream(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options,
            SseEmitter emitter
    );
}
