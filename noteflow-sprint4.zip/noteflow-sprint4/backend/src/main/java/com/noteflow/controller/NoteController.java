package com.noteflow.controller;

import com.noteflow.dto.NoteDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.FolderService;
import com.noteflow.service.NoteService;
import com.noteflow.service.S3Service;
import com.noteflow.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/notes")
@RequiredArgsConstructor
public class NoteController {

    private final NoteService noteService;
    private final S3Service s3Service;
    private final UserService userService;
    private final FolderService folderService;
    private final SecurityUtils securityUtils;

    @GetMapping
    public ResponseEntity<NoteDto.PageResponse> listNotes(
            @RequestParam(defaultValue = "") String search,
            @RequestParam(required = false) String folderId,
            @RequestParam(required = false) String tags,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size
    ) {
        User user = currentUser();
        UUID folderUuid = folderId != null ? UUID.fromString(folderId) : null;
        List<String> tagList = (tags != null && !tags.isBlank())
                ? List.of(tags.split(","))
                : List.of();
        return ResponseEntity.ok(noteService.listNotes(user, search, folderUuid, tagList, page, size));
    }

    @GetMapping("/search")
    public ResponseEntity<NoteDto.PageResponse> searchNotes(@RequestParam String q) {
        return ResponseEntity.ok(noteService.listNotes(currentUser(), q, null, List.of(), 0, 20));
    }

    /** Returns all distinct tags used by the current user's notes */
    @GetMapping("/tags")
    public ResponseEntity<List<String>> listTags() {
        return ResponseEntity.ok(folderService.listTags(currentUser()));
    }

    @GetMapping("/{id}")
    public ResponseEntity<NoteDto.Response> getNote(@PathVariable UUID id) {
        return ResponseEntity.ok(noteService.getNote(currentUser(), id));
    }

    @PostMapping
    public ResponseEntity<NoteDto.Response> createNote(@Valid @RequestBody NoteDto.CreateRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(noteService.createNote(currentUser(), req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<NoteDto.Response> updateNote(
            @PathVariable UUID id,
            @Valid @RequestBody NoteDto.UpdateRequest req
    ) {
        return ResponseEntity.ok(noteService.updateNote(currentUser(), id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteNote(@PathVariable UUID id) {
        noteService.deleteNote(currentUser(), id);
        return ResponseEntity.noContent().build();
    }

    @PostMapping("/{id}/pin")
    public ResponseEntity<NoteDto.Response> togglePin(@PathVariable UUID id) {
        return ResponseEntity.ok(noteService.togglePin(currentUser(), id));
    }

    @PostMapping("/attachments/presign")
    public ResponseEntity<NoteDto.PresignResponse> presignAttachment(@RequestBody NoteDto.PresignRequest req) {
        return ResponseEntity.ok(s3Service.generateUploadUrl(currentUser(), req));
    }

    @PostMapping("/attachments/confirm")
    public ResponseEntity<Void> confirmAttachment(@RequestBody NoteDto.ConfirmUploadRequest req) {
        noteService.confirmAttachment(currentUser(), req.getAttachmentId(), req.getFileKey());
        return ResponseEntity.ok().build();
    }

    private User currentUser() {
        return userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
    }
}
