package com.noteflow.service;

import lombok.extern.slf4j.Slf4j;
import net.fortuna.ical4j.model.*;
import net.fortuna.ical4j.model.property.RRule;
import net.fortuna.ical4j.transform.recurrence.Frequency;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Expands an iCal RRULE string into concrete occurrence dates
 * within a given window. Uses ical4j 4.0.8.
 *
 * Example RRULE: "FREQ=WEEKLY;BYDAY=MO,WE,FR;COUNT=12"
 */
@Service
@Slf4j
public class RecurrenceService {

    private static final DateTimeFormatter ISO_DATE = DateTimeFormatter.ISO_LOCAL_DATE;
    private static final int MAX_OCCURRENCES = 365; // Safety cap

    /**
     * Expand an RRULE relative to a start date, bounded by a window.
     *
     * @param rruleStr   Raw RRULE string (without "RRULE:" prefix)
     * @param startDate  The DTSTART for the recurrence
     * @param windowFrom Start of the window to include occurrences
     * @param windowTo   End of the window to include occurrences
     * @return List of LocalDate instances within the window
     */
    public List<LocalDate> expand(
            String rruleStr,
            LocalDate startDate,
            LocalDate windowFrom,
            LocalDate windowTo
    ) {
        List<LocalDate> results = new ArrayList<>();

        if (rruleStr == null || rruleStr.isBlank()) return results;

        try {
            // ical4j 4.x uses java.time directly
            String fullRule = rruleStr.startsWith("RRULE:") ? rruleStr : "RRULE:" + rruleStr;
            RRule<LocalDate> rule = new RRule<>(fullRule);

            LocalDate current = startDate.isBefore(windowFrom) ? windowFrom : startDate;
            int count = 0;

            // Use ical4j's recurrence iterator
            var iterator = rule.getRecur().iterator(startDate, LocalDate.MAX);
            while (iterator.hasNext() && count < MAX_OCCURRENCES) {
                LocalDate occurrence = iterator.next();
                if (occurrence.isAfter(windowTo)) break;
                if (!occurrence.isBefore(windowFrom)) {
                    results.add(occurrence);
                    count++;
                }
            }
        } catch (Exception e) {
            log.warn("Failed to expand RRULE '{}': {}", rruleStr, e.getMessage());
        }

        return results;
    }

    /**
     * Build a simple RRULE string from common parameters.
     * Used by the frontend to preview the rule before saving.
     */
    public String buildRRule(String frequency, Integer interval, List<String> byDay, Integer count, LocalDate until) {
        StringBuilder sb = new StringBuilder("FREQ=").append(frequency.toUpperCase());
        if (interval != null && interval > 1) sb.append(";INTERVAL=").append(interval);
        if (byDay != null && !byDay.isEmpty()) sb.append(";BYDAY=").append(String.join(",", byDay));
        if (count != null) sb.append(";COUNT=").append(count);
        if (until != null) sb.append(";UNTIL=").append(until.format(DateTimeFormatter.BASIC_ISO_DATE)).append("T000000Z");
        return sb.toString();
    }

    /**
     * Human-readable description of an RRULE.
     */
    public String describe(String rruleStr) {
        if (rruleStr == null || rruleStr.isBlank()) return "No recurrence";
        try {
            if (rruleStr.contains("FREQ=DAILY")) return "Daily";
            if (rruleStr.contains("FREQ=WEEKLY") && rruleStr.contains("BYDAY=MO,TU,WE,TH,FR")) return "Every weekday";
            if (rruleStr.contains("FREQ=WEEKLY")) {
                String days = rruleStr.replaceAll(".*BYDAY=([^;]+).*", "$1");
                return "Weekly on " + days;
            }
            if (rruleStr.contains("FREQ=MONTHLY")) return "Monthly";
            if (rruleStr.contains("FREQ=YEARLY")) return "Yearly";
        } catch (Exception ignored) {}
        return rruleStr;
    }
}
