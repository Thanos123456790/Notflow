package com.noteflow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.Instant;
import java.time.LocalTime;
import java.util.List;
import java.util.UUID;

public class RoutineDto {

    @Data
    public static class CreateRequest {
        @NotBlank @Size(max = 255)
        private String name;
        private String description;
        private LocalTime startTime;
        private List<String> daysOfWeek; // ["MON","TUE","WED"]
        private String color;
        private String emoji;
    }

    @Data
    public static class UpdateRequest {
        @Size(max = 255)
        private String name;
        private String description;
        private LocalTime startTime;
        private List<String> daysOfWeek;
        private Boolean active;
        private String color;
        private String emoji;
    }

    @Data
    public static class Response {
        private UUID id;
        private UUID userId;
        private String name;
        private String description;
        private LocalTime startTime;
        private List<String> daysOfWeek;
        private boolean active;
        private String color;
        private String emoji;
        private Instant createdAt;
        private Instant updatedAt;
    }
}
