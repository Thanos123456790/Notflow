package com.noteflow.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class NoteDto {

    // ── Request DTOs ──────────────────────────────────────────────

    @Data
    public static class CreateRequest {
        @Size(max = 500)
        private String title = "Untitled Note";
        private String content;       // JSON string
        private String contentText;
        private List<String> tags;
        private UUID folderId;
    }

    @Data
    public static class UpdateRequest {
        @Size(max = 500)
        private String title;
        private String content;
        private String contentText;
        private List<String> tags;
        private UUID folderId;
        private Boolean isPinned;
        private Boolean isArchived;
    }

    @Data
    public static class PresignRequest {
        private UUID noteId;
        private String filename;
        private String contentType;
    }

    @Data
    public static class ConfirmUploadRequest {
        private UUID attachmentId;
        private String fileKey;
    }

    // ── Response DTOs ─────────────────────────────────────────────

    @Data
    public static class Response {
        private UUID id;
        private UUID userId;
        private UUID folderId;
        private String title;
        private String content;
        private String contentText;
        private List<String> tags;
        private boolean isPinned;
        private boolean isArchived;
        private Instant createdAt;
        private Instant updatedAt;
        private List<AttachmentResponse> attachments;
    }

    @Data
    public static class AttachmentResponse {
        private UUID id;
        private UUID noteId;
        private String fileName;
        private String fileType;
        private String s3Key;
        private String cdnUrl;
        private Long sizeBytes;
        private String uploadStatus;
        private Instant createdAt;
    }

    @Data
    public static class PresignResponse {
        private String uploadUrl;
        private String fileKey;
        private UUID attachmentId;
    }

    @Data
    public static class PageResponse {
        private List<Response> notes;
        private long total;
        private int page;
        private int pageSize;
    }
}
