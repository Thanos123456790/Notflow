package com.noteflow.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "note_attachments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class NoteAttachment {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "note_id", nullable = false)
    private Note note;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "file_type", nullable = false)
    private String fileType;

    @Column(name = "s3_key", nullable = false)
    private String s3Key;

    @Column(name = "cdn_url", nullable = false)
    private String cdnUrl;

    @Column(name = "size_bytes")
    private Long sizeBytes;

    @Column(name = "upload_status")
    private String uploadStatus = "PENDING"; // PENDING | CONFIRMED

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();
}
