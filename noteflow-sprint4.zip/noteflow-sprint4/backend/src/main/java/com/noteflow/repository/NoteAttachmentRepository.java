package com.noteflow.repository;

import com.noteflow.entity.NoteAttachment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.UUID;

@Repository
public interface NoteAttachmentRepository extends JpaRepository<NoteAttachment, UUID> {
    List<NoteAttachment> findByNoteId(UUID noteId);
    void deleteByNoteId(UUID noteId);
}
