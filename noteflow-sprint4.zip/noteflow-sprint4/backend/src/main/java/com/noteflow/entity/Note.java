package com.noteflow.entity;

import io.hypersistence.utils.hibernate.type.array.StringArrayType;
import io.hypersistence.utils.hibernate.type.json.JsonBinaryType;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Entity
@Table(name = "notes")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "folder_id")
    private Folder folder;

    @Column(nullable = false)
    private String title = "Untitled Note";

    /**
     * TipTap/Lexical JSON content stored as JSONB.
     * Using String here to avoid heavy JSON type dependency;
     * map to/from Map<String,Object> in service layer.
     */
    @Column(columnDefinition = "jsonb")
    private String content;

    @Column(name = "content_text", columnDefinition = "TEXT")
    private String contentText;

    @Column(columnDefinition = "TEXT[]")
    private String[] tags = new String[]{};

    @Column(name = "is_pinned")
    private boolean isPinned = false;

    @Column(name = "is_archived")
    private boolean isArchived = false;

    @Column(name = "is_deleted")
    private boolean isDeleted = false;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;

    @OneToMany(mappedBy = "note", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<NoteAttachment> attachments;
}
