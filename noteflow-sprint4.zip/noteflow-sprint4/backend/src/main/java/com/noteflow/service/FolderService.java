package com.noteflow.service;

import com.noteflow.dto.FolderDto;
import com.noteflow.entity.Folder;
import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.FolderRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class FolderService {

    private final FolderRepository folderRepository;

    @Transactional(readOnly = true)
    public List<FolderDto.Response> listFolders(User user) {
        return folderRepository.findByUserOrderByNameAsc(user)
                .stream()
                .map(f -> toResponse(f, folderRepository.countNotesByFolderId(f.getId())))
                .collect(Collectors.toList());
    }

    @Transactional
    public FolderDto.Response createFolder(User user, FolderDto.CreateRequest req) {
        Folder parent = null;
        if (req.getParentFolderId() != null) {
            parent = folderRepository.findByIdAndUser(req.getParentFolderId(), user)
                    .orElseThrow(() -> new ResourceNotFoundException("Parent folder not found"));
        }

        Folder folder = Folder.builder()
                .user(user)
                .name(req.getName())
                .color(req.getColor())
                .parentFolder(parent)
                .build();

        Folder saved = folderRepository.save(folder);
        log.info("Created folder id={} for userId={}", saved.getId(), user.getId());
        return toResponse(saved, 0);
    }

    @Transactional
    public FolderDto.Response updateFolder(User user, UUID folderId, FolderDto.UpdateRequest req) {
        Folder folder = folderRepository.findByIdAndUser(folderId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Folder not found: " + folderId));

        if (req.getName() != null) folder.setName(req.getName());
        if (req.getColor() != null) folder.setColor(req.getColor());

        return toResponse(folderRepository.save(folder), folderRepository.countNotesByFolderId(folderId));
    }

    @Transactional
    public void deleteFolder(User user, UUID folderId) {
        Folder folder = folderRepository.findByIdAndUser(folderId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Folder not found: " + folderId));
        folderRepository.delete(folder);
        log.info("Deleted folder id={}", folderId);
    }

    @Transactional(readOnly = true)
    public List<String> listTags(User user) {
        return folderRepository.findAllTagsByUser(user);
    }

    private FolderDto.Response toResponse(Folder f, long noteCount) {
        FolderDto.Response r = new FolderDto.Response();
        r.setId(f.getId());
        r.setUserId(f.getUser().getId());
        r.setName(f.getName());
        r.setColor(f.getColor());
        r.setNoteCount(noteCount);
        if (f.getParentFolder() != null) r.setParentFolderId(f.getParentFolder().getId());
        r.setCreatedAt(f.getCreatedAt());
        return r;
    }
}
