package com.noteflow.repository;

import com.noteflow.entity.Task;
import com.noteflow.entity.User;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface TaskRepository extends JpaRepository<Task, UUID> {

    Page<Task> findByUserAndDeletedFalseOrderBySortOrderAscCreatedAtDesc(User user, Pageable pageable);

    Page<Task> findByUserAndStatusAndDeletedFalseOrderBySortOrderAsc(User user, String status, Pageable pageable);

    List<Task> findByUserAndDeletedFalseAndDueDateBetweenOrderByDueDateAsc(
            User user, Instant from, Instant to);

    List<Task> findByUserAndDeletedFalseAndStatusNotOrderBySortOrderAsc(User user, String status);

    Optional<Task> findByIdAndUserAndDeletedFalse(UUID id, User user);

    long countByUserAndStatusAndDeletedFalse(User user, String status);

    @Query("""
        SELECT t FROM Task t
        WHERE t.user = :user
          AND t.deleted = false
          AND t.status != 'ARCHIVED'
        ORDER BY
          CASE t.priority WHEN 'HIGH' THEN 0 WHEN 'MEDIUM' THEN 1 ELSE 2 END,
          t.dueDate ASC NULLS LAST,
          t.sortOrder ASC
    """)
    List<Task> findAllActiveByPriority(@Param("user") User user);

    @Modifying
    @Query("UPDATE Task t SET t.sortOrder = :order WHERE t.id = :id AND t.user = :user")
    void updateSortOrder(@Param("id") UUID id, @Param("user") User user, @Param("order") int order);

    List<Task> findByUserAndRecurringTrueAndDeletedFalse(User user);
}
