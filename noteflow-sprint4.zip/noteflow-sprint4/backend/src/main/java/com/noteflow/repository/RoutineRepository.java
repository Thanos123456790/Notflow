package com.noteflow.repository;

import com.noteflow.entity.Routine;
import com.noteflow.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface RoutineRepository extends JpaRepository<Routine, UUID> {
    List<Routine> findByUserOrderByNameAsc(User user);
    List<Routine> findByUserAndActiveTrue(User user);
    Optional<Routine> findByIdAndUser(UUID id, User user);
}
