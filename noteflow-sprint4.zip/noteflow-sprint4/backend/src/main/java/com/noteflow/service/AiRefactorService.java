package com.noteflow.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.noteflow.ai.AiProvider;
import com.noteflow.ai.AiTypes;
import com.noteflow.dto.AiRefactorDto;
import com.noteflow.entity.Note;
import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.AiRefactorJobRepository;
import com.noteflow.repository.NoteRepository;
import com.noteflow.entity.AiRefactorJob;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class AiRefactorService {

    private final List<AiProvider> providers;
    private final AiRefactorJobRepository jobRepository;
    private final NoteRepository noteRepository;
    private final ObjectMapper objectMapper;

    @Value("${ai.default-provider:GEMINI}")
    private String defaultProviderName;

    // ── Provider resolution ────────────────────────────────────────

    private AiProvider resolve(AiTypes.Provider requested) {
        AiTypes.Provider target = (requested != null) ? requested
                : AiTypes.Provider.valueOf(defaultProviderName.toUpperCase());
        return providers.stream()
                .filter(p -> p.getProvider() == target)
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("No provider registered for: " + target));
    }

    // ── SSE Streaming (primary path) ──────────────────────────────

    /**
     * Creates a job record, then streams the AI response via SSE.
     * The frontend connects to this endpoint and receives real-time token deltas.
     */
    @Transactional
    public SseEmitter streamRefactor(
            User user,
            UUID noteId,
            AiTypes.Provider provider,
            AiTypes.RefactorOptions options
    ) {
        Note note = noteRepository.findByIdAndUserAndIsDeletedFalse(noteId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Note not found: " + noteId));

        // Create PROCESSING job record
        AiRefactorJob job = AiRefactorJob.builder()
                .note(note)
                .user(user)
                .provider(provider != null ? provider.name() : defaultProviderName.toUpperCase())
                .status("PROCESSING")
                .build();
        AiRefactorJob savedJob = jobRepository.save(job);

        SseEmitter emitter = new SseEmitter(60_000L); // 60s timeout

        // Stream in a separate thread so we don't block the HTTP thread
        AiProvider resolvedProvider = resolve(provider);
        String title   = note.getTitle();
        String content = note.getContentText() != null ? note.getContentText() : "";

        Thread.ofVirtual().start(() -> {
            try {
                resolvedProvider.refactorStream(title, content, options, wrapEmitter(emitter, savedJob.getId()));
            } catch (Exception e) {
                log.error("Stream thread error for jobId={}: {}", savedJob.getId(), e.getMessage());
                emitter.completeWithError(e);
            }
        });

        return emitter;
    }

    /**
     * Wraps the emitter so that on DONE we persist the result to the DB.
     * Uses a delegate pattern to intercept the "done" event.
     */
    private SseEmitter wrapEmitter(SseEmitter raw, UUID jobId) {
        // For simplicity, we return the raw emitter and handle DB persistence
        // from the provider's DONE callback via a post-stream update.
        // The AiRefactorJob is updated asynchronously.
        raw.onCompletion(() -> markJobCompleted(jobId));
        raw.onError(err -> markJobFailed(jobId, err.getMessage()));
        return raw;
    }

    // ── Non-streaming (background job) ────────────────────────────

    @Async
    @Transactional
    public void runBackgroundRefactor(UUID jobId) {
        AiRefactorJob job = jobRepository.findById(jobId)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found: " + jobId));

        job.setStatus("PROCESSING");
        jobRepository.save(job);

        try {
            AiProvider provider = resolve(AiTypes.Provider.valueOf(job.getProvider()));
            AiTypes.RefactorOptions options = new AiTypes.RefactorOptions(true, true, true, true);

            AiTypes.RefactorResult result = provider.refactor(
                    job.getNote().getTitle(),
                    job.getNote().getContentText() != null ? job.getNote().getContentText() : "",
                    options
            );

            job.setStatus("COMPLETED");
            job.setResult(objectMapper.writeValueAsString(result));
            job.setInputTokens(result.getInputTokens());
            job.setOutputTokens(result.getOutputTokens());
            job.setProviderModel(result.getProviderModel());
            job.setCompletedAt(Instant.now());
            jobRepository.save(job);

        } catch (Exception e) {
            log.error("Background refactor failed for jobId={}: {}", jobId, e.getMessage(), e);
            job.setStatus("FAILED");
            job.setErrorMessage(e.getMessage());
            jobRepository.save(job);
        }
    }

    // ── Job history ────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public List<AiRefactorDto.JobResponse> listJobs(User user, UUID noteId) {
        List<AiRefactorJob> jobs = (noteId != null)
                ? jobRepository.findByUserAndNoteIdOrderByCreatedAtDesc(user, noteId)
                : jobRepository.findByUserOrderByCreatedAtDesc(user);
        return jobs.stream().map(this::toJobResponse).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public AiRefactorDto.JobResponse getJob(User user, UUID jobId) {
        AiRefactorJob job = jobRepository.findByIdAndUser(jobId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Job not found: " + jobId));
        return toJobResponse(job);
    }

    // ── Helpers ───────────────────────────────────────────────────

    private void markJobCompleted(UUID jobId) {
        jobRepository.findById(jobId).ifPresent(job -> {
            if ("PROCESSING".equals(job.getStatus())) {
                job.setStatus("COMPLETED");
                job.setCompletedAt(Instant.now());
                jobRepository.save(job);
            }
        });
    }

    private void markJobFailed(UUID jobId, String error) {
        jobRepository.findById(jobId).ifPresent(job -> {
            job.setStatus("FAILED");
            job.setErrorMessage(error);
            jobRepository.save(job);
        });
    }

    private AiRefactorDto.JobResponse toJobResponse(AiRefactorJob job) {
        AiRefactorDto.JobResponse r = new AiRefactorDto.JobResponse();
        r.setId(job.getId());
        r.setNoteId(job.getNote().getId());
        r.setProvider(job.getProvider());
        r.setStatus(job.getStatus());
        r.setInputTokens(job.getInputTokens());
        r.setOutputTokens(job.getOutputTokens());
        r.setProviderModel(job.getProviderModel());
        r.setErrorMessage(job.getErrorMessage());
        r.setCreatedAt(job.getCreatedAt());
        r.setCompletedAt(job.getCompletedAt());

        if (job.getResult() != null) {
            try {
                r.setResult(objectMapper.readValue(job.getResult(), AiRefactorDto.RefactorResultDto.class));
            } catch (Exception e) {
                log.warn("Could not deserialize job result for jobId={}", job.getId());
            }
        }
        return r;
    }
}
