package com.noteflow.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

public class TaskDto {

    // ── Request DTOs ──────────────────────────────────────────────

    @Data
    public static class CreateRequest {
        @NotBlank @Size(max = 500)
        private String title;
        private String description;
        private String priority = "MEDIUM"; // HIGH | MEDIUM | LOW
        private Instant dueDate;
        private Instant reminderAt;
        private boolean recurring = false;
        private String recurrenceRule;
        private UUID linkedNoteId;
        private UUID routineId;
        private List<String> tags;
        private Integer estimatedMins;
        private String color;
        private List<SubtaskRequest> subtasks;
    }

    @Data
    public static class UpdateRequest {
        @Size(max = 500)
        private String title;
        private String description;
        private String priority;
        private String status;
        private Instant dueDate;
        private Instant reminderAt;
        private Boolean recurring;
        private String recurrenceRule;
        private UUID linkedNoteId;
        private List<String> tags;
        private Integer estimatedMins;
        private Integer actualMins;
        private String color;
        private Integer sortOrder;
    }

    @Data
    public static class SubtaskRequest {
        @NotBlank
        private String title;
        private int sortOrder;
    }

    @Data
    public static class ReorderRequest {
        private List<UUID> orderedIds; // Task IDs in new order
    }

    // ── Response DTOs ─────────────────────────────────────────────

    @Data
    public static class Response {
        private UUID id;
        private UUID userId;
        private String title;
        private String description;
        private String priority;
        private String status;
        private Instant dueDate;
        private Instant reminderAt;
        private boolean recurring;
        private String recurrenceRule;
        private UUID linkedNoteId;
        private UUID routineId;
        private List<String> tags;
        private int sortOrder;
        private Integer estimatedMins;
        private Integer actualMins;
        private String color;
        private Instant completedAt;
        private Instant createdAt;
        private Instant updatedAt;
        private List<SubtaskResponse> subtasks;
        // Expanded recurrence instances for calendar (not persisted)
        private List<RecurrenceInstance> recurrenceInstances;
    }

    @Data
    public static class SubtaskResponse {
        private UUID id;
        private String title;
        private boolean completed;
        private int sortOrder;
    }

    @Data
    public static class RecurrenceInstance {
        private String instanceDate; // ISO date string
        private boolean completed;
    }

    @Data
    public static class PageResponse {
        private List<Response> tasks;
        private long total;
        private int page;
        private int pageSize;
    }
}
