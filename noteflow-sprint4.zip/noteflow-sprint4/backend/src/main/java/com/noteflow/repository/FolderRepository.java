package com.noteflow.repository;

import com.noteflow.entity.Folder;
import com.noteflow.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface FolderRepository extends JpaRepository<Folder, UUID> {

    List<Folder> findByUserOrderByNameAsc(User user);

    Optional<Folder> findByIdAndUser(UUID id, User user);

    boolean existsByIdAndUser(UUID id, User user);

    @Query(value = """
        SELECT COUNT(*) FROM notes
        WHERE folder_id = :folderId AND is_deleted = false
    """, nativeQuery = true)
    long countNotesByFolderId(@Param("folderId") UUID folderId);

    @Query("""
        SELECT DISTINCT unnest(n.tags) FROM Note n
        WHERE n.user = :user AND n.isDeleted = false
        ORDER BY 1
    """)
    List<String> findAllTagsByUser(@Param("user") User user);
}
