package com.noteflow.service;

import com.noteflow.dto.RoutineDto;
import com.noteflow.entity.Routine;
import com.noteflow.entity.User;
import com.noteflow.exception.ResourceNotFoundException;
import com.noteflow.repository.RoutineRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class RoutineService {

    private final RoutineRepository routineRepository;

    @Transactional(readOnly = true)
    public List<RoutineDto.Response> listRoutines(User user) {
        return routineRepository.findByUserOrderByNameAsc(user)
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    @Transactional
    public RoutineDto.Response createRoutine(User user, RoutineDto.CreateRequest req) {
        Routine routine = Routine.builder()
                .user(user)
                .name(req.getName())
                .description(req.getDescription())
                .startTime(req.getStartTime())
                .daysOfWeek(req.getDaysOfWeek() != null ? req.getDaysOfWeek().toArray(new String[0]) : new String[]{})
                .color(req.getColor())
                .emoji(req.getEmoji())
                .active(true)
                .build();
        Routine saved = routineRepository.save(routine);
        log.info("Created routine id={} for userId={}", saved.getId(), user.getId());
        return toResponse(saved);
    }

    @Transactional
    public RoutineDto.Response updateRoutine(User user, UUID routineId, RoutineDto.UpdateRequest req) {
        Routine routine = routineRepository.findByIdAndUser(routineId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Routine not found: " + routineId));

        if (req.getName() != null)        routine.setName(req.getName());
        if (req.getDescription() != null) routine.setDescription(req.getDescription());
        if (req.getStartTime() != null)   routine.setStartTime(req.getStartTime());
        if (req.getDaysOfWeek() != null)  routine.setDaysOfWeek(req.getDaysOfWeek().toArray(new String[0]));
        if (req.getActive() != null)      routine.setActive(req.getActive());
        if (req.getColor() != null)       routine.setColor(req.getColor());
        if (req.getEmoji() != null)       routine.setEmoji(req.getEmoji());

        return toResponse(routineRepository.save(routine));
    }

    @Transactional
    public void deleteRoutine(User user, UUID routineId) {
        Routine routine = routineRepository.findByIdAndUser(routineId, user)
                .orElseThrow(() -> new ResourceNotFoundException("Routine not found: " + routineId));
        routineRepository.delete(routine);
    }

    private RoutineDto.Response toResponse(Routine r) {
        RoutineDto.Response res = new RoutineDto.Response();
        res.setId(r.getId());
        res.setUserId(r.getUser().getId());
        res.setName(r.getName());
        res.setDescription(r.getDescription());
        res.setStartTime(r.getStartTime());
        res.setDaysOfWeek(r.getDaysOfWeek() != null ? Arrays.asList(r.getDaysOfWeek()) : List.of());
        res.setActive(r.isActive());
        res.setColor(r.getColor());
        res.setEmoji(r.getEmoji());
        res.setCreatedAt(r.getCreatedAt());
        res.setUpdatedAt(r.getUpdatedAt());
        return res;
    }
}
