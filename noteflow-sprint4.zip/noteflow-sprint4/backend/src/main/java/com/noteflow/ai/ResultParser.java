package com.noteflow.ai;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

/**
 * Parses the JSON returned by any AI provider into a RefactorResult.
 * Handles models that wrap their JSON in markdown code fences.
 */
@Slf4j
public final class ResultParser {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static AiTypes.RefactorResult parse(String raw) {
        String json = stripCodeFences(raw.trim());
        try {
            JsonNode node = MAPPER.readTree(json);
            return AiTypes.RefactorResult.builder()
                    .refactoredContent(text(node, "refactoredContent"))
                    .keyPoints(list(node, "keyPoints"))
                    .questions(list(node, "questions"))
                    .suggestions(list(node, "suggestions"))
                    .build();
        } catch (Exception e) {
            log.warn("Failed to parse AI JSON response: {}. Raw: {}", e.getMessage(), raw.length() > 200 ? raw.substring(0, 200) : raw);
            // Graceful fallback — return the raw text as refactoredContent
            return AiTypes.RefactorResult.builder()
                    .refactoredContent(raw)
                    .build();
        }
    }

    private static String text(JsonNode node, String field) {
        JsonNode n = node.get(field);
        return (n == null || n.isNull()) ? null : n.asText();
    }

    private static List<String> list(JsonNode node, String field) {
        JsonNode n = node.get(field);
        if (n == null || n.isNull() || !n.isArray()) return null;
        List<String> result = new ArrayList<>();
        n.forEach(item -> result.add(item.asText()));
        return result;
    }

    /** Strip ```json ... ``` fences that some models still emit despite instructions. */
    private static String stripCodeFences(String text) {
        if (text.startsWith("```")) {
            int start = text.indexOf('\n') + 1;
            int end = text.lastIndexOf("```");
            if (end > start) return text.substring(start, end).trim();
        }
        return text;
    }

    private ResultParser() {}
}
