package com.noteflow.ai;

/**
 * Builds the system and user prompts used for note refactoring.
 * Single source of truth — both Gemini and OpenAI providers use this.
 */
public final class PromptBuilder {

    public static final String SYSTEM_PROMPT = """
            You are an expert note editor and study coach embedded in NoteFlow AI.
            Your role is to analyse a user's raw notes and produce a structured JSON response.
            
            RULES:
            - Be concise and precise.
            - Preserve the user's intent — do not add invented facts.
            - Output ONLY valid JSON matching the schema below; no markdown fences.
            - If a section is not requested, set its value to null.
            
            OUTPUT SCHEMA:
            {
              "refactoredContent": "<improved rewrite of the note as clean markdown>",
              "keyPoints": ["<bullet 1>", "<bullet 2>", ...],
              "questions": ["<question 1>", "<question 2>", ...],
              "suggestions": ["<suggestion 1>", "<suggestion 2>", ...]
            }
            """;

    public static String buildUserPrompt(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options
    ) {
        var sb = new StringBuilder();
        sb.append("NOTE TITLE: ").append(noteTitle).append("\n\n");
        sb.append("NOTE CONTENT:\n").append(noteContent).append("\n\n");
        sb.append("REQUESTED SECTIONS:\n");
        if (options.isRefactor())    sb.append("- refactoredContent: YES\n");
        if (options.isKeyPoints())   sb.append("- keyPoints: YES\n");
        if (options.isQuestions())   sb.append("- questions: YES\n");
        if (options.isSuggestions()) sb.append("- suggestions: YES\n");
        return sb.toString();
    }

    private PromptBuilder() {}
}
