package com.noteflow.controller;

import com.noteflow.dto.UserDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.ActivityLogService;
import com.noteflow.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;
    private final ActivityLogService activityLogService;
    private final SecurityUtils securityUtils;

    @GetMapping("/profile")
    public ResponseEntity<UserDto.Response> getProfile() {
        User user = userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
        return ResponseEntity.ok(toResponse(user));
    }

    @PutMapping("/profile")
    public ResponseEntity<UserDto.Response> updateProfile(@RequestBody UserDto.UpdateRequest req) {
        User user = userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
        if (req.getFullName() != null) user.setFullName(req.getFullName());
        if (req.getBio() != null) user.setBio(req.getBio());
        if (req.getTimezone() != null) user.setTimezone(req.getTimezone());
        // Save via syncFromClerk or a dedicated update method
        return ResponseEntity.ok(toResponse(user));
    }

    @GetMapping("/profile/stats")
    public ResponseEntity<?> getStats() {
        User user = userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
        int streak = activityLogService.calculateCurrentStreak(user);
        return ResponseEntity.ok(java.util.Map.of(
                "currentStreak", streak,
                "userId", user.getId()
        ));
    }

    private UserDto.Response toResponse(User user) {
        UserDto.Response r = new UserDto.Response();
        r.setId(user.getId());
        r.setClerkUserId(user.getClerkUserId());
        r.setEmail(user.getEmail());
        r.setFullName(user.getFullName());
        r.setAvatarUrl(user.getAvatarUrl());
        r.setBio(user.getBio());
        r.setTimezone(user.getTimezone());
        r.setCreatedAt(user.getCreatedAt());
        return r;
    }
}
