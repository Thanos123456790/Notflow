package com.noteflow.controller;

import com.noteflow.dto.FolderDto;
import com.noteflow.entity.User;
import com.noteflow.security.SecurityUtils;
import com.noteflow.service.FolderService;
import com.noteflow.service.UserService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/api/v1/folders")
@RequiredArgsConstructor
public class FolderController {

    private final FolderService folderService;
    private final UserService userService;
    private final SecurityUtils securityUtils;

    @GetMapping
    public ResponseEntity<List<FolderDto.Response>> listFolders() {
        return ResponseEntity.ok(folderService.listFolders(currentUser()));
    }

    @PostMapping
    public ResponseEntity<FolderDto.Response> createFolder(@Valid @RequestBody FolderDto.CreateRequest req) {
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(folderService.createFolder(currentUser(), req));
    }

    @PutMapping("/{id}")
    public ResponseEntity<FolderDto.Response> updateFolder(
            @PathVariable UUID id,
            @Valid @RequestBody FolderDto.UpdateRequest req
    ) {
        return ResponseEntity.ok(folderService.updateFolder(currentUser(), id, req));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFolder(@PathVariable UUID id) {
        folderService.deleteFolder(currentUser(), id);
        return ResponseEntity.noContent().build();
    }

    private User currentUser() {
        return userService.getOrCreateUser(securityUtils.getCurrentClerkUserId());
    }
}
