package com.noteflow.dto;

import lombok.Data;

import java.time.Instant;
import java.util.UUID;

public class UserDto {

    @Data
    public static class Response {
        private UUID id;
        private String clerkUserId;
        private String email;
        private String fullName;
        private String avatarUrl;
        private String bio;
        private String timezone;
        private Instant createdAt;
    }

    @Data
    public static class UpdateRequest {
        private String fullName;
        private String bio;
        private String timezone;
    }

    /** Payload sent by Clerk webhooks (user.created / user.updated). */
    @Data
    public static class ClerkWebhookPayload {
        private String type;
        private ClerkWebhookData data;

        @Data
        public static class ClerkWebhookData {
            private String id;                      // clerkUserId
            private String[] email_addresses;       // array of objects; we'll parse manually
            private String first_name;
            private String last_name;
            private String image_url;
            // Full deserialization handled in WebhookController via raw JSON
        }
    }
}
