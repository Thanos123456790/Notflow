package com.noteflow.ai;

import com.openai.client.OpenAIClient;
import com.openai.client.okhttp.OpenAIOkHttpClient;
import com.openai.models.chat.completions.ChatCompletion;
import com.openai.models.chat.completions.ChatCompletionChunk;
import com.openai.models.chat.completions.ChatCompletionCreateParams;
import com.openai.models.chat.completions.ChatCompletionMessageParam;
import com.openai.models.chat.completions.ChatCompletionSystemMessageParam;
import com.openai.models.chat.completions.ChatCompletionUserMessageParam;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.mvc.method.annotation.SseEmitter;

import java.util.List;

/**
 * OpenAI provider using official openai-java SDK 2.8.1.
 * Model: gpt-4.1-mini (GPT-4o mini is legacy; gpt-4.1-mini is the current fast/cheap model).
 */
@Component
@Slf4j
public class OpenAiProvider implements AiProvider {

    private final OpenAIClient client;
    private final String model;
    private final ObjectMapper mapper = new ObjectMapper();

    public OpenAiProvider(
            @Value("${ai.openai.api-key}") String apiKey,
            @Value("${ai.openai.model:gpt-4.1-mini}") String model
    ) {
        this.model = model;
        this.client = OpenAIOkHttpClient.builder()
                .apiKey(apiKey)
                .build();
    }

    @Override
    public AiTypes.Provider getProvider() {
        return AiTypes.Provider.OPENAI;
    }

    @Override
    public AiTypes.RefactorResult refactor(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options
    ) {
        String userPrompt = PromptBuilder.buildUserPrompt(noteTitle, noteContent, options);

        ChatCompletionCreateParams params = ChatCompletionCreateParams.builder()
                .model(model)
                .messages(List.of(
                        ChatCompletionMessageParam.ofSystem(
                                ChatCompletionSystemMessageParam.builder()
                                        .content(PromptBuilder.SYSTEM_PROMPT)
                                        .build()
                        ),
                        ChatCompletionMessageParam.ofUser(
                                ChatCompletionUserMessageParam.builder()
                                        .content(userPrompt)
                                        .build()
                        )
                ))
                .responseFormat(ChatCompletionCreateParams.ResponseFormat.JSON_OBJECT)
                .temperature(0.3)
                .maxCompletionTokens(4096)
                .build();

        ChatCompletion completion = client.chat().completions().create(params);

        String raw = completion.choices().get(0).message().content().orElse("");
        int inputTokens  = completion.usage().map(u -> (int) u.promptTokens()).orElse(0);
        int outputTokens = completion.usage().map(u -> (int) u.completionTokens()).orElse(0);

        AiTypes.RefactorResult result = ResultParser.parse(raw);
        result.setInputTokens(inputTokens);
        result.setOutputTokens(outputTokens);
        result.setProviderModel(model);

        log.info("OpenAI refactor complete: in={} out={} tokens", inputTokens, outputTokens);
        return result;
    }

    @Override
    public void refactorStream(
            String noteTitle,
            String noteContent,
            AiTypes.RefactorOptions options,
            SseEmitter emitter
    ) {
        String userPrompt = PromptBuilder.buildUserPrompt(noteTitle, noteContent, options);

        ChatCompletionCreateParams params = ChatCompletionCreateParams.builder()
                .model(model)
                .messages(List.of(
                        ChatCompletionMessageParam.ofSystem(
                                ChatCompletionSystemMessageParam.builder()
                                        .content(PromptBuilder.SYSTEM_PROMPT)
                                        .build()
                        ),
                        ChatCompletionMessageParam.ofUser(
                                ChatCompletionUserMessageParam.builder()
                                        .content(userPrompt)
                                        .build()
                        )
                ))
                .responseFormat(ChatCompletionCreateParams.ResponseFormat.JSON_OBJECT)
                .temperature(0.3)
                .maxCompletionTokens(4096)
                .stream(true)
                .build();

        StringBuilder fullResponse = new StringBuilder();

        try {
            client.chat().completions().createStreaming(params).stream().forEach(chunk -> {
                chunk.choices().stream()
                        .filter(c -> c.delta().content().isPresent())
                        .forEach(c -> {
                            String delta = c.delta().content().get();
                            fullResponse.append(delta);
                            try {
                                AiTypes.StreamChunk sseChunk = AiTypes.StreamChunk.builder()
                                        .type(AiTypes.StreamChunk.Type.DELTA)
                                        .field("raw")
                                        .delta(delta)
                                        .build();
                                emitter.send(SseEmitter.event()
                                        .name("chunk")
                                        .data(mapper.writeValueAsString(sseChunk)));
                            } catch (Exception e) {
                                log.warn("SSE send error during stream: {}", e.getMessage());
                            }
                        });
            });

            AiTypes.RefactorResult result = ResultParser.parse(fullResponse.toString());
            result.setProviderModel(model);
            emitter.send(SseEmitter.event()
                    .name("done")
                    .data(mapper.writeValueAsString(result)));
            emitter.complete();

        } catch (Exception e) {
            log.error("OpenAI stream error: {}", e.getMessage(), e);
            try {
                AiTypes.StreamChunk err = AiTypes.StreamChunk.builder()
                        .type(AiTypes.StreamChunk.Type.ERROR)
                        .error(e.getMessage())
                        .build();
                emitter.send(SseEmitter.event().name("error").data(mapper.writeValueAsString(err)));
            } catch (Exception ignored) {}
            emitter.completeWithError(e);
        }
    }
}
