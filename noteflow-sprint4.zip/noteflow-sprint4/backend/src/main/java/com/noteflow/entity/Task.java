package com.noteflow.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Entity
@Table(name = "tasks")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    private UUID id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(nullable = false)
    private String title;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Column(nullable = false)
    private String priority = "MEDIUM"; // HIGH | MEDIUM | LOW

    @Column(nullable = false)
    private String status = "TODO"; // TODO | IN_PROGRESS | DONE | ARCHIVED

    @Column(name = "due_date")
    private Instant dueDate;

    @Column(name = "reminder_at")
    private Instant reminderAt;

    @Column(name = "is_recurring")
    private boolean recurring = false;

    @Column(name = "recurrence_rule")
    private String recurrenceRule; // iCal RRULE string e.g. FREQ=WEEKLY;BYDAY=MO,WE,FR

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "linked_note_id")
    private Note linkedNote;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "routine_id")
    private Routine routine;

    @Column(columnDefinition = "TEXT[]")
    private String[] tags = new String[]{};

    @Column(name = "sort_order")
    private int sortOrder = 0;

    @Column(name = "estimated_mins")
    private Integer estimatedMins;

    @Column(name = "actual_mins")
    private Integer actualMins;

    private String color;

    @Column(name = "completed_at")
    private Instant completedAt;

    @Column(name = "is_deleted")
    private boolean deleted = false;

    @Column(name = "created_at", updatable = false)
    private Instant createdAt = Instant.now();

    @UpdateTimestamp
    @Column(name = "updated_at")
    private Instant updatedAt;

    @OneToMany(mappedBy = "task", cascade = CascadeType.ALL, orphanRemoval = true)
    @OrderBy("sortOrder ASC")
    private List<Subtask> subtasks;
}
