-- ============================================================
-- V3__ai_refactor_sprint3.sql
-- NoteFlow AI – Sprint 3: AI Refactor job tracking indexes
-- ============================================================

-- Index for fast user-level job history lookup
CREATE INDEX IF NOT EXISTS idx_ai_refactor_jobs_user_id
  ON ai_refactor_jobs (user_id, created_at DESC);

-- Index for polling job status
CREATE INDEX IF NOT EXISTS idx_ai_refactor_jobs_status
  ON ai_refactor_jobs (status, created_at DESC)
  WHERE status IN ('PENDING', 'PROCESSING');

-- Add token usage tracking columns (if not already present from V1)
ALTER TABLE ai_refactor_jobs
  ADD COLUMN IF NOT EXISTS provider_model VARCHAR(100),
  ADD COLUMN IF NOT EXISTS cost_usd DECIMAL(10, 6);
