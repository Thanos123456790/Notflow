-- ============================================================
-- V4__sprint4_tasks_calendar.sql
-- NoteFlow AI – Sprint 4: Tasks, Routines, Calendar indexes
-- ============================================================

-- Add missing columns to tasks if they don't exist
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS sort_order       INT          DEFAULT 0,
  ADD COLUMN IF NOT EXISTS routine_id       UUID         REFERENCES routines (id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS estimated_mins   INT,
  ADD COLUMN IF NOT EXISTS actual_mins      INT,
  ADD COLUMN IF NOT EXISTS reminder_at      TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS color            VARCHAR(7);

-- Index for quick board-style queries (status + sort_order)
CREATE INDEX IF NOT EXISTS idx_tasks_user_status
  ON tasks (user_id, status, sort_order);

-- Index for due-date range queries (calendar view)
CREATE INDEX IF NOT EXISTS idx_tasks_due_range
  ON tasks (user_id, due_date)
  WHERE due_date IS NOT NULL AND is_deleted IS DISTINCT FROM TRUE;

-- Add soft-delete to tasks
ALTER TABLE tasks
  ADD COLUMN IF NOT EXISTS is_deleted BOOLEAN DEFAULT FALSE;

-- Routine task instances junction
CREATE TABLE IF NOT EXISTS routine_task_instances (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    routine_id   UUID NOT NULL REFERENCES routines (id) ON DELETE CASCADE,
    task_id      UUID NOT NULL REFERENCES tasks (id)    ON DELETE CASCADE,
    scheduled_at TIMESTAMPTZ NOT NULL,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE (routine_id, scheduled_at)
);

CREATE INDEX IF NOT EXISTS idx_routine_instances_scheduled
  ON routine_task_instances (routine_id, scheduled_at);

-- Add color + emoji to routines
ALTER TABLE routines
  ADD COLUMN IF NOT EXISTS color       VARCHAR(7),
  ADD COLUMN IF NOT EXISTS emoji       VARCHAR(10),
  ADD COLUMN IF NOT EXISTS description TEXT,
  ADD COLUMN IF NOT EXISTS updated_at  TIMESTAMPTZ DEFAULT NOW();

-- Subtasks cleanup: ensure sort_order exists
ALTER TABLE subtasks
  ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT NOW();
