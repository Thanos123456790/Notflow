-- ============================================================
-- V2__sprint2_enhancements.sql
-- NoteFlow AI – Sprint 2: Folder note counts, tag index
-- ============================================================

-- Add note_count helper function (used by folder list endpoint)
CREATE OR REPLACE FUNCTION folder_note_count(folder_uuid UUID)
RETURNS BIGINT AS $$
  SELECT COUNT(*) FROM notes
  WHERE folder_id = folder_uuid AND is_deleted = FALSE;
$$ LANGUAGE SQL STABLE;

-- Full-text search index on note title alone (for faster title-only search)
CREATE INDEX IF NOT EXISTS idx_notes_title_gin
  ON notes USING GIN (to_tsvector('english', title));

-- Partial index: only active (non-deleted, non-archived) notes per user
CREATE INDEX IF NOT EXISTS idx_notes_active_user
  ON notes (user_id, updated_at DESC)
  WHERE is_deleted = FALSE AND is_archived = FALSE;

-- Ensure updated_at is refreshed on notes updates
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notes_updated_at_trigger
  BEFORE UPDATE ON notes
  FOR EACH ROW
  WHEN (OLD.* IS DISTINCT FROM NEW.*)
  EXECUTE FUNCTION update_updated_at_column();

-- Same trigger for tasks
CREATE TRIGGER tasks_updated_at_trigger
  BEFORE UPDATE ON tasks
  FOR EACH ROW
  WHEN (OLD.* IS DISTINCT FROM NEW.*)
  EXECUTE FUNCTION update_updated_at_column();
