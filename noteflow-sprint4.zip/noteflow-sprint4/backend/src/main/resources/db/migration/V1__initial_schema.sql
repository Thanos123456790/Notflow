-- ============================================================
-- V1__initial_schema.sql
-- NoteFlow AI – Sprint 1 Foundation Schema
-- ============================================================

-- Enable pgcrypto for gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ============================================================
-- USERS (synced from Clerk via webhook)
-- ============================================================
CREATE TABLE users (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    clerk_user_id    VARCHAR(255) UNIQUE NOT NULL,
    email            VARCHAR(255) NOT NULL,
    full_name        VARCHAR(255),
    avatar_url       TEXT,
    bio              TEXT,
    timezone         VARCHAR(100) DEFAULT 'UTC',
    created_at       TIMESTAMPTZ  DEFAULT NOW(),
    updated_at       TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX idx_users_clerk_user_id ON users (clerk_user_id);

-- ============================================================
-- FOLDERS
-- ============================================================
CREATE TABLE folders (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    name             VARCHAR(255) NOT NULL,
    color            VARCHAR(7),
    parent_folder_id UUID REFERENCES folders (id) ON DELETE SET NULL,
    created_at       TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_folders_user_id ON folders (user_id);

-- ============================================================
-- NOTES
-- ============================================================
CREATE TABLE notes (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    folder_id        UUID REFERENCES folders (id) ON DELETE SET NULL,
    title            VARCHAR(500) NOT NULL DEFAULT 'Untitled Note',
    content          JSONB,                         -- Rich text JSON (TipTap)
    content_text     TEXT,                          -- Plain text for FTS
    content_vector   TSVECTOR,                     -- Auto-updated FTS vector
    tags             TEXT[]       DEFAULT '{}',
    is_pinned        BOOLEAN      DEFAULT FALSE,
    is_archived      BOOLEAN      DEFAULT FALSE,
    is_deleted       BOOLEAN      DEFAULT FALSE,
    created_at       TIMESTAMPTZ  DEFAULT NOW(),
    updated_at       TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX idx_notes_user_id        ON notes (user_id);
CREATE INDEX idx_notes_content_vector ON notes USING GIN (content_vector);
CREATE INDEX idx_notes_tags           ON notes USING GIN (tags);
CREATE INDEX idx_notes_is_deleted     ON notes (user_id, is_deleted);

-- Auto-update content_vector from content_text
CREATE OR REPLACE FUNCTION notes_content_vector_update() RETURNS TRIGGER AS $$
BEGIN
    NEW.content_vector := to_tsvector('english', COALESCE(NEW.title, '') || ' ' || COALESCE(NEW.content_text, ''));
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER notes_content_vector_trigger
    BEFORE INSERT OR UPDATE OF title, content_text
    ON notes
    FOR EACH ROW EXECUTE FUNCTION notes_content_vector_update();

-- ============================================================
-- NOTE ATTACHMENTS
-- ============================================================
CREATE TABLE note_attachments (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    note_id       UUID NOT NULL REFERENCES notes (id) ON DELETE CASCADE,
    file_name     VARCHAR(500) NOT NULL,
    file_type     VARCHAR(100) NOT NULL,
    s3_key        TEXT         NOT NULL,
    cdn_url       TEXT         NOT NULL,
    size_bytes    BIGINT,
    upload_status VARCHAR(50)  DEFAULT 'PENDING',  -- PENDING | CONFIRMED
    created_at    TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX idx_note_attachments_note_id ON note_attachments (note_id);

-- ============================================================
-- AI REFACTOR JOBS
-- ============================================================
CREATE TABLE ai_refactor_jobs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    note_id       UUID NOT NULL REFERENCES notes (id) ON DELETE CASCADE,
    user_id       UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    provider      VARCHAR(50)  NOT NULL,            -- GEMINI_FLASH | GPT4O_MINI
    status        VARCHAR(50)  DEFAULT 'PENDING',   -- PENDING|PROCESSING|COMPLETED|FAILED
    options       JSONB,                            -- { refactor, keyPoints, questions, suggestions }
    result        JSONB,                            -- Full AI response
    input_tokens  INT,
    output_tokens INT,
    error_message TEXT,
    created_at    TIMESTAMPTZ  DEFAULT NOW(),
    completed_at  TIMESTAMPTZ
);

-- ============================================================
-- TASKS
-- ============================================================
CREATE TABLE tasks (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id         UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    title           VARCHAR(500) NOT NULL,
    description     TEXT,
    priority        VARCHAR(20)  DEFAULT 'MEDIUM',  -- HIGH|MEDIUM|LOW
    status          VARCHAR(30)  DEFAULT 'TODO',    -- TODO|IN_PROGRESS|DONE|ARCHIVED
    due_date        TIMESTAMPTZ,
    is_recurring    BOOLEAN      DEFAULT FALSE,
    recurrence_rule VARCHAR(500),                   -- iCal RRULE
    linked_note_id  UUID REFERENCES notes (id) ON DELETE SET NULL,
    tags            TEXT[]       DEFAULT '{}',
    completed_at    TIMESTAMPTZ,
    created_at      TIMESTAMPTZ  DEFAULT NOW(),
    updated_at      TIMESTAMPTZ  DEFAULT NOW()
);

CREATE INDEX idx_tasks_user_id  ON tasks (user_id);
CREATE INDEX idx_tasks_due_date ON tasks (user_id, due_date);

-- ============================================================
-- SUBTASKS
-- ============================================================
CREATE TABLE subtasks (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    task_id      UUID NOT NULL REFERENCES tasks (id) ON DELETE CASCADE,
    title        VARCHAR(500) NOT NULL,
    is_completed BOOLEAN DEFAULT FALSE,
    sort_order   INT     DEFAULT 0
);

-- ============================================================
-- ROUTINES
-- ============================================================
CREATE TABLE routines (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id      UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    name         VARCHAR(255) NOT NULL,
    start_time   TIME,
    days_of_week TEXT[] DEFAULT '{}',
    is_active    BOOLEAN     DEFAULT TRUE,
    created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- QUESTION BANK
-- ============================================================
CREATE TABLE question_bank (
    id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id        UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    source_note_id UUID REFERENCES notes (id) ON DELETE SET NULL,
    source_job_id  UUID REFERENCES ai_refactor_jobs (id) ON DELETE SET NULL,
    question_text  TEXT        NOT NULL,
    difficulty     VARCHAR(20),                     -- easy|medium|hard
    topic_tags     TEXT[]      DEFAULT '{}',
    is_bookmarked  BOOLEAN     DEFAULT FALSE,
    created_at     TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- VOICE SESSIONS
-- ============================================================
CREATE TABLE voice_sessions (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id          UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    mode             VARCHAR(30) NOT NULL,           -- INTERVIEW|ENGLISH
    topic            VARCHAR(255),
    overall_score    DECIMAL(4, 2),
    duration_seconds INT,
    started_at       TIMESTAMPTZ DEFAULT NOW(),
    ended_at         TIMESTAMPTZ
);

CREATE TABLE voice_exchanges (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    session_id      UUID NOT NULL REFERENCES voice_sessions (id) ON DELETE CASCADE,
    question_text   TEXT,
    user_transcript TEXT,
    ai_evaluation   JSONB,
    exchange_order  INT,
    created_at      TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ACTIVITY LOG (streaks & heatmap)
-- ============================================================
CREATE TABLE activity_log (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id       UUID NOT NULL REFERENCES users (id) ON DELETE CASCADE,
    activity_type VARCHAR(50) NOT NULL,             -- NOTE_CREATED|TASK_COMPLETED|etc.
    entity_id     UUID,
    activity_date DATE        NOT NULL,             -- Timezone-adjusted
    created_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_activity_user_date ON activity_log (user_id, activity_date);

-- ============================================================
-- USER SETTINGS
-- ============================================================
CREATE TABLE user_settings (
    user_id              UUID PRIMARY KEY REFERENCES users (id) ON DELETE CASCADE,
    default_ai_provider  VARCHAR(50) DEFAULT 'GEMINI_FLASH',
    theme                VARCHAR(20) DEFAULT 'SYSTEM',
    timezone             VARCHAR(100) DEFAULT 'UTC',
    email_notifications  BOOLEAN     DEFAULT TRUE,
    push_notifications   BOOLEAN     DEFAULT FALSE,
    language             VARCHAR(10) DEFAULT 'en',
    updated_at           TIMESTAMPTZ DEFAULT NOW()
);
