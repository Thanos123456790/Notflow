package com.noteflow.ai;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class ResultParserTest {

    @Test
    void parsesCleanJson() {
        String json = """
            {
              "refactoredContent": "Improved note content here.",
              "keyPoints": ["Point A", "Point B"],
              "questions": ["What is X?"],
              "suggestions": ["Do Y"]
            }
            """;

        AiTypes.RefactorResult result = ResultParser.parse(json);

        assertThat(result.getRefactoredContent()).isEqualTo("Improved note content here.");
        assertThat(result.getKeyPoints()).containsExactly("Point A", "Point B");
        assertThat(result.getQuestions()).containsExactly("What is X?");
        assertThat(result.getSuggestions()).containsExactly("Do Y");
    }

    @Test
    void stripsMarkdownFences() {
        String json = """
            ```json
            {
              "refactoredContent": "Clean content",
              "keyPoints": null,
              "questions": null,
              "suggestions": null
            }
            ```
            """;

        AiTypes.RefactorResult result = ResultParser.parse(json);
        assertThat(result.getRefactoredContent()).isEqualTo("Clean content");
    }

    @Test
    void gracefullyHandlesMalformedJson() {
        String raw = "This is not JSON at all";
        AiTypes.RefactorResult result = ResultParser.parse(raw);
        // Falls back to returning raw as refactoredContent
        assertThat(result.getRefactoredContent()).isEqualTo(raw);
    }

    @Test
    void handlesNullSections() {
        String json = """
            {
              "refactoredContent": "Some content",
              "keyPoints": null,
              "questions": [],
              "suggestions": null
            }
            """;

        AiTypes.RefactorResult result = ResultParser.parse(json);
        assertThat(result.getRefactoredContent()).isEqualTo("Some content");
        assertThat(result.getKeyPoints()).isNull();
        assertThat(result.getQuestions()).isEmpty();
        assertThat(result.getSuggestions()).isNull();
    }
}
