package com.noteflow.ai;

import org.junit.jupiter.api.Test;
import static org.assertj.core.api.Assertions.assertThat;

class PromptBuilderTest {

    @Test
    void includesAllSectionsWhenAllEnabled() {
        AiTypes.RefactorOptions opts = new AiTypes.RefactorOptions(true, true, true, true);
        String prompt = PromptBuilder.buildUserPrompt("My Title", "My content here", opts);

        assertThat(prompt).contains("My Title");
        assertThat(prompt).contains("My content here");
        assertThat(prompt).contains("refactoredContent: YES");
        assertThat(prompt).contains("keyPoints: YES");
        assertThat(prompt).contains("questions: YES");
        assertThat(prompt).contains("suggestions: YES");
    }

    @Test
    void omitsSectionsWhenDisabled() {
        AiTypes.RefactorOptions opts = new AiTypes.RefactorOptions(true, false, false, false);
        String prompt = PromptBuilder.buildUserPrompt("Title", "Content", opts);

        assertThat(prompt).contains("refactoredContent: YES");
        assertThat(prompt).doesNotContain("keyPoints: YES");
        assertThat(prompt).doesNotContain("questions: YES");
        assertThat(prompt).doesNotContain("suggestions: YES");
    }

    @Test
    void systemPromptIsNotEmpty() {
        assertThat(PromptBuilder.SYSTEM_PROMPT).isNotBlank();
        assertThat(PromptBuilder.SYSTEM_PROMPT).contains("JSON");
    }
}
