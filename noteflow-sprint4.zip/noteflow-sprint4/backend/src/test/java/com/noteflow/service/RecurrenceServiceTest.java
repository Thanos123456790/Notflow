package com.noteflow.service;

import org.junit.jupiter.api.Test;
import java.time.LocalDate;
import java.util.List;
import static org.assertj.core.api.Assertions.assertThat;

class RecurrenceServiceTest {

    private final RecurrenceService svc = new RecurrenceService();

    @Test
    void buildDailyRRule() {
        String rule = svc.buildRRule("DAILY", null, null, 7, null);
        assertThat(rule).contains("FREQ=DAILY");
        assertThat(rule).contains("COUNT=7");
    }

    @Test
    void buildWeeklyRRuleWithDays() {
        String rule = svc.buildRRule("WEEKLY", null, List.of("MO", "WE", "FR"), null, null);
        assertThat(rule).contains("FREQ=WEEKLY");
        assertThat(rule).contains("BYDAY=MO,WE,FR");
    }

    @Test
    void buildMonthlyWithInterval() {
        String rule = svc.buildRRule("MONTHLY", 2, null, null, null);
        assertThat(rule).contains("FREQ=MONTHLY");
        assertThat(rule).contains("INTERVAL=2");
    }

    @Test
    void describeDaily() {
        assertThat(svc.describe("FREQ=DAILY")).isEqualTo("Daily");
    }

    @Test
    void describeWeekdays() {
        assertThat(svc.describe("FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR")).isEqualTo("Every weekday");
    }

    @Test
    void describeWeekly() {
        String desc = svc.describe("FREQ=WEEKLY;BYDAY=MO,FR");
        assertThat(desc).contains("Weekly on");
    }

    @Test
    void describeNullReturnsNoRecurrence() {
        assertThat(svc.describe(null)).isEqualTo("No recurrence");
    }
}
