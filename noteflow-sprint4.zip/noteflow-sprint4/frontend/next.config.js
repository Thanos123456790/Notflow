/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: 'cdn.noteflow.app' },
      { protocol: 'https', hostname: 'img.clerk.com' },
    ],
  },
  // Next.js 16 experimental features
  experimental: {
    optimizePackageImports: ['lucide-react', '@tiptap/react'],
  },
};

module.exports = nextConfig;
