export interface Note {
  id: string;
  userId: string;
  folderId?: string | null;
  title: string;
  content?: Record<string, unknown> | null;
  contentText?: string | null;
  tags?: string[];
  isPinned: boolean;
  isArchived: boolean;
  isDeleted: boolean;
  createdAt: string;
  updatedAt: string;
  attachments?: NoteAttachment[];
}

export interface NoteAttachment {
  id: string;
  noteId: string;
  fileName: string;
  fileType: string;
  s3Key: string;
  cdnUrl: string;
  sizeBytes?: number;
  uploadStatus: 'PENDING' | 'CONFIRMED';
  createdAt: string;
}

export interface CreateNoteRequest {
  title?: string;
  content?: Record<string, unknown>;
  contentText?: string;
  tags?: string[];
  folderId?: string;
}

export interface UpdateNoteRequest {
  id: string;
  title?: string;
  content?: Record<string, unknown>;
  contentText?: string;
  tags?: string[];
  folderId?: string;
  isPinned?: boolean;
  isArchived?: boolean;
}

export interface NotesResponse {
  notes: Note[];
  total: number;
  page: number;
  pageSize: number;
}

export interface PresignRequest {
  noteId: string;
  filename: string;
  contentType: string;
}

export interface PresignResponse {
  uploadUrl: string;
  fileKey: string;
  attachmentId: string;
  cdnUrl?: string;
}
