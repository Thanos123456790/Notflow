export interface AppUser {
  id: string;
  clerkUserId: string;
  email: string;
  fullName?: string;
  avatarUrl?: string;
  bio?: string;
  timezone: string;
  createdAt: string;
  updatedAt: string;
}

export interface UserSettings {
  userId: string;
  defaultAiProvider: 'GEMINI_FLASH' | 'GPT4O_MINI';
  theme: 'LIGHT' | 'DARK' | 'SYSTEM';
  timezone: string;
  emailNotifications: boolean;
  pushNotifications: boolean;
  language: string;
  updatedAt: string;
}

export interface UserStats {
  totalNotes: number;
  totalTasks: number;
  totalVoiceSessions: number;
  currentStreak: number;
  longestStreak: number;
  lastActiveDate: string;
}
