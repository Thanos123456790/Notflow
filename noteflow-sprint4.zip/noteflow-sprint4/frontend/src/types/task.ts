export type TaskPriority = 'HIGH' | 'MEDIUM' | 'LOW';
export type TaskStatus = 'TODO' | 'IN_PROGRESS' | 'DONE' | 'ARCHIVED';

export interface Subtask {
  id: string;
  title: string;
  completed: boolean;
  sortOrder: number;
}

export interface RecurrenceInstance {
  instanceDate: string;
  completed: boolean;
}

export interface Task {
  id: string;
  userId: string;
  title: string;
  description?: string;
  priority: TaskPriority;
  status: TaskStatus;
  dueDate?: string;
  reminderAt?: string;
  recurring: boolean;
  recurrenceRule?: string;
  linkedNoteId?: string;
  routineId?: string;
  tags: string[];
  sortOrder: number;
  estimatedMins?: number;
  actualMins?: number;
  color?: string;
  completedAt?: string;
  createdAt: string;
  updatedAt: string;
  subtasks?: Subtask[];
  recurrenceInstances?: RecurrenceInstance[];
}

export interface CreateTaskRequest {
  title: string;
  description?: string;
  priority?: TaskPriority;
  dueDate?: string;
  reminderAt?: string;
  recurring?: boolean;
  recurrenceRule?: string;
  linkedNoteId?: string;
  routineId?: string;
  tags?: string[];
  estimatedMins?: number;
  color?: string;
  subtasks?: { title: string; sortOrder: number }[];
}

export interface UpdateTaskRequest {
  id: string;
  title?: string;
  description?: string;
  priority?: TaskPriority;
  status?: TaskStatus;
  dueDate?: string;
  reminderAt?: string;
  recurring?: boolean;
  recurrenceRule?: string;
  linkedNoteId?: string;
  tags?: string[];
  estimatedMins?: number;
  actualMins?: number;
  color?: string;
  sortOrder?: number;
}

export interface TasksResponse {
  tasks: Task[];
  total: number;
  page: number;
  pageSize: number;
}

export interface Routine {
  id: string;
  userId: string;
  name: string;
  description?: string;
  startTime?: string;
  daysOfWeek: string[];
  active: boolean;
  color?: string;
  emoji?: string;
  createdAt: string;
  updatedAt: string;
}

export interface CreateRoutineRequest {
  name: string;
  description?: string;
  startTime?: string;
  daysOfWeek?: string[];
  color?: string;
  emoji?: string;
}

export const PRIORITY_CONFIG: Record<TaskPriority, { label: string; color: string; bg: string }> = {
  HIGH:   { label: 'High',   color: 'text-red-600',    bg: 'bg-red-50 dark:bg-red-950/30' },
  MEDIUM: { label: 'Medium', color: 'text-amber-600',  bg: 'bg-amber-50 dark:bg-amber-950/30' },
  LOW:    { label: 'Low',    color: 'text-blue-600',   bg: 'bg-blue-50 dark:bg-blue-950/30' },
};

export const STATUS_CONFIG: Record<TaskStatus, { label: string; color: string }> = {
  TODO:        { label: 'To Do',       color: 'text-[var(--color-muted-foreground)]' },
  IN_PROGRESS: { label: 'In Progress', color: 'text-blue-600' },
  DONE:        { label: 'Done',        color: 'text-emerald-600' },
  ARCHIVED:    { label: 'Archived',    color: 'text-[var(--color-muted-foreground)]' },
};
