'use client';

import { useState, useCallback, useRef } from 'react';
import { useAuth } from '@clerk/nextjs';
import { streamRefactor, RefactorResult, RefactorOptions, AiProvider } from '@/lib/aiApi';

export type StreamStatus = 'idle' | 'streaming' | 'done' | 'error';

export interface AiRefactorState {
  status: StreamStatus;
  rawBuffer: string;
  result: RefactorResult | null;
  error: string | null;
  tokenCount: { input: number; output: number } | null;
}

export function useAiRefactor() {
  const { getToken } = useAuth();
  const abortRef = useRef<(() => void) | null>(null);

  const [state, setState] = useState<AiRefactorState>({
    status: 'idle',
    rawBuffer: '',
    result: null,
    error: null,
    tokenCount: null,
  });

  const start = useCallback(
    (noteId: string, provider: AiProvider, options: RefactorOptions) => {
      // Abort any existing stream
      abortRef.current?.();

      setState({ status: 'streaming', rawBuffer: '', result: null, error: null, tokenCount: null });

      const abort = streamRefactor(
        noteId,
        provider,
        options,
        {
          onDelta: (delta) => {
            setState((prev) => ({ ...prev, rawBuffer: prev.rawBuffer + delta }));
          },
          onDone: (result) => {
            setState((prev) => ({
              ...prev,
              status: 'done',
              result,
              tokenCount:
                result.inputTokens != null
                  ? { input: result.inputTokens, output: result.outputTokens ?? 0 }
                  : null,
            }));
          },
          onError: (error) => {
            setState((prev) => ({ ...prev, status: 'error', error }));
          },
        },
        () => getToken()
      );

      abortRef.current = abort;
    },
    [getToken]
  );

  const reset = useCallback(() => {
    abortRef.current?.();
    setState({ status: 'idle', rawBuffer: '', result: null, error: null, tokenCount: null });
  }, []);

  return { ...state, start, reset };
}
