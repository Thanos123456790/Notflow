import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiClient } from '@/lib/apiClient';

export interface Folder {
  id: string;
  name: string;
  color?: string | null;
  parentFolderId?: string | null;
  createdAt: string;
  noteCount?: number;
}

export interface CreateFolderRequest {
  name: string;
  color?: string;
  parentFolderId?: string;
}

const FOLDER_KEYS = {
  all: ['folders'] as const,
  list: () => [...FOLDER_KEYS.all, 'list'] as const,
  tags: () => [...FOLDER_KEYS.all, 'tags'] as const,
};

async function listFolders(): Promise<Folder[]> {
  const { data } = await apiClient.get<Folder[]>('/folders');
  return data;
}

async function listTags(): Promise<string[]> {
  const { data } = await apiClient.get<string[]>('/notes/tags');
  return data;
}

async function createFolder(req: CreateFolderRequest): Promise<Folder> {
  const { data } = await apiClient.post<Folder>('/folders', req);
  return data;
}

async function deleteFolder(id: string): Promise<void> {
  await apiClient.delete(`/folders/${id}`);
}

export function useFolders() {
  const query = useQuery({
    queryKey: FOLDER_KEYS.list(),
    queryFn: listFolders,
    staleTime: 60_000,
  });
  return {
    folders: query.data ?? [],
    isLoading: query.isLoading,
  };
}

export function useTags() {
  const query = useQuery({
    queryKey: FOLDER_KEYS.tags(),
    queryFn: listTags,
    staleTime: 60_000,
  });
  return { tags: query.data ?? [] };
}

export function useCreateFolder() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: createFolder,
    onSuccess: () => qc.invalidateQueries({ queryKey: FOLDER_KEYS.list() }),
  });
  return { createFolder: mutation.mutateAsync, isCreating: mutation.isPending };
}

export function useDeleteFolder() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: deleteFolder,
    onSuccess: () => qc.invalidateQueries({ queryKey: FOLDER_KEYS.list() }),
  });
  return { deleteFolder: mutation.mutateAsync };
}
