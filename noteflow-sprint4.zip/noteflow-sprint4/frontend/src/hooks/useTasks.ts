import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { tasksApi, GetTasksParams } from '@/lib/tasksApi';
import { CreateTaskRequest, UpdateTaskRequest, CreateRoutineRequest } from '@/types/task';

export const TASK_KEYS = {
  all:      ['tasks'] as const,
  lists:    () => [...TASK_KEYS.all, 'list'] as const,
  list:     (p: GetTasksParams) => [...TASK_KEYS.lists(), p] as const,
  calendar: (from: string, to: string) => [...TASK_KEYS.all, 'calendar', from, to] as const,
  detail:   (id: string) => [...TASK_KEYS.all, 'detail', id] as const,
  routines: ['routines'] as const,
};

export function useTasks(params: GetTasksParams = {}) {
  const q = useQuery({
    queryKey: TASK_KEYS.list(params),
    queryFn: () => tasksApi.list(params),
    staleTime: 30_000,
  });
  return {
    tasks:     q.data?.tasks ?? [],
    total:     q.data?.total ?? 0,
    isLoading: q.isLoading,
    refetch:   q.refetch,
  };
}

export function useCalendarTasks(from: string, to: string, enabled = true) {
  const q = useQuery({
    queryKey: TASK_KEYS.calendar(from, to),
    queryFn: () => tasksApi.calendar(from, to),
    enabled,
    staleTime: 30_000,
  });
  return { tasks: q.data ?? [], isLoading: q.isLoading };
}

export function useTask(id: string) {
  const q = useQuery({
    queryKey: TASK_KEYS.detail(id),
    queryFn: () => tasksApi.get(id),
    enabled: !!id,
  });
  return { task: q.data, isLoading: q.isLoading };
}

export function useCreateTask() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (p: CreateTaskRequest) => tasksApi.create(p),
    onSuccess: () => qc.invalidateQueries({ queryKey: TASK_KEYS.lists() }),
  });
  return { createTask: m.mutateAsync, isCreating: m.isPending };
}

export function useUpdateTask() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (p: UpdateTaskRequest) => tasksApi.update(p),
    onSuccess: (t) => {
      qc.setQueryData(TASK_KEYS.detail(t.id), t);
      qc.invalidateQueries({ queryKey: TASK_KEYS.lists() });
      qc.invalidateQueries({ queryKey: TASK_KEYS.all });
    },
  });
  return { updateTask: m.mutateAsync, isUpdating: m.isPending };
}

export function useDeleteTask() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (id: string) => tasksApi.delete(id),
    onSuccess: (_, id) => {
      qc.removeQueries({ queryKey: TASK_KEYS.detail(id) });
      qc.invalidateQueries({ queryKey: TASK_KEYS.lists() });
    },
  });
  return { deleteTask: m.mutateAsync };
}

export function useUpdateTaskStatus() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: ({ id, status }: { id: string; status: string }) => tasksApi.updateStatus(id, status),
    onSuccess: () => qc.invalidateQueries({ queryKey: TASK_KEYS.all }),
  });
  return { updateStatus: m.mutateAsync, isUpdating: m.isPending };
}

export function useToggleSubtask() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: ({ taskId, subtaskId }: { taskId: string; subtaskId: string }) =>
      tasksApi.toggleSubtask(taskId, subtaskId),
    onSuccess: (t) => qc.setQueryData(TASK_KEYS.detail(t.id), t),
  });
  return { toggleSubtask: m.mutateAsync };
}

export function useReorderTasks() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (ids: string[]) => tasksApi.reorder(ids),
    onSuccess: () => qc.invalidateQueries({ queryKey: TASK_KEYS.lists() }),
  });
  return { reorder: m.mutateAsync };
}

// ── Routines ────────────────────────────────────────────────────

export function useRoutines() {
  const q = useQuery({
    queryKey: TASK_KEYS.routines,
    queryFn: tasksApi.listRoutines,
    staleTime: 60_000,
  });
  return { routines: q.data ?? [], isLoading: q.isLoading };
}

export function useCreateRoutine() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (p: CreateRoutineRequest) => tasksApi.createRoutine(p),
    onSuccess: () => qc.invalidateQueries({ queryKey: TASK_KEYS.routines }),
  });
  return { createRoutine: m.mutateAsync, isCreating: m.isPending };
}

export function useDeleteRoutine() {
  const qc = useQueryClient();
  const m = useMutation({
    mutationFn: (id: string) => tasksApi.deleteRoutine(id),
    onSuccess: () => qc.invalidateQueries({ queryKey: TASK_KEYS.routines }),
  });
  return { deleteRoutine: m.mutateAsync };
}
