import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { notesApi, GetNotesParams } from '@/lib/notesApi';
import { CreateNoteRequest, UpdateNoteRequest } from '@/types/note';

export const NOTE_KEYS = {
  all: ['notes'] as const,
  lists: () => [...NOTE_KEYS.all, 'list'] as const,
  list: (params: GetNotesParams) => [...NOTE_KEYS.lists(), params] as const,
  detail: (id: string) => [...NOTE_KEYS.all, 'detail', id] as const,
};

export function useNotes(params: GetNotesParams & { limit?: number } = {}) {
  const query = useQuery({
    queryKey: NOTE_KEYS.list(params),
    queryFn: () => notesApi.list(params),
    staleTime: 30_000,
  });
  return {
    notes: query.data?.notes ?? [],
    total: query.data?.total ?? 0,
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error,
    refetch: query.refetch,
  };
}

export function useNote(id: string) {
  const query = useQuery({
    queryKey: NOTE_KEYS.detail(id),
    queryFn: () => notesApi.get(id),
    enabled: !!id,
    staleTime: 10_000,
  });
  return { note: query.data, isLoading: query.isLoading, isError: query.isError };
}

export function useCreateNote() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: (payload: CreateNoteRequest) => notesApi.create(payload),
    onSuccess: () => qc.invalidateQueries({ queryKey: NOTE_KEYS.lists() }),
  });
  return { createNote: mutation.mutateAsync, isCreating: mutation.isPending, error: mutation.error };
}

export function useUpdateNote() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: (payload: UpdateNoteRequest) => notesApi.update(payload),
    onSuccess: (updated) => {
      qc.setQueryData(NOTE_KEYS.detail(updated.id), updated);
      qc.invalidateQueries({ queryKey: NOTE_KEYS.lists() });
    },
  });
  return { updateNote: mutation.mutateAsync, isUpdating: mutation.isPending };
}

export function useDeleteNote() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: (id: string) => notesApi.delete(id),
    onSuccess: (_data, id) => {
      qc.removeQueries({ queryKey: NOTE_KEYS.detail(id) });
      qc.invalidateQueries({ queryKey: NOTE_KEYS.lists() });
    },
  });
  return { deleteNote: mutation.mutateAsync, isDeleting: mutation.isPending };
}

export function useTogglePin() {
  const qc = useQueryClient();
  const mutation = useMutation({
    mutationFn: (id: string) => notesApi.togglePin(id),
    onSuccess: (updated) => {
      qc.setQueryData(NOTE_KEYS.detail(updated.id), updated);
      qc.invalidateQueries({ queryKey: NOTE_KEYS.lists() });
    },
  });
  return { togglePin: mutation.mutateAsync };
}
