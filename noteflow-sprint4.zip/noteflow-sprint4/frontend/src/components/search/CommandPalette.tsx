'use client';

import { useEffect, useState, useCallback } from 'react';
import { Command } from 'cmdk';
import { useRouter } from 'next/navigation';
import { Search, FileText, Plus, Sparkles, Calendar, Mic, Loader2 } from 'lucide-react';
import { notesApi } from '@/lib/notesApi';
import { Note } from '@/types/note';
import { useCreateNote } from '@/hooks/useNotes';
import { formatDistanceToNow } from 'date-fns';

interface CommandPaletteProps {
  open: boolean;
  onOpenChange: (v: boolean) => void;
}

export function CommandPalette({ open, onOpenChange }: CommandPaletteProps) {
  const router = useRouter();
  const { createNote, isCreating } = useCreateNote();
  const [search, setSearch] = useState('');
  const [results, setResults] = useState<Note[]>([]);
  const [searching, setSearching] = useState(false);

  // Debounced search
  useEffect(() => {
    if (!search.trim()) { setResults([]); return; }
    const t = setTimeout(async () => {
      setSearching(true);
      try {
        const res = await notesApi.list({ search, limit: 8 });
        setResults(res.notes);
      } catch { setResults([]); }
      finally { setSearching(false); }
    }, 250);
    return () => clearTimeout(t);
  }, [search]);

  const handleSelect = useCallback(
    (value: string) => {
      onOpenChange(false);
      setSearch('');
      router.push(value);
    },
    [router, onOpenChange]
  );

  const handleCreateNote = async () => {
    onOpenChange(false);
    const note = await createNote({ title: search.trim() || 'Untitled Note' });
    router.push(`/notes/${note.id}`);
  };

  return (
    <div
      className={`fixed inset-0 z-50 ${open ? 'flex' : 'hidden'} items-start justify-center pt-20`}
    >
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/40 backdrop-blur-sm"
        onClick={() => onOpenChange(false)}
      />

      {/* Palette */}
      <Command
        className="relative z-10 w-full max-w-lg bg-[var(--color-card)] border border-[var(--color-border)] rounded-2xl shadow-2xl overflow-hidden"
        shouldFilter={false}
      >
        <div className="flex items-center gap-2 px-4 py-3 border-b border-[var(--color-border)]">
          {searching ? (
            <Loader2 size={16} className="text-[var(--color-muted-foreground)] animate-spin" />
          ) : (
            <Search size={16} className="text-[var(--color-muted-foreground)]" />
          )}
          <Command.Input
            value={search}
            onValueChange={setSearch}
            placeholder="Search notes, or type a command…"
            className="flex-1 bg-transparent text-sm text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)] outline-none"
          />
          <kbd className="text-xs text-[var(--color-muted-foreground)] border border-[var(--color-border)] rounded px-1.5 py-0.5">ESC</kbd>
        </div>

        <Command.List className="max-h-80 overflow-y-auto p-2">
          {/* Search results */}
          {results.length > 0 && (
            <Command.Group heading={<span className="text-xs text-[var(--color-muted-foreground)] uppercase tracking-wider px-2 py-1">Notes</span>}>
              {results.map((note) => (
                <Command.Item
                  key={note.id}
                  value={`/notes/${note.id}`}
                  onSelect={handleSelect}
                  className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer text-sm text-[var(--color-foreground)] data-[selected]:bg-[var(--color-accent)]"
                >
                  <FileText size={14} className="text-[var(--color-muted-foreground)] flex-shrink-0" />
                  <span className="flex-1 truncate">{note.title || 'Untitled'}</span>
                  <span className="text-xs text-[var(--color-muted-foreground)] flex-shrink-0">
                    {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
                  </span>
                </Command.Item>
              ))}
            </Command.Group>
          )}

          {/* Quick actions */}
          <Command.Group heading={<span className="text-xs text-[var(--color-muted-foreground)] uppercase tracking-wider px-2 py-1">Actions</span>}>
            <Command.Item
              value="new-note"
              onSelect={handleCreateNote}
              className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer text-sm text-[var(--color-foreground)] data-[selected]:bg-[var(--color-accent)]"
            >
              <Plus size={14} className="text-[var(--color-primary)] flex-shrink-0" />
              <span>New Note{search ? ` — "${search}"` : ''}</span>
            </Command.Item>
            <Command.Item
              value="/ai-enhance"
              onSelect={handleSelect}
              className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer text-sm text-[var(--color-foreground)] data-[selected]:bg-[var(--color-accent)]"
            >
              <Sparkles size={14} className="text-violet-500 flex-shrink-0" />
              <span>Go to AI Enhance</span>
            </Command.Item>
            <Command.Item
              value="/tasks"
              onSelect={handleSelect}
              className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer text-sm text-[var(--color-foreground)] data-[selected]:bg-[var(--color-accent)]"
            >
              <Calendar size={14} className="text-blue-500 flex-shrink-0" />
              <span>Go to Tasks</span>
            </Command.Item>
            <Command.Item
              value="/interview"
              onSelect={handleSelect}
              className="flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer text-sm text-[var(--color-foreground)] data-[selected]:bg-[var(--color-accent)]"
            >
              <Mic size={14} className="text-emerald-500 flex-shrink-0" />
              <span>Go to Interview Prep</span>
            </Command.Item>
          </Command.Group>

          <Command.Empty className="py-8 text-center text-sm text-[var(--color-muted-foreground)]">
            No results found.
          </Command.Empty>
        </Command.List>
      </Command>
    </div>
  );
}
