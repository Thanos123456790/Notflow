'use client';

import { Editor } from '@tiptap/react';
import {
  Bold, Italic, Underline as UnderlineIcon, Strikethrough,
  Code, CodeSquare, Heading1, Heading2, Heading3,
  List, ListOrdered, CheckSquare, Quote,
  Link as LinkIcon, Image, Highlighter,
  Minus, Undo, Redo, Type,
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { ImageUploadButton } from '../upload/ImageUploadButton';

interface EditorToolbarProps {
  editor: Editor;
  noteId: string;
  onImageInsert: (url: string) => void;
}

interface ToolbarBtn {
  icon: React.ReactNode;
  action: () => void;
  isActive?: boolean;
  title: string;
  className?: string;
}

export function EditorToolbar({ editor, noteId, onImageInsert }: EditorToolbarProps) {
  const btn = (config: ToolbarBtn) => (
    <button
      key={config.title}
      onMouseDown={(e) => { e.preventDefault(); config.action(); }}
      title={config.title}
      className={cn(
        'p-1.5 rounded-md text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors',
        config.isActive && 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)] hover:bg-[var(--color-primary)] hover:text-[var(--color-primary-foreground)]',
        config.className
      )}
    >
      {config.icon}
    </button>
  );

  const handleLinkToggle = () => {
    if (editor.isActive('link')) {
      editor.chain().focus().unsetLink().run();
    } else {
      const url = window.prompt('Enter URL');
      if (url) editor.chain().focus().setLink({ href: url }).run();
    }
  };

  const groups: ToolbarBtn[][] = [
    // History
    [
      { icon: <Undo size={15} />, action: () => editor.chain().focus().undo().run(), title: 'Undo (⌘Z)', className: !editor.can().undo() ? 'opacity-30' : '' },
      { icon: <Redo size={15} />, action: () => editor.chain().focus().redo().run(), title: 'Redo (⌘⇧Z)', className: !editor.can().redo() ? 'opacity-30' : '' },
    ],
    // Headings
    [
      { icon: <Heading1 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 1 }).run(), isActive: editor.isActive('heading', { level: 1 }), title: 'H1' },
      { icon: <Heading2 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 2 }).run(), isActive: editor.isActive('heading', { level: 2 }), title: 'H2' },
      { icon: <Heading3 size={15} />, action: () => editor.chain().focus().toggleHeading({ level: 3 }).run(), isActive: editor.isActive('heading', { level: 3 }), title: 'H3' },
    ],
    // Marks
    [
      { icon: <Bold size={15} />, action: () => editor.chain().focus().toggleBold().run(), isActive: editor.isActive('bold'), title: 'Bold (⌘B)' },
      { icon: <Italic size={15} />, action: () => editor.chain().focus().toggleItalic().run(), isActive: editor.isActive('italic'), title: 'Italic (⌘I)' },
      { icon: <UnderlineIcon size={15} />, action: () => editor.chain().focus().toggleUnderline().run(), isActive: editor.isActive('underline'), title: 'Underline (⌘U)' },
      { icon: <Strikethrough size={15} />, action: () => editor.chain().focus().toggleStrike().run(), isActive: editor.isActive('strike'), title: 'Strikethrough' },
      { icon: <Highlighter size={15} />, action: () => editor.chain().focus().toggleHighlight().run(), isActive: editor.isActive('highlight'), title: 'Highlight' },
      { icon: <Code size={15} />, action: () => editor.chain().focus().toggleCode().run(), isActive: editor.isActive('code'), title: 'Inline Code (⌘E)' },
    ],
    // Lists
    [
      { icon: <List size={15} />, action: () => editor.chain().focus().toggleBulletList().run(), isActive: editor.isActive('bulletList'), title: 'Bullet List' },
      { icon: <ListOrdered size={15} />, action: () => editor.chain().focus().toggleOrderedList().run(), isActive: editor.isActive('orderedList'), title: 'Ordered List' },
      { icon: <CheckSquare size={15} />, action: () => editor.chain().focus().toggleTaskList().run(), isActive: editor.isActive('taskList'), title: 'Task List' },
      { icon: <Quote size={15} />, action: () => editor.chain().focus().toggleBlockquote().run(), isActive: editor.isActive('blockquote'), title: 'Blockquote' },
      { icon: <CodeSquare size={15} />, action: () => editor.chain().focus().toggleCodeBlock().run(), isActive: editor.isActive('codeBlock'), title: 'Code Block' },
    ],
    // Insert
    [
      { icon: <LinkIcon size={15} />, action: handleLinkToggle, isActive: editor.isActive('link'), title: 'Link (⌘K)' },
      { icon: <Minus size={15} />, action: () => editor.chain().focus().setHorizontalRule().run(), title: 'Divider' },
    ],
  ];

  return (
    <div className="flex flex-wrap items-center gap-0.5 p-1.5 border border-[var(--color-border)] rounded-xl bg-[var(--color-card)] mb-3 sticky top-0 z-10">
      {groups.map((group, gi) => (
        <span key={gi} className="flex items-center gap-0.5">
          {gi > 0 && <span className="w-px h-5 bg-[var(--color-border)] mx-1" />}
          {group.map((b) => btn(b))}
        </span>
      ))}

      {/* Separator before image */}
      <span className="w-px h-5 bg-[var(--color-border)] mx-1" />
      <ImageUploadButton noteId={noteId} onInsert={onImageInsert} />
    </div>
  );
}
