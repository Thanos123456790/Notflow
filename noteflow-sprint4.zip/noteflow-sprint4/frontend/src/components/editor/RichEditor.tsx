'use client';

import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Placeholder from '@tiptap/extension-placeholder';
import Highlight from '@tiptap/extension-highlight';
import TaskList from '@tiptap/extension-task-list';
import TaskItem from '@tiptap/extension-task-item';
import CodeBlockLowlight from '@tiptap/extension-code-block-lowlight';
import ImageExtension from '@tiptap/extension-image';
import Link from '@tiptap/extension-link';
import Typography from '@tiptap/extension-typography';
import CharacterCount from '@tiptap/extension-character-count';
import Underline from '@tiptap/extension-underline';
import Color from '@tiptap/extension-color';
import TextStyle from '@tiptap/extension-text-style';
import { createLowlight } from 'lowlight';
import javascript from 'highlight.js/lib/languages/javascript';
import typescript from 'highlight.js/lib/languages/typescript';
import python from 'highlight.js/lib/languages/python';
import java from 'highlight.js/lib/languages/java';
import { useCallback, useEffect } from 'react';
import { EditorToolbar } from './EditorToolbar';
import { ImageUploadButton } from '../upload/ImageUploadButton';

const lowlight = createLowlight();
lowlight.register('javascript', javascript);
lowlight.register('typescript', typescript);
lowlight.register('python', python);
lowlight.register('java', java);

interface RichEditorProps {
  noteId: string;
  initialContent?: Record<string, unknown> | null;
  initialText?: string | null;
  onUpdate: (content: Record<string, unknown>, text: string) => void;
  placeholder?: string;
}

export function RichEditor({
  noteId,
  initialContent,
  initialText,
  onUpdate,
  placeholder = 'Start writing… (/ for commands)',
}: RichEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        codeBlock: false, // replaced by CodeBlockLowlight
      }),
      Placeholder.configure({ placeholder }),
      Highlight.configure({ multicolor: true }),
      TaskList,
      TaskItem.configure({ nested: true }),
      CodeBlockLowlight.configure({ lowlight }),
      ImageExtension.configure({ inline: false, allowBase64: false }),
      Link.configure({
        openOnClick: false,
        HTMLAttributes: { rel: 'noopener noreferrer', target: '_blank' },
      }),
      Typography,
      CharacterCount,
      Underline,
      TextStyle,
      Color,
    ],
    content: initialContent ?? (initialText ? `<p>${initialText}</p>` : ''),
    editorProps: {
      attributes: { class: 'tiptap-editor' },
    },
    onUpdate: ({ editor }) => {
      const json = editor.getJSON() as Record<string, unknown>;
      const text = editor.getText();
      onUpdate(json, text);
    },
    immediatelyRender: false,
  });

  // Sync external content changes (e.g. on note switch)
  useEffect(() => {
    if (!editor || editor.isDestroyed) return;
    const current = JSON.stringify(editor.getJSON());
    const incoming = JSON.stringify(initialContent);
    if (initialContent && current !== incoming) {
      editor.commands.setContent(initialContent as any);
    }
  }, [noteId]); // only re-sync on note ID change

  const insertImage = useCallback(
    (url: string) => {
      editor?.chain().focus().setImage({ src: url }).run();
    },
    [editor]
  );

  if (!editor) return null;

  return (
    <div className="flex flex-col gap-0">
      <EditorToolbar editor={editor} noteId={noteId} onImageInsert={insertImage} />
      <EditorContent editor={editor} className="flex-1" />
      <div className="flex items-center justify-end pt-2 border-t border-[var(--color-border)] mt-2">
        <span className="text-xs text-[var(--color-muted-foreground)]">
          {editor.storage.characterCount?.characters() ?? 0} characters ·{' '}
          {editor.storage.characterCount?.words() ?? 0} words
        </span>
      </div>
    </div>
  );
}
