'use client';

import { RefactorOptions } from '@/lib/aiApi';
import { FileText, List, HelpCircle, Lightbulb } from 'lucide-react';

interface RefactorOptionsPanelProps {
  options: RefactorOptions;
  onChange: (opts: RefactorOptions) => void;
  disabled?: boolean;
}

const OPTION_CONFIG = [
  { key: 'refactor' as keyof RefactorOptions, label: 'Rewrite', desc: 'Improve clarity and structure', icon: FileText, color: 'text-violet-500' },
  { key: 'keyPoints' as keyof RefactorOptions, label: 'Key Points', desc: 'Extract bullet takeaways', icon: List, color: 'text-blue-500' },
  { key: 'questions' as keyof RefactorOptions, label: 'Questions', desc: 'Generate study/interview Qs', icon: HelpCircle, color: 'text-amber-500' },
  { key: 'suggestions' as keyof RefactorOptions, label: 'Suggestions', desc: 'Actionable improvements', icon: Lightbulb, color: 'text-emerald-500' },
];

export function RefactorOptionsPanel({ options, onChange, disabled }: RefactorOptionsPanelProps) {
  const toggle = (key: keyof RefactorOptions) => {
    onChange({ ...options, [key]: !options[key] });
  };

  return (
    <div className="grid grid-cols-2 gap-2">
      {OPTION_CONFIG.map(({ key, label, desc, icon: Icon, color }) => (
        <button
          key={key}
          onClick={() => toggle(key)}
          disabled={disabled}
          className={`flex items-start gap-2.5 p-3 rounded-xl border-2 text-left transition-all ${
            options[key]
              ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/5'
              : 'border-[var(--color-border)] hover:border-[var(--color-primary)]/30 opacity-60'
          } ${disabled ? 'cursor-not-allowed' : 'cursor-pointer'}`}
        >
          <Icon size={16} className={`${color} mt-0.5 flex-shrink-0`} />
          <div>
            <p className="text-sm font-medium text-[var(--color-foreground)]">{label}</p>
            <p className="text-[11px] text-[var(--color-muted-foreground)] mt-0.5">{desc}</p>
          </div>
        </button>
      ))}
    </div>
  );
}
