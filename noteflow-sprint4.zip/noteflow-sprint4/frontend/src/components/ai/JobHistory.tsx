'use client';

import { useQuery } from '@tanstack/react-query';
import { aiApi, AiJob } from '@/lib/aiApi';
import { formatDistanceToNow } from 'date-fns';
import { CheckCircle, XCircle, Loader2, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';

interface JobHistoryProps {
  noteId?: string;
  onSelect?: (job: AiJob) => void;
  selectedJobId?: string;
}

const STATUS_ICON = {
  COMPLETED: <CheckCircle size={12} className="text-emerald-500" />,
  FAILED: <XCircle size={12} className="text-[var(--color-destructive)]" />,
  PROCESSING: <Loader2 size={12} className="animate-spin text-[var(--color-primary)]" />,
  PENDING: <Clock size={12} className="text-[var(--color-muted-foreground)]" />,
};

const PROVIDER_BADGE: Record<string, string> = {
  GEMINI: 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300',
  OPENAI: 'bg-emerald-100 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300',
};

export function JobHistory({ noteId, onSelect, selectedJobId }: JobHistoryProps) {
  const { data: jobs = [], isLoading } = useQuery({
    queryKey: ['ai-jobs', noteId],
    queryFn: () => aiApi.listJobs(noteId),
    refetchInterval: (query) => {
      const hasActiveJobs = query.state.data?.some(
        (j) => j.status === 'PENDING' || j.status === 'PROCESSING'
      );
      return hasActiveJobs ? 3000 : false;
    },
  });

  if (isLoading) {
    return <div className="space-y-2">{[...Array(3)].map((_, i) => <div key={i} className="h-14 rounded-lg bg-[var(--color-muted)] animate-pulse" />)}</div>;
  }

  if (jobs.length === 0) {
    return <p className="text-xs text-[var(--color-muted-foreground)] text-center py-4">No jobs yet</p>;
  }

  return (
    <div className="space-y-1.5">
      {jobs.map((job) => (
        <button
          key={job.id}
          onClick={() => onSelect?.(job)}
          className={cn(
            'w-full flex items-start gap-2.5 p-3 rounded-xl border text-left transition-all',
            selectedJobId === job.id
              ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/5'
              : 'border-[var(--color-border)] hover:border-[var(--color-primary)]/30 bg-[var(--color-card)]'
          )}
        >
          <div className="flex-shrink-0 mt-0.5">{STATUS_ICON[job.status]}</div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-1.5">
              <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${PROVIDER_BADGE[job.provider] ?? ''}`}>
                {job.providerModel ?? job.provider}
              </span>
            </div>
            <p className="text-xs text-[var(--color-muted-foreground)] mt-0.5">
              {formatDistanceToNow(new Date(job.createdAt), { addSuffix: true })}
            </p>
            {job.inputTokens != null && (
              <p className="text-[10px] text-[var(--color-muted-foreground)]">
                {job.inputTokens.toLocaleString()} in · {job.outputTokens?.toLocaleString()} out
              </p>
            )}
          </div>
        </button>
      ))}
    </div>
  );
}
