'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { Loader2, Sparkles, CheckCircle, AlertCircle } from 'lucide-react';
import { StreamStatus } from '@/hooks/useAiRefactor';

interface StreamProgressProps {
  status: StreamStatus;
  charCount: number;
  tokenCount?: { input: number; output: number } | null;
  providerModel?: string;
}

const STATUS_CONFIG = {
  idle: { icon: null, label: '', color: '' },
  streaming: {
    icon: <Loader2 size={14} className="animate-spin text-[var(--color-primary)]" />,
    label: 'Generating…',
    color: 'text-[var(--color-primary)]',
  },
  done: {
    icon: <CheckCircle size={14} className="text-emerald-500" />,
    label: 'Complete',
    color: 'text-emerald-500',
  },
  error: {
    icon: <AlertCircle size={14} className="text-[var(--color-destructive)]" />,
    label: 'Error',
    color: 'text-[var(--color-destructive)]',
  },
};

export function StreamProgress({ status, charCount, tokenCount, providerModel }: StreamProgressProps) {
  const cfg = STATUS_CONFIG[status];
  if (status === 'idle') return null;

  return (
    <AnimatePresence>
      <motion.div
        initial={{ opacity: 0, y: -8 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -8 }}
        className="flex items-center justify-between px-3 py-2 rounded-lg bg-[var(--color-muted)]/50 border border-[var(--color-border)]"
      >
        <div className="flex items-center gap-2">
          {cfg.icon}
          <span className={`text-xs font-medium ${cfg.color}`}>{cfg.label}</span>
          {status === 'streaming' && (
            <span className="text-xs text-[var(--color-muted-foreground)]">{charCount} chars received</span>
          )}
        </div>
        {tokenCount && (
          <div className="flex items-center gap-3 text-xs text-[var(--color-muted-foreground)]">
            {providerModel && <span className="font-mono bg-[var(--color-muted)] px-1.5 py-0.5 rounded">{providerModel}</span>}
            <span>{tokenCount.input.toLocaleString()} in</span>
            <span>{tokenCount.output.toLocaleString()} out</span>
          </div>
        )}
      </motion.div>
    </AnimatePresence>
  );
}
