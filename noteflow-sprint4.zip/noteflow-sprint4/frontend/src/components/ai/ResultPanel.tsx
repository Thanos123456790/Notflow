'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { RefactorResult } from '@/lib/aiApi';
import { FileText, List, HelpCircle, Lightbulb, Copy, CheckCheck } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useState } from 'react';

interface ResultPanelProps {
  result: RefactorResult;
  onApply?: (content: string) => void;
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  const handleCopy = async () => {
    await navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <button
      onClick={handleCopy}
      className="p-1 rounded text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors"
      title="Copy"
    >
      {copied ? <CheckCheck size={13} className="text-emerald-500" /> : <Copy size={13} />}
    </button>
  );
}

const fadeUp = {
  hidden: { opacity: 0, y: 12 },
  visible: (i: number) => ({
    opacity: 1, y: 0,
    transition: { delay: i * 0.08, duration: 0.3, ease: 'easeOut' },
  }),
};

export function ResultPanel({ result, onApply }: ResultPanelProps) {
  return (
    <div className="space-y-4">
      {/* Rewritten content */}
      {result.refactoredContent && (
        <motion.div
          custom={0} variants={fadeUp} initial="hidden" animate="visible"
          className="rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--color-border)] bg-violet-50/50 dark:bg-violet-950/20">
            <div className="flex items-center gap-2">
              <FileText size={14} className="text-violet-500" />
              <span className="text-xs font-semibold text-[var(--color-foreground)] uppercase tracking-wider">Rewritten Note</span>
            </div>
            <div className="flex items-center gap-1">
              <CopyButton text={result.refactoredContent} />
              {onApply && (
                <button
                  onClick={() => onApply(result.refactoredContent!)}
                  className="text-xs px-2 py-1 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg hover:opacity-90 transition-opacity"
                >
                  Apply to note
                </button>
              )}
            </div>
          </div>
          <div className="p-4 prose prose-sm dark:prose-invert max-w-none text-[var(--color-foreground)]">
            <ReactMarkdown remarkPlugins={[remarkGfm]}>
              {result.refactoredContent}
            </ReactMarkdown>
          </div>
        </motion.div>
      )}

      {/* Key Points */}
      {result.keyPoints && result.keyPoints.length > 0 && (
        <motion.div
          custom={1} variants={fadeUp} initial="hidden" animate="visible"
          className="rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--color-border)] bg-blue-50/50 dark:bg-blue-950/20">
            <div className="flex items-center gap-2">
              <List size={14} className="text-blue-500" />
              <span className="text-xs font-semibold text-[var(--color-foreground)] uppercase tracking-wider">Key Points</span>
            </div>
            <CopyButton text={result.keyPoints.map(p => `• ${p}`).join('\n')} />
          </div>
          <ul className="p-4 space-y-2">
            {result.keyPoints.map((point, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-[var(--color-foreground)]">
                <span className="w-5 h-5 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 text-[10px] font-bold flex items-center justify-center flex-shrink-0 mt-0.5">
                  {i + 1}
                </span>
                {point}
              </li>
            ))}
          </ul>
        </motion.div>
      )}

      {/* Questions */}
      {result.questions && result.questions.length > 0 && (
        <motion.div
          custom={2} variants={fadeUp} initial="hidden" animate="visible"
          className="rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--color-border)] bg-amber-50/50 dark:bg-amber-950/20">
            <div className="flex items-center gap-2">
              <HelpCircle size={14} className="text-amber-500" />
              <span className="text-xs font-semibold text-[var(--color-foreground)] uppercase tracking-wider">Study / Interview Questions</span>
            </div>
            <CopyButton text={result.questions.map((q, i) => `Q${i + 1}. ${q}`).join('\n')} />
          </div>
          <ol className="p-4 space-y-2">
            {result.questions.map((q, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-[var(--color-foreground)]">
                <span className="text-amber-500 font-semibold flex-shrink-0">Q{i + 1}.</span>
                {q}
              </li>
            ))}
          </ol>
        </motion.div>
      )}

      {/* Suggestions */}
      {result.suggestions && result.suggestions.length > 0 && (
        <motion.div
          custom={3} variants={fadeUp} initial="hidden" animate="visible"
          className="rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] overflow-hidden"
        >
          <div className="flex items-center justify-between px-4 py-2.5 border-b border-[var(--color-border)] bg-emerald-50/50 dark:bg-emerald-950/20">
            <div className="flex items-center gap-2">
              <Lightbulb size={14} className="text-emerald-500" />
              <span className="text-xs font-semibold text-[var(--color-foreground)] uppercase tracking-wider">Suggestions</span>
            </div>
            <CopyButton text={result.suggestions.map(s => `→ ${s}`).join('\n')} />
          </div>
          <ul className="p-4 space-y-2">
            {result.suggestions.map((s, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-[var(--color-foreground)]">
                <span className="text-emerald-500 flex-shrink-0">→</span>
                {s}
              </li>
            ))}
          </ul>
        </motion.div>
      )}
    </div>
  );
}
