'use client';

import { AiProvider } from '@/lib/aiApi';
import { cn } from '@/lib/utils';

interface ProviderSelectorProps {
  value: AiProvider;
  onChange: (v: AiProvider) => void;
  disabled?: boolean;
}

const PROVIDERS: { id: AiProvider; label: string; model: string; color: string }[] = [
  {
    id: 'GEMINI',
    label: 'Gemini',
    model: 'gemini-3.5-flash',
    color: 'from-blue-500 to-cyan-500',
  },
  {
    id: 'OPENAI',
    label: 'GPT',
    model: 'gpt-4.1-mini',
    color: 'from-emerald-500 to-teal-500',
  },
];

export function ProviderSelector({ value, onChange, disabled }: ProviderSelectorProps) {
  return (
    <div className="flex gap-2">
      {PROVIDERS.map((p) => (
        <button
          key={p.id}
          onClick={() => onChange(p.id)}
          disabled={disabled}
          className={cn(
            'flex flex-col items-start gap-0.5 px-3 py-2.5 rounded-xl border-2 transition-all text-left',
            value === p.id
              ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/5'
              : 'border-[var(--color-border)] hover:border-[var(--color-primary)]/40',
            disabled && 'opacity-50 cursor-not-allowed'
          )}
        >
          <div className="flex items-center gap-2">
            <div className={`w-2 h-2 rounded-full bg-gradient-to-br ${p.color}`} />
            <span className="text-sm font-semibold text-[var(--color-foreground)]">{p.label}</span>
            {value === p.id && (
              <span className="text-[10px] bg-[var(--color-primary)] text-[var(--color-primary-foreground)] px-1.5 py-0.5 rounded-full">
                Selected
              </span>
            )}
          </div>
          <span className="text-[11px] text-[var(--color-muted-foreground)] pl-4">{p.model}</span>
        </button>
      ))}
    </div>
  );
}
