'use client';

import { useState, useCallback } from 'react';
import {
  DndContext, DragEndEvent, DragOverEvent, DragStartEvent,
  PointerSensor, useSensor, useSensors, DragOverlay, closestCenter,
} from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, arrayMove } from '@dnd-kit/sortable';
import { Task, TaskStatus } from '@/types/task';
import { TaskCard } from './TaskCard';
import { useUpdateTaskStatus, useReorderTasks } from '@/hooks/useTasks';
import { Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

const COLUMNS: { id: TaskStatus; label: string; color: string }[] = [
  { id: 'TODO',        label: 'To Do',       color: 'border-t-slate-400' },
  { id: 'IN_PROGRESS', label: 'In Progress', color: 'border-t-blue-500' },
  { id: 'DONE',        label: 'Done',        color: 'border-t-emerald-500' },
];

interface KanbanBoardProps {
  tasks: Task[];
  onCreateTask?: (status: TaskStatus) => void;
  onEditTask?: (task: Task) => void;
}

export function KanbanBoard({ tasks, onCreateTask, onEditTask }: KanbanBoardProps) {
  const { updateStatus } = useUpdateTaskStatus();
  const { reorder } = useReorderTasks();
  const [activeId, setActiveId] = useState<string | null>(null);
  const [localTasks, setLocalTasks] = useState<Task[]>(tasks);

  // Keep local state in sync with prop changes
  if (JSON.stringify(tasks.map(t => t.id)) !== JSON.stringify(localTasks.map(t => t.id))) {
    setLocalTasks(tasks);
  }

  const sensors = useSensors(
    useSensor(PointerSensor, { activationConstraint: { distance: 8 } })
  );

  const getColumnTasks = (status: TaskStatus) =>
    localTasks.filter(t => t.status === status).sort((a, b) => a.sortOrder - b.sortOrder);

  const activeTask = activeId ? localTasks.find(t => t.id === activeId) : null;

  const handleDragStart = useCallback((event: DragStartEvent) => {
    setActiveId(event.active.id as string);
  }, []);

  const handleDragOver = useCallback((event: DragOverEvent) => {
    const { active, over } = event;
    if (!over) return;

    const activeTask = localTasks.find(t => t.id === active.id);
    const overTask   = localTasks.find(t => t.id === over.id);
    const overStatus = (over.data.current?.status ?? overTask?.status) as TaskStatus | undefined;

    if (!activeTask || !overStatus) return;
    if (activeTask.status === overStatus) return;

    setLocalTasks(prev =>
      prev.map(t => t.id === activeTask.id ? { ...t, status: overStatus } : t)
    );
  }, [localTasks]);

  const handleDragEnd = useCallback(async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const activeTask = localTasks.find(t => t.id === active.id);
    const overTask   = localTasks.find(t => t.id === over.id);

    if (!activeTask) return;

    const targetStatus = (over.data.current?.status ?? overTask?.status ?? activeTask.status) as TaskStatus;

    // Persist status change if column changed
    if (activeTask.status !== targetStatus) {
      await updateStatus({ id: activeTask.id, status: targetStatus });
    }

    // Persist sort order within column
    if (overTask && activeTask.id !== overTask.id) {
      const colTasks = getColumnTasks(targetStatus);
      const oldIdx = colTasks.findIndex(t => t.id === active.id);
      const newIdx = colTasks.findIndex(t => t.id === over.id);
      if (oldIdx !== -1 && newIdx !== -1) {
        const reordered = arrayMove(colTasks, oldIdx, newIdx);
        await reorder(reordered.map(t => t.id));
      }
    }
  }, [localTasks, updateStatus, reorder]);

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragOver={handleDragOver}
      onDragEnd={handleDragEnd}
    >
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-start">
        {COLUMNS.map(col => {
          const colTasks = getColumnTasks(col.id);
          return (
            <div
              key={col.id}
              data-status={col.id}
              className={cn(
                'rounded-xl border-t-2 border border-[var(--color-border)] bg-[var(--color-muted)]/30 flex flex-col',
                col.color
              )}
            >
              {/* Column header */}
              <div className="flex items-center justify-between px-3 py-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-[var(--color-foreground)]">{col.label}</span>
                  <span className="text-xs bg-[var(--color-muted)] text-[var(--color-muted-foreground)] px-1.5 py-0.5 rounded-full">
                    {colTasks.length}
                  </span>
                </div>
                <button
                  onClick={() => onCreateTask?.(col.id)}
                  className="p-1 rounded-lg text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors"
                  title={`Add to ${col.label}`}
                >
                  <Plus size={14} />
                </button>
              </div>

              {/* Cards */}
              <SortableContext items={colTasks.map(t => t.id)} strategy={verticalListSortingStrategy}>
                <div className="flex flex-col gap-2 p-2 min-h-[120px]">
                  {colTasks.map(task => (
                    <TaskCard key={task.id} task={task} onEdit={onEditTask} draggable />
                  ))}
                  {colTasks.length === 0 && (
                    <div className="flex items-center justify-center py-8 text-xs text-[var(--color-muted-foreground)] border-2 border-dashed border-[var(--color-border)] rounded-xl">
                      Drop tasks here
                    </div>
                  )}
                </div>
              </SortableContext>
            </div>
          );
        })}
      </div>

      {/* Drag overlay */}
      <DragOverlay>
        {activeTask && <TaskCard task={activeTask} />}
      </DragOverlay>
    </DndContext>
  );
}
