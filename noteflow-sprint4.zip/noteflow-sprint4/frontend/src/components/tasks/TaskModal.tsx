'use client';

import { useState, useEffect } from 'react';
import { Task, TaskPriority, TaskStatus, CreateTaskRequest } from '@/types/task';
import { useCreateTask, useUpdateTask, useDeleteTask } from '@/hooks/useTasks';
import { TagInput } from '@/components/tags/TagInput';
import { X, Trash2, Repeat, Link as LinkIcon, Loader2, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';

interface TaskModalProps {
  task?: Task | null;
  defaultStatus?: TaskStatus;
  onClose: () => void;
}

const PRIORITIES: TaskPriority[] = ['HIGH', 'MEDIUM', 'LOW'];
const PRIORITY_COLORS: Record<TaskPriority, string> = {
  HIGH:   'border-red-400 bg-red-50 dark:bg-red-950/30 text-red-700 dark:text-red-300',
  MEDIUM: 'border-amber-400 bg-amber-50 dark:bg-amber-950/30 text-amber-700 dark:text-amber-300',
  LOW:    'border-blue-400 bg-blue-50 dark:bg-blue-950/30 text-blue-700 dark:text-blue-300',
};

const RRULE_PRESETS = [
  { label: 'Daily',         value: 'FREQ=DAILY' },
  { label: 'Weekdays',      value: 'FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR' },
  { label: 'Weekly',        value: 'FREQ=WEEKLY' },
  { label: 'Bi-weekly',     value: 'FREQ=WEEKLY;INTERVAL=2' },
  { label: 'Monthly',       value: 'FREQ=MONTHLY' },
  { label: 'Custom…',       value: 'custom' },
];

export function TaskModal({ task, defaultStatus = 'TODO', onClose }: TaskModalProps) {
  const { createTask, isCreating } = useCreateTask();
  const { updateTask, isUpdating }  = useUpdateTask();
  const { deleteTask }              = useDeleteTask();

  const isEditing = !!task;
  const isBusy    = isCreating || isUpdating;

  const [title,          setTitle]          = useState(task?.title ?? '');
  const [description,    setDescription]    = useState(task?.description ?? '');
  const [priority,       setPriority]       = useState<TaskPriority>(task?.priority ?? 'MEDIUM');
  const [dueDate,        setDueDate]        = useState(task?.dueDate ? task.dueDate.slice(0, 16) : '');
  const [tags,           setTags]           = useState<string[]>(task?.tags ?? []);
  const [recurring,      setRecurring]      = useState(task?.recurring ?? false);
  const [rrulePreset,    setRrulePreset]    = useState('FREQ=WEEKLY');
  const [customRrule,    setCustomRrule]    = useState('');
  const [estimatedMins,  setEstimatedMins]  = useState(task?.estimatedMins?.toString() ?? '');
  const [subtasks,       setSubtasks]       = useState<string[]>(task?.subtasks?.map(s => s.title) ?? []);
  const [newSubtask,     setNewSubtask]     = useState('');

  const addSubtask = () => {
    if (newSubtask.trim()) {
      setSubtasks(prev => [...prev, newSubtask.trim()]);
      setNewSubtask('');
    }
  };

  const handleSave = async () => {
    if (!title.trim()) return;

    const rrule = recurring ? (rrulePreset === 'custom' ? customRrule : rrulePreset) : undefined;
    const payload: CreateTaskRequest = {
      title: title.trim(),
      description: description.trim() || undefined,
      priority,
      dueDate: dueDate ? new Date(dueDate).toISOString() : undefined,
      tags,
      recurring,
      recurrenceRule: rrule,
      estimatedMins: estimatedMins ? parseInt(estimatedMins) : undefined,
      subtasks: subtasks.map((t, i) => ({ title: t, sortOrder: i })),
    };

    if (isEditing) {
      await updateTask({ id: task!.id, ...payload } as any);
    } else {
      await createTask(payload);
    }
    onClose();
  };

  const handleDelete = async () => {
    if (!task || !confirm('Delete this task?')) return;
    await deleteTask(task.id);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />

      <div className="relative z-10 w-full max-w-lg bg-[var(--color-card)] border border-[var(--color-border)] rounded-2xl shadow-2xl flex flex-col max-h-[90vh]">
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-[var(--color-border)]">
          <h2 className="text-base font-semibold text-[var(--color-foreground)]">
            {isEditing ? 'Edit Task' : 'New Task'}
          </h2>
          <div className="flex items-center gap-2">
            {isEditing && (
              <button onClick={handleDelete} className="p-1.5 text-[var(--color-muted-foreground)] hover:text-[var(--color-destructive)] transition-colors">
                <Trash2 size={15} />
              </button>
            )}
            <button onClick={onClose} className="p-1.5 text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors">
              <X size={18} />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="overflow-y-auto p-5 space-y-4 flex-1">
          {/* Title */}
          <input
            autoFocus
            placeholder="Task title…"
            value={title}
            onChange={e => setTitle(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSave()}
            className="w-full text-base font-medium bg-transparent border-none outline-none text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)]/50"
          />

          {/* Description */}
          <textarea
            placeholder="Add description…"
            value={description}
            onChange={e => setDescription(e.target.value)}
            rows={2}
            className="w-full text-sm bg-transparent border-none outline-none resize-none text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)]/40"
          />

          {/* Priority */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Priority</label>
            <div className="flex gap-2">
              {PRIORITIES.map(p => (
                <button
                  key={p}
                  onClick={() => setPriority(p)}
                  className={cn(
                    'flex-1 py-1.5 rounded-lg border-2 text-xs font-semibold transition-all',
                    priority === p ? PRIORITY_COLORS[p] : 'border-[var(--color-border)] text-[var(--color-muted-foreground)] hover:border-[var(--color-primary)]/30'
                  )}
                >
                  {p === 'HIGH' ? '🔴' : p === 'MEDIUM' ? '🟡' : '🔵'} {p.charAt(0) + p.slice(1).toLowerCase()}
                </button>
              ))}
            </div>
          </div>

          {/* Due Date + Estimated time */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Due Date</label>
              <input
                type="datetime-local"
                value={dueDate}
                onChange={e => setDueDate(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-1"
              />
            </div>
            <div>
              <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Est. Time (min)</label>
              <input
                type="number"
                min="1"
                placeholder="e.g. 30"
                value={estimatedMins}
                onChange={e => setEstimatedMins(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-1"
              />
            </div>
          </div>

          {/* Recurring */}
          <div>
            <label className="flex items-center gap-2.5 cursor-pointer">
              <div
                onClick={() => setRecurring(v => !v)}
                className={cn(
                  'w-10 h-5 rounded-full border-2 relative transition-all cursor-pointer',
                  recurring ? 'bg-[var(--color-primary)] border-[var(--color-primary)]' : 'bg-[var(--color-muted)] border-[var(--color-border)]'
                )}
              >
                <div className={cn(
                  'w-3.5 h-3.5 rounded-full bg-white absolute top-0.5 transition-all',
                  recurring ? 'left-5' : 'left-0.5'
                )} />
              </div>
              <div className="flex items-center gap-1.5 text-sm text-[var(--color-foreground)]">
                <Repeat size={14} className={recurring ? 'text-[var(--color-primary)]' : 'text-[var(--color-muted-foreground)]'} />
                Recurring task
              </div>
            </label>

            {recurring && (
              <div className="mt-2 pl-12 space-y-2">
                <select
                  value={rrulePreset}
                  onChange={e => setRrulePreset(e.target.value)}
                  className="w-full px-3 py-1.5 text-xs rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)]"
                >
                  {RRULE_PRESETS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
                </select>
                {rrulePreset === 'custom' && (
                  <input
                    placeholder="e.g. FREQ=WEEKLY;BYDAY=MO,FR"
                    value={customRrule}
                    onChange={e => setCustomRrule(e.target.value)}
                    className="w-full px-3 py-1.5 text-xs font-mono rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none"
                  />
                )}
              </div>
            )}
          </div>

          {/* Subtasks */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Subtasks</label>
            <div className="space-y-1.5 mb-2">
              {subtasks.map((s, i) => (
                <div key={i} className="flex items-center gap-2 group">
                  <div className="w-3 h-3 rounded-full border-2 border-[var(--color-border)] flex-shrink-0" />
                  <span className="flex-1 text-sm text-[var(--color-foreground)]">{s}</span>
                  <button onClick={() => setSubtasks(prev => prev.filter((_, j) => j !== i))} className="opacity-0 group-hover:opacity-100 transition-opacity text-[var(--color-muted-foreground)] hover:text-[var(--color-destructive)]">
                    <X size={12} />
                  </button>
                </div>
              ))}
            </div>
            <div className="flex gap-2">
              <input
                placeholder="Add subtask…"
                value={newSubtask}
                onChange={e => setNewSubtask(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addSubtask()}
                className="flex-1 px-3 py-1.5 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)]/50 focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-1"
              />
              <button onClick={addSubtask} className="p-1.5 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg hover:opacity-90 transition-opacity">
                <Plus size={14} />
              </button>
            </div>
          </div>

          {/* Tags */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Tags</label>
            <TagInput tags={tags} onChange={setTags} />
          </div>
        </div>

        {/* Footer */}
        <div className="flex gap-3 px-5 py-4 border-t border-[var(--color-border)]">
          <button onClick={onClose} className="flex-1 py-2.5 rounded-xl border border-[var(--color-border)] text-sm text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors">
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={!title.trim() || isBusy}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-[var(--color-primary)] text-[var(--color-primary-foreground)] text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-50"
          >
            {isBusy && <Loader2 size={14} className="animate-spin" />}
            {isEditing ? 'Save Changes' : 'Create Task'}
          </button>
        </div>
      </div>
    </div>
  );
}
