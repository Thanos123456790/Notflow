'use client';

import { Task } from '@/types/task';
import { PriorityBadge } from './PriorityBadge';
import { SubtaskList } from './SubtaskList';
import { useUpdateTaskStatus } from '@/hooks/useTasks';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { Calendar, Repeat, Link as LinkIcon, GripVertical, CheckCircle, Circle } from 'lucide-react';
import { formatDistanceToNow, format, isPast, isToday } from 'date-fns';
import { cn } from '@/lib/utils';

interface TaskCardProps {
  task: Task;
  onEdit?: (task: Task) => void;
  draggable?: boolean;
}

export function TaskCard({ task, onEdit, draggable = false }: TaskCardProps) {
  const { updateStatus } = useUpdateTaskStatus();

  const {
    attributes, listeners, setNodeRef,
    transform, transition, isDragging,
  } = useSortable({ id: task.id, disabled: !draggable });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.4 : 1,
  };

  const isDone     = task.status === 'DONE';
  const isOverdue  = task.dueDate && isPast(new Date(task.dueDate)) && !isDone;
  const isDueToday = task.dueDate && isToday(new Date(task.dueDate));

  const toggleComplete = (e: React.MouseEvent) => {
    e.stopPropagation();
    updateStatus({ id: task.id, status: isDone ? 'TODO' : 'DONE' });
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      onClick={() => onEdit?.(task)}
      className={cn(
        'group relative p-3.5 rounded-xl border bg-[var(--color-card)] cursor-pointer transition-all',
        isDragging   ? 'shadow-2xl z-50' : 'hover:shadow-sm hover:border-[var(--color-primary)]/40',
        isDone       ? 'border-[var(--color-border)] opacity-60' : 'border-[var(--color-border)]',
        isOverdue    ? 'border-red-200 dark:border-red-900/40' : '',
        task.color   ? `border-l-4` : '',
      )}
      style={{ ...style, ...(task.color ? { borderLeftColor: task.color } : {}) }}
    >
      {/* Drag handle */}
      {draggable && (
        <button
          {...attributes} {...listeners}
          className="absolute left-1 top-1/2 -translate-y-1/2 p-1 opacity-0 group-hover:opacity-40 hover:!opacity-80 transition-opacity cursor-grab active:cursor-grabbing"
          onClick={e => e.stopPropagation()}
        >
          <GripVertical size={14} className="text-[var(--color-muted-foreground)]" />
        </button>
      )}

      <div className={cn('flex items-start gap-2.5', draggable && 'pl-4')}>
        {/* Complete toggle */}
        <button onClick={toggleComplete} className="flex-shrink-0 mt-0.5">
          {isDone
            ? <CheckCircle size={16} className="text-emerald-500" />
            : <Circle size={16} className="text-[var(--color-muted-foreground)] hover:text-emerald-500 transition-colors" />
          }
        </button>

        <div className="flex-1 min-w-0">
          {/* Title */}
          <p className={cn(
            'text-sm font-medium text-[var(--color-foreground)] leading-snug',
            isDone && 'line-through text-[var(--color-muted-foreground)]'
          )}>
            {task.title}
          </p>

          {/* Meta row */}
          <div className="flex items-center flex-wrap gap-1.5 mt-1.5">
            <PriorityBadge priority={task.priority} />

            {task.dueDate && (
              <span className={cn(
                'flex items-center gap-1 text-[10px]',
                isOverdue    ? 'text-red-500 font-semibold' :
                isDueToday   ? 'text-amber-500 font-semibold' :
                               'text-[var(--color-muted-foreground)]'
              )}>
                <Calendar size={10} />
                {isToday(new Date(task.dueDate))
                  ? 'Today'
                  : format(new Date(task.dueDate), 'MMM d')}
              </span>
            )}

            {task.recurring && (
              <span className="flex items-center gap-1 text-[10px] text-violet-500">
                <Repeat size={10} />
                Recurring
              </span>
            )}

            {task.linkedNoteId && (
              <span className="flex items-center gap-1 text-[10px] text-blue-500">
                <LinkIcon size={10} />
                Note
              </span>
            )}
          </div>

          {/* Subtasks */}
          {task.subtasks && task.subtasks.length > 0 && (
            <SubtaskList taskId={task.id} subtasks={task.subtasks} />
          )}

          {/* Tags */}
          {task.tags && task.tags.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {task.tags.slice(0, 3).map(tag => (
                <span key={tag} className="text-[10px] bg-[var(--color-muted)] text-[var(--color-muted-foreground)] px-1.5 py-0.5 rounded">
                  #{tag}
                </span>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
