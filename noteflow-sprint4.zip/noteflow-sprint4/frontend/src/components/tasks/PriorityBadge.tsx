'use client';

import { TaskPriority, PRIORITY_CONFIG } from '@/types/task';
import { cn } from '@/lib/utils';

interface PriorityBadgeProps {
  priority: TaskPriority;
  size?: 'sm' | 'md';
}

export function PriorityBadge({ priority, size = 'sm' }: PriorityBadgeProps) {
  const cfg = PRIORITY_CONFIG[priority];
  return (
    <span className={cn(
      'inline-flex items-center font-medium rounded-full',
      cfg.color, cfg.bg,
      size === 'sm' ? 'text-[10px] px-1.5 py-0.5' : 'text-xs px-2 py-1'
    )}>
      {cfg.label}
    </span>
  );
}
