'use client';

import { useState } from 'react';
import { Routine, CreateRoutineRequest } from '@/types/task';
import { useRoutines, useCreateRoutine, useDeleteRoutine } from '@/hooks/useTasks';
import { Plus, Trash2, Clock, X, Loader2 } from 'lucide-react';
import { cn } from '@/lib/utils';

const DAYS = ['MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT', 'SUN'];
const DAY_LABELS: Record<string, string> = {
  MON: 'M', TUE: 'T', WED: 'W', THU: 'T', FRI: 'F', SAT: 'S', SUN: 'S'
};

const EMOJIS = ['🌅', '🏃', '📚', '🧘', '💪', '🎯', '✍️', '🎨', '🍎', '💧'];
const COLORS  = ['#7C3AED', '#2563EB', '#059669', '#D97706', '#DC2626', '#DB2777', '#0891B2'];

interface RoutineCardProps {
  routine: Routine;
  onDelete: (id: string) => void;
}

function RoutineCard({ routine, onDelete }: RoutineCardProps) {
  return (
    <div className="flex items-center gap-3 p-3 rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] group">
      <div
        className="w-9 h-9 rounded-lg flex items-center justify-center text-lg flex-shrink-0"
        style={{ backgroundColor: routine.color ? routine.color + '20' : 'var(--color-muted)' }}
      >
        {routine.emoji ?? '📋'}
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm font-medium text-[var(--color-foreground)] truncate">{routine.name}</p>
        <div className="flex items-center gap-2 mt-0.5">
          {routine.startTime && (
            <span className="flex items-center gap-1 text-[10px] text-[var(--color-muted-foreground)]">
              <Clock size={9} /> {routine.startTime}
            </span>
          )}
          <div className="flex gap-0.5">
            {DAYS.map(d => (
              <span
                key={d}
                className={cn(
                  'w-4 h-4 rounded text-[9px] font-bold flex items-center justify-center',
                  routine.daysOfWeek?.includes(d)
                    ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)]'
                    : 'bg-[var(--color-muted)] text-[var(--color-muted-foreground)]'
                )}
              >
                {DAY_LABELS[d]}
              </span>
            ))}
          </div>
        </div>
      </div>
      <button
        onClick={() => onDelete(routine.id)}
        className="opacity-0 group-hover:opacity-100 transition-opacity p-1.5 text-[var(--color-muted-foreground)] hover:text-[var(--color-destructive)]"
      >
        <Trash2 size={13} />
      </button>
    </div>
  );
}

export function RoutineManager() {
  const { routines, isLoading } = useRoutines();
  const { createRoutine, isCreating } = useCreateRoutine();
  const { deleteRoutine } = useDeleteRoutine();

  const [showForm, setShowForm] = useState(false);
  const [name,       setName]       = useState('');
  const [startTime,  setStartTime]  = useState('');
  const [days,       setDays]       = useState<string[]>([]);
  const [emoji,      setEmoji]      = useState('🎯');
  const [color,      setColor]      = useState('#7C3AED');

  const toggleDay = (d: string) =>
    setDays(prev => prev.includes(d) ? prev.filter(x => x !== d) : [...prev, d]);

  const handleCreate = async () => {
    if (!name.trim()) return;
    await createRoutine({
      name: name.trim(),
      startTime: startTime || undefined,
      daysOfWeek: days,
      emoji,
      color,
    });
    setName(''); setStartTime(''); setDays([]); setShowForm(false);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-semibold text-[var(--color-foreground)]">Routines</h3>
        <button
          onClick={() => setShowForm(v => !v)}
          className="flex items-center gap-1.5 text-xs text-[var(--color-primary)] hover:opacity-80 transition-opacity"
        >
          <Plus size={13} />
          New
        </button>
      </div>

      {showForm && (
        <div className="p-3.5 rounded-xl border border-[var(--color-primary)]/30 bg-[var(--color-primary)]/5 space-y-3">
          {/* Emoji + Color row */}
          <div className="flex items-center gap-2">
            <div className="flex gap-1 flex-wrap">
              {EMOJIS.map(e => (
                <button key={e} onClick={() => setEmoji(e)}
                  className={cn('text-base p-1 rounded transition-all', emoji === e ? 'bg-[var(--color-muted)] ring-2 ring-[var(--color-primary)]' : 'hover:bg-[var(--color-muted)]')}>
                  {e}
                </button>
              ))}
            </div>
          </div>

          {/* Name */}
          <input
            autoFocus placeholder="Routine name…"
            value={name} onChange={e => setName(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleCreate()}
            className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)]"
          />

          {/* Time */}
          <input
            type="time" value={startTime} onChange={e => setStartTime(e.target.value)}
            className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)]"
          />

          {/* Days */}
          <div className="flex gap-1.5">
            {DAYS.map(d => (
              <button key={d} onClick={() => toggleDay(d)}
                className={cn(
                  'w-8 h-8 rounded-lg text-xs font-bold transition-all',
                  days.includes(d)
                    ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)]'
                    : 'bg-[var(--color-muted)] text-[var(--color-muted-foreground)] hover:bg-[var(--color-accent)]'
                )}>
                {DAY_LABELS[d]}
              </button>
            ))}
          </div>

          {/* Colors */}
          <div className="flex gap-1.5">
            {COLORS.map(c => (
              <button key={c} onClick={() => setColor(c)}
                className={cn('w-5 h-5 rounded-full border-2 transition-all', color === c ? 'border-white scale-110' : 'border-transparent')}
                style={{ backgroundColor: c }}
              />
            ))}
          </div>

          <div className="flex gap-2">
            <button onClick={() => setShowForm(false)} className="flex-1 py-2 rounded-lg border border-[var(--color-border)] text-xs text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors">
              Cancel
            </button>
            <button onClick={handleCreate} disabled={!name.trim() || isCreating}
              className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-[var(--color-primary)] text-[var(--color-primary-foreground)] text-xs font-semibold hover:opacity-90 transition-opacity disabled:opacity-50">
              {isCreating && <Loader2 size={12} className="animate-spin" />}
              Create
            </button>
          </div>
        </div>
      )}

      {isLoading
        ? <div className="space-y-2">{[...Array(2)].map((_, i) => <div key={i} className="h-14 rounded-xl bg-[var(--color-muted)] animate-pulse" />)}</div>
        : routines.length === 0
        ? <p className="text-xs text-[var(--color-muted-foreground)] text-center py-4">No routines yet</p>
        : <div className="space-y-2">{routines.map(r => <RoutineCard key={r.id} routine={r} onDelete={deleteRoutine} />)}</div>
      }
    </div>
  );
}
