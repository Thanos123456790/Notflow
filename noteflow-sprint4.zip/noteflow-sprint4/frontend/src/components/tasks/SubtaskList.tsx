'use client';

import { Subtask } from '@/types/task';
import { useToggleSubtask } from '@/hooks/useTasks';
import { cn } from '@/lib/utils';

interface SubtaskListProps {
  taskId: string;
  subtasks: Subtask[];
}

export function SubtaskList({ taskId, subtasks }: SubtaskListProps) {
  const { toggleSubtask } = useToggleSubtask();

  if (!subtasks || subtasks.length === 0) return null;

  const completed = subtasks.filter(s => s.completed).length;

  return (
    <div className="mt-3 space-y-1.5">
      <div className="flex items-center gap-2 mb-2">
        <div className="flex-1 h-1.5 rounded-full bg-[var(--color-muted)] overflow-hidden">
          <div
            className="h-full bg-emerald-500 rounded-full transition-all duration-300"
            style={{ width: `${subtasks.length > 0 ? (completed / subtasks.length) * 100 : 0}%` }}
          />
        </div>
        <span className="text-[10px] text-[var(--color-muted-foreground)] flex-shrink-0">
          {completed}/{subtasks.length}
        </span>
      </div>
      {subtasks.map(sub => (
        <label
          key={sub.id}
          className="flex items-start gap-2 cursor-pointer group"
          onClick={() => toggleSubtask({ taskId, subtaskId: sub.id })}
        >
          <div className={cn(
            'w-4 h-4 rounded border-2 flex items-center justify-center flex-shrink-0 mt-0.5 transition-all',
            sub.completed
              ? 'bg-emerald-500 border-emerald-500'
              : 'border-[var(--color-border)] group-hover:border-emerald-400'
          )}>
            {sub.completed && (
              <svg className="w-2.5 h-2.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            )}
          </div>
          <span className={cn(
            'text-xs transition-all',
            sub.completed
              ? 'line-through text-[var(--color-muted-foreground)]'
              : 'text-[var(--color-foreground)]'
          )}>
            {sub.title}
          </span>
        </label>
      ))}
    </div>
  );
}
