'use client';

import Link from 'next/link';
import { Note } from '@/types/note';
import { Pin } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { cn } from '@/lib/utils';

interface NoteCardProps {
  note: Note;
  viewMode?: 'grid' | 'list';
}

export function NoteCard({ note, viewMode = 'grid' }: NoteCardProps) {
  const preview = note.contentText
    ? note.contentText.slice(0, 140) + (note.contentText.length > 140 ? '…' : '')
    : 'No content';

  if (viewMode === 'list') {
    return (
      <Link href={`/notes/${note.id}`}>
        <div className="flex items-center gap-4 px-4 py-3 rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] hover:border-[var(--color-primary)]/40 hover:shadow-sm transition-all cursor-pointer group">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              {note.isPinned && <Pin size={12} className="text-amber-500 flex-shrink-0" />}
              <p className="text-sm font-medium text-[var(--color-foreground)] truncate">{note.title || 'Untitled'}</p>
            </div>
            <p className="text-xs text-[var(--color-muted-foreground)] truncate mt-0.5">{preview}</p>
          </div>
          <div className="flex items-center gap-3 flex-shrink-0">
            {note.tags && note.tags.length > 0 && (
              <div className="flex gap-1">
                {note.tags.slice(0, 2).map(tag => (
                  <span key={tag} className="text-xs bg-[var(--color-primary)]/10 text-[var(--color-primary)] px-1.5 py-0.5 rounded">#{tag}</span>
                ))}
              </div>
            )}
            <span className="text-xs text-[var(--color-muted-foreground)] whitespace-nowrap">
              {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
            </span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link href={`/notes/${note.id}`}>
      <div className="group relative flex flex-col h-40 p-4 rounded-xl border border-[var(--color-border)] bg-[var(--color-card)] hover:border-[var(--color-primary)]/40 hover:shadow-sm transition-all cursor-pointer overflow-hidden">
        {note.isPinned && <Pin size={13} className="absolute top-3 right-3 text-amber-500" />}
        <p className="text-sm font-semibold text-[var(--color-foreground)] truncate mb-1.5 pr-5">
          {note.title || 'Untitled'}
        </p>
        <p className="text-xs text-[var(--color-muted-foreground)] leading-relaxed flex-1 overflow-hidden line-clamp-3">
          {preview}
        </p>
        <div className="flex items-center justify-between mt-2 pt-2 border-t border-[var(--color-border)]/60">
          <div className="flex gap-1 overflow-hidden">
            {note.tags?.slice(0, 2).map(tag => (
              <span key={tag} className="text-xs bg-[var(--color-primary)]/10 text-[var(--color-primary)] px-1.5 py-0.5 rounded truncate max-w-[80px]">
                #{tag}
              </span>
            ))}
          </div>
          <span className="text-xs text-[var(--color-muted-foreground)] whitespace-nowrap flex-shrink-0">
            {formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}
          </span>
        </div>
      </div>
    </Link>
  );
}
