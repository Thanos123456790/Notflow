'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useCreateNote } from '@/hooks/useNotes';
import { useFolders } from '@/hooks/useFolders';
import { TagInput } from '@/components/tags/TagInput';
import { X, FileText, Loader2, Folder } from 'lucide-react';

interface NoteCreateModalProps {
  onClose: () => void;
  defaultFolderId?: string;
}

export function NoteCreateModal({ onClose, defaultFolderId }: NoteCreateModalProps) {
  const router = useRouter();
  const { createNote, isCreating } = useCreateNote();
  const { folders } = useFolders();
  const [title, setTitle] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [folderId, setFolderId] = useState(defaultFolderId ?? '');

  const handleCreate = async () => {
    const note = await createNote({
      title: title.trim() || 'Untitled Note',
      tags,
      folderId: folderId || undefined,
    });
    onClose();
    router.push(`/notes/${note.id}`);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && e.target instanceof HTMLInputElement) handleCreate();
    if (e.key === 'Escape') onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative z-10 w-full max-w-md bg-[var(--color-card)] border border-[var(--color-border)] rounded-2xl shadow-2xl p-6">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-[var(--color-primary)]/10 flex items-center justify-center">
              <FileText size={16} className="text-[var(--color-primary)]" />
            </div>
            <h2 className="text-base font-semibold text-[var(--color-foreground)]">New Note</h2>
          </div>
          <button onClick={onClose} className="text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Title</label>
            <input
              autoFocus
              placeholder="Note title..."
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              onKeyDown={handleKeyDown}
              className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-2"
            />
          </div>

          {folders.length > 0 && (
            <div>
              <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Folder</label>
              <select
                value={folderId}
                onChange={(e) => setFolderId(e.target.value)}
                className="w-full px-3 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-2"
              >
                <option value="">No folder</option>
                {folders.map(f => <option key={f.id} value={f.id}>{f.name}</option>)}
              </select>
            </div>
          )}

          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">Tags</label>
            <TagInput tags={tags} onChange={setTags} placeholder="Add tags (Enter or comma to add)..." />
          </div>
        </div>

        <div className="flex gap-3 mt-6">
          <button
            onClick={onClose}
            className="flex-1 px-4 py-2 text-sm rounded-lg border border-[var(--color-border)] text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleCreate}
            disabled={isCreating}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2 text-sm bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg font-medium hover:opacity-90 transition-opacity disabled:opacity-60"
          >
            {isCreating && <Loader2 size={14} className="animate-spin" />}
            Create Note
          </button>
        </div>
      </div>
    </div>
  );
}
