'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Paperclip, Loader2, X, FileText, FileImage, FileCode } from 'lucide-react';
import { notesApi } from '@/lib/notesApi';
import { NoteAttachment } from '@/types/note';
import { cn } from '@/lib/utils';

interface FileDropzoneProps {
  noteId: string;
  onUploaded: (attachment: NoteAttachment) => void;
}

const ICON_MAP: Record<string, React.ReactNode> = {
  'image/': <FileImage size={14} className="text-blue-500" />,
  'text/': <FileText size={14} className="text-green-500" />,
  'application/pdf': <FileText size={14} className="text-red-500" />,
  'default': <FileCode size={14} className="text-muted-foreground" />,
};

function getIcon(type: string) {
  for (const [k, v] of Object.entries(ICON_MAP)) {
    if (type.startsWith(k) || type === k) return v;
  }
  return ICON_MAP['default'];
}

function formatBytes(bytes: number) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1048576) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1048576).toFixed(1) + ' MB';
}

export function FileDropzone({ noteId, onUploaded }: FileDropzoneProps) {
  const [uploading, setUploading] = useState<string[]>([]);

  const uploadFile = useCallback(
    async (file: File) => {
      const id = crypto.randomUUID();
      setUploading((p) => [...p, id]);
      try {
        const presign = await notesApi.presignAttachment({
          noteId,
          filename: file.name,
          contentType: file.type || 'application/octet-stream',
        });
        await notesApi.uploadToS3(presign.uploadUrl, file);
        await notesApi.confirmAttachment(presign.attachmentId, presign.fileKey);
        onUploaded({
          id: presign.attachmentId,
          noteId,
          fileName: file.name,
          fileType: file.type,
          s3Key: presign.fileKey,
          cdnUrl: presign.cdnUrl ?? '',
          sizeBytes: file.size,
          uploadStatus: 'CONFIRMED',
          createdAt: new Date().toISOString(),
        });
      } catch (err) {
        console.error('File upload failed:', err);
      } finally {
        setUploading((p) => p.filter((i) => i !== id));
      }
    },
    [noteId, onUploaded]
  );

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    multiple: true,
    maxSize: 25 * 1024 * 1024, // 25 MB
    onDrop: (files) => files.forEach(uploadFile),
  });

  return (
    <div
      {...getRootProps()}
      className={cn(
        'flex items-center gap-2 px-3 py-2 rounded-lg border border-dashed border-[var(--color-border)] cursor-pointer transition-colors text-xs text-[var(--color-muted-foreground)]',
        isDragActive && 'border-[var(--color-primary)] bg-[var(--color-primary)]/5 text-[var(--color-primary)]'
      )}
    >
      <input {...getInputProps()} />
      {uploading.length > 0 ? (
        <Loader2 size={14} className="animate-spin" />
      ) : (
        <Paperclip size={14} />
      )}
      {isDragActive
        ? 'Drop files here…'
        : uploading.length > 0
        ? `Uploading ${uploading.length} file${uploading.length > 1 ? 's' : ''}…`
        : 'Attach files (drag & drop or click)'}
    </div>
  );
}
