'use client';

import { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Image, Loader2 } from 'lucide-react';
import { notesApi } from '@/lib/notesApi';
import { cn } from '@/lib/utils';

interface ImageUploadButtonProps {
  noteId: string;
  onInsert: (cdnUrl: string) => void;
}

export function ImageUploadButton({ noteId, onInsert }: ImageUploadButtonProps) {
  const [uploading, setUploading] = useState(false);

  const upload = useCallback(
    async (file: File) => {
      if (!file.type.startsWith('image/')) return;
      setUploading(true);
      try {
        // 1. Get pre-signed URL
        const presign = await notesApi.presignAttachment({
          noteId,
          filename: file.name,
          contentType: file.type,
        });

        // 2. Upload directly to S3
        await notesApi.uploadToS3(presign.uploadUrl, file);

        // 3. Confirm upload
        await notesApi.confirmAttachment(presign.attachmentId, presign.fileKey);

        // 4. Insert CDN URL into editor
        onInsert(presign.cdnUrl ?? presign.uploadUrl);
      } catch (err) {
        console.error('Image upload failed:', err);
      } finally {
        setUploading(false);
      }
    },
    [noteId, onInsert]
  );

  const { getRootProps, getInputProps } = useDropzone({
    accept: { 'image/*': [] },
    multiple: false,
    noClick: false,
    onDrop: (files) => { if (files[0]) upload(files[0]); },
  });

  return (
    <button
      {...getRootProps()}
      title="Upload image"
      disabled={uploading}
      className={cn(
        'p-1.5 rounded-md text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] hover:bg-[var(--color-muted)] transition-colors',
        uploading && 'opacity-60 cursor-not-allowed'
      )}
    >
      <input {...getInputProps()} />
      {uploading ? <Loader2 size={15} className="animate-spin" /> : <Image size={15} />}
    </button>
  );
}
