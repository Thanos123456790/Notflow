'use client';

import { NoteAttachment } from '@/types/note';
import { FileText, FileImage, FileCode, X, ExternalLink } from 'lucide-react';

interface AttachmentListProps {
  attachments: NoteAttachment[];
  onRemove?: (id: string) => void;
}

function formatBytes(b: number) {
  if (b < 1024) return b + ' B';
  if (b < 1048576) return (b / 1024).toFixed(1) + ' KB';
  return (b / 1048576).toFixed(1) + ' MB';
}

function FileIcon({ type }: { type: string }) {
  if (type.startsWith('image/')) return <FileImage size={14} className="text-blue-500" />;
  if (type === 'application/pdf') return <FileText size={14} className="text-red-500" />;
  return <FileCode size={14} className="text-[var(--color-muted-foreground)]" />;
}

export function AttachmentList({ attachments, onRemove }: AttachmentListProps) {
  if (!attachments || attachments.length === 0) return null;

  return (
    <div className="space-y-1.5">
      {attachments
        .filter((a) => a.uploadStatus === 'CONFIRMED')
        .map((a) => (
          <div
            key={a.id}
            className="flex items-center gap-2 px-3 py-2 rounded-lg bg-[var(--color-muted)] group"
          >
            <FileIcon type={a.fileType} />
            <span className="text-xs text-[var(--color-foreground)] flex-1 truncate">{a.fileName}</span>
            {a.sizeBytes && (
              <span className="text-xs text-[var(--color-muted-foreground)] flex-shrink-0">
                {formatBytes(a.sizeBytes)}
              </span>
            )}
            <a
              href={a.cdnUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="opacity-0 group-hover:opacity-100 transition-opacity text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)]"
            >
              <ExternalLink size={12} />
            </a>
            {onRemove && (
              <button
                onClick={() => onRemove(a.id)}
                className="opacity-0 group-hover:opacity-100 transition-opacity text-[var(--color-muted-foreground)] hover:text-[var(--color-destructive)]"
              >
                <X size={12} />
              </button>
            )}
          </div>
        ))}
    </div>
  );
}
