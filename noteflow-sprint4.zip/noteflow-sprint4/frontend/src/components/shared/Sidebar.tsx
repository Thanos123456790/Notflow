'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { UserButton } from '@clerk/nextjs';
import { FileText, Sparkles, Calendar, Mic, User, LayoutDashboard, Search } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import { CommandPalette } from '../search/CommandPalette';
import { FolderList } from '../folders/FolderList';
import { useFolders, useTags } from '@/hooks/useFolders';

const NAV_ITEMS = [
  { href: '/', icon: LayoutDashboard, label: 'Dashboard', exact: true },
  { href: '/notes', icon: FileText, label: 'Notes' },
  { href: '/ai-enhance', icon: Sparkles, label: 'AI Enhance' },
  { href: '/tasks', icon: Calendar, label: 'Tasks' },
  { href: '/interview', icon: Mic, label: 'Interview Prep' },
  { href: '/profile', icon: User, label: 'Profile' },
];

export function Sidebar() {
  const pathname = usePathname();
  const [cmdOpen, setCmdOpen] = useState(false);
  const { folders } = useFolders();
  const { tags } = useTags();
  const isNotesSection = pathname.startsWith('/notes');

  return (
    <>
      <aside className="w-[240px] flex-shrink-0 border-r border-[var(--color-border)] bg-[var(--color-card)] flex flex-col h-full">
        <div className="h-14 flex items-center px-4 border-b border-[var(--color-border)] gap-2.5">
          <div className="w-7 h-7 rounded-lg bg-[var(--color-primary)] flex items-center justify-center flex-shrink-0">
            <span className="text-[var(--color-primary-foreground)] text-sm font-bold">N</span>
          </div>
          <span className="font-semibold text-[var(--color-foreground)] text-sm">NoteFlow AI</span>
        </div>

        <div className="px-3 py-2 border-b border-[var(--color-border)]">
          <button
            onClick={() => setCmdOpen(true)}
            className="flex items-center gap-2 w-full px-3 py-2 rounded-lg bg-[var(--color-muted)] text-[var(--color-muted-foreground)] text-sm hover:bg-[var(--color-accent)] hover:text-[var(--color-accent-foreground)] transition-colors"
          >
            <Search size={13} />
            <span className="flex-1 text-left">Search...</span>
            <kbd className="text-xs border border-[var(--color-border)] rounded px-1 py-0.5">Cmd+K</kbd>
          </button>
        </div>

        <nav className="px-2 py-3 space-y-0.5">
          {NAV_ITEMS.map(({ href, icon: Icon, label, exact }) => {
            const isActive = exact ? pathname === href : pathname.startsWith(href);
            return (
              <Link key={href} href={href}>
                <span className={cn(
                  'flex items-center gap-3 px-3 py-2 rounded-lg text-sm font-medium transition-colors',
                  isActive
                    ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)]'
                    : 'text-[var(--color-muted-foreground)] hover:bg-[var(--color-accent)] hover:text-[var(--color-accent-foreground)]'
                )}>
                  <Icon size={15} className="flex-shrink-0" />
                  {label}
                </span>
              </Link>
            );
          })}
        </nav>

        {isNotesSection && (folders.length > 0 || tags.length > 0) && (
          <div className="px-3 py-3 border-t border-[var(--color-border)] flex-1 overflow-y-auto">
            <FolderList folders={folders} tags={tags} />
          </div>
        )}

        <div className="border-t border-[var(--color-border)] px-4 py-3 flex items-center gap-3 mt-auto">
          <UserButton afterSignOutUrl="/sign-in" />
          <span className="text-xs text-[var(--color-muted-foreground)] truncate">Account</span>
        </div>
      </aside>

      <CommandPalette open={cmdOpen} onOpenChange={setCmdOpen} />
    </>
  );
}
