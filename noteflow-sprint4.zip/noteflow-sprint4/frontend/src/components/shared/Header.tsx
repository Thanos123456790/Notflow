'use client';

import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { Bell, Search } from 'lucide-react';
import { CommandPalette } from '../search/CommandPalette';

const PAGE_TITLES: Record<string, string> = {
  '/': 'Dashboard',
  '/notes': 'Notes',
  '/ai-enhance': 'AI Enhance',
  '/tasks': 'Tasks & Calendar',
  '/interview': 'Interview Prep',
  '/profile': 'Profile',
};

export function Header() {
  const pathname = usePathname();
  const [cmdOpen, setCmdOpen] = useState(false);

  const title =
    Object.entries(PAGE_TITLES)
      .sort((a, b) => b[0].length - a[0].length)
      .find(([path]) => pathname === path || pathname.startsWith(path + '/'))?.[1] ?? 'NoteFlow AI';

  // Global ⌘K handler
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setCmdOpen((v) => !v);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  return (
    <>
      <header className="h-14 border-b border-[var(--color-border)] bg-[var(--color-card)]/80 backdrop-blur-sm flex items-center justify-between px-6 flex-shrink-0">
        <h2 className="text-sm font-semibold text-[var(--color-foreground)]">{title}</h2>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setCmdOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs text-[var(--color-muted-foreground)] border border-[var(--color-border)] hover:bg-[var(--color-muted)] transition-colors"
          >
            <Search size={12} />
            Search
            <kbd className="ml-1 border border-[var(--color-border)] rounded px-1 py-0.5 text-[10px]">⌘K</kbd>
          </button>
          <button className="p-2 rounded-lg hover:bg-[var(--color-muted)] transition-colors text-[var(--color-muted-foreground)]">
            <Bell size={16} />
          </button>
        </div>
      </header>

      <CommandPalette open={cmdOpen} onOpenChange={setCmdOpen} />
    </>
  );
}
