'use client';

import { useState } from 'react';
import { Folder, FolderPlus, ChevronRight, Hash } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useNoteStore } from '@/store/noteStore';

interface FolderItem {
  id: string;
  name: string;
  color?: string | null;
  noteCount?: number;
}

interface FolderListProps {
  folders: FolderItem[];
  tags?: string[];
  onCreateFolder?: () => void;
}

export function FolderList({ folders, tags = [], onCreateFolder }: FolderListProps) {
  const { activeFolder, setActiveFolder, activeTags, toggleTag } = useNoteStore();
  const [foldersOpen, setFoldersOpen] = useState(true);
  const [tagsOpen, setTagsOpen] = useState(true);

  return (
    <div className="space-y-4">
      {/* Folders */}
      <div>
        <button
          onClick={() => setFoldersOpen((v) => !v)}
          className="flex items-center justify-between w-full px-2 py-1 text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider hover:text-[var(--color-foreground)] transition-colors"
        >
          <span className="flex items-center gap-1">
            <ChevronRight size={12} className={cn('transition-transform', foldersOpen && 'rotate-90')} />
            Folders
          </span>
          <button
            onClick={(e) => { e.stopPropagation(); onCreateFolder?.(); }}
            className="hover:text-[var(--color-foreground)] transition-colors"
            title="New folder"
          >
            <FolderPlus size={13} />
          </button>
        </button>

        {foldersOpen && (
          <div className="mt-1 space-y-0.5">
            <button
              onClick={() => setActiveFolder(null)}
              className={cn(
                'flex items-center gap-2 w-full px-3 py-1.5 rounded-lg text-sm transition-colors',
                !activeFolder
                  ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)]'
                  : 'text-[var(--color-muted-foreground)] hover:bg-[var(--color-accent)] hover:text-[var(--color-accent-foreground)]'
              )}
            >
              <Folder size={14} />
              <span>All Notes</span>
            </button>
            {folders.map((f) => (
              <button
                key={f.id}
                onClick={() => setActiveFolder(f.id)}
                className={cn(
                  'flex items-center gap-2 w-full px-3 py-1.5 rounded-lg text-sm transition-colors',
                  activeFolder === f.id
                    ? 'bg-[var(--color-primary)]/10 text-[var(--color-primary)]'
                    : 'text-[var(--color-muted-foreground)] hover:bg-[var(--color-accent)] hover:text-[var(--color-accent-foreground)]'
                )}
              >
                <span
                  className="w-3 h-3 rounded-sm flex-shrink-0"
                  style={{ backgroundColor: f.color ?? 'var(--color-muted-foreground)' }}
                />
                <span className="truncate flex-1 text-left">{f.name}</span>
                {f.noteCount != null && (
                  <span className="text-xs opacity-60">{f.noteCount}</span>
                )}
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Tags */}
      {tags.length > 0 && (
        <div>
          <button
            onClick={() => setTagsOpen((v) => !v)}
            className="flex items-center gap-1 w-full px-2 py-1 text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider hover:text-[var(--color-foreground)] transition-colors"
          >
            <ChevronRight size={12} className={cn('transition-transform', tagsOpen && 'rotate-90')} />
            Tags
          </button>

          {tagsOpen && (
            <div className="mt-1 flex flex-wrap gap-1.5 px-1">
              {tags.map((tag) => (
                <button
                  key={tag}
                  onClick={() => toggleTag(tag)}
                  className={cn(
                    'flex items-center gap-1 text-xs px-2 py-0.5 rounded-full border transition-colors',
                    activeTags.includes(tag)
                      ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)] border-[var(--color-primary)]'
                      : 'border-[var(--color-border)] text-[var(--color-muted-foreground)] hover:border-[var(--color-primary)]/50 hover:text-[var(--color-foreground)]'
                  )}
                >
                  <Hash size={9} />
                  {tag}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
