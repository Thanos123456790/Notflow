'use client';

import { useRef, useCallback } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import listPlugin from '@fullcalendar/list';
import interactionPlugin from '@fullcalendar/interaction';
import rrulePlugin from '@fullcalendar/rrule';
import { Task } from '@/types/task';
import { useCalendarTasks } from '@/hooks/useTasks';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';

interface CalendarViewProps {
  onTaskClick?: (task: Task) => void;
  onDateClick?: (date: string) => void;
}

const PRIORITY_COLORS: Record<string, string> = {
  HIGH:   '#ef4444',
  MEDIUM: '#f59e0b',
  LOW:    '#3b82f6',
};

const STATUS_BG: Record<string, string> = {
  TODO:        '#6366f1',
  IN_PROGRESS: '#3b82f6',
  DONE:        '#10b981',
  ARCHIVED:    '#9ca3af',
};

export function CalendarView({ onTaskClick, onDateClick }: CalendarViewProps) {
  const calRef = useRef<FullCalendar>(null);

  // We use a wide window — FullCalendar navigates, but we always have 3 months loaded
  const today = new Date();
  const from  = format(new Date(today.getFullYear(), today.getMonth() - 1, 1), 'yyyy-MM-dd');
  const to    = format(new Date(today.getFullYear(), today.getMonth() + 3, 0), 'yyyy-MM-dd');

  const { tasks, isLoading } = useCalendarTasks(from, to);

  const events = tasks.flatMap(task => {
    const base = {
      id:    task.id,
      title: task.title,
      backgroundColor: task.color ?? STATUS_BG[task.status] ?? '#6366f1',
      borderColor:     PRIORITY_COLORS[task.priority] ?? '#6366f1',
      extendedProps: { task },
    };

    if (task.recurring && task.recurrenceRule) {
      // Use FullCalendar's rrule plugin for recurring events
      return [{
        ...base,
        rrule: {
          dtstart: task.dueDate ?? task.createdAt,
          ...parseRRule(task.recurrenceRule),
        },
      }];
    }

    if (task.dueDate) {
      return [{ ...base, start: task.dueDate, allDay: !task.dueDate.includes('T') }];
    }

    // Tasks without due dates shown as all-day on created date
    return [{ ...base, start: task.createdAt.slice(0, 10), allDay: true }];
  });

  const handleEventClick = useCallback((info: any) => {
    const task = info.event.extendedProps.task as Task;
    onTaskClick?.(task);
  }, [onTaskClick]);

  const handleDateClick = useCallback((info: any) => {
    onDateClick?.(info.dateStr);
  }, [onDateClick]);

  return (
    <div className="calendar-wrapper">
      <style>{`
        .calendar-wrapper .fc {
          --fc-border-color: var(--color-border);
          --fc-event-border-color: transparent;
          --fc-today-bg-color: oklch(from var(--color-primary) l c h / 0.08);
          --fc-page-bg-color: transparent;
          --fc-neutral-bg-color: var(--color-muted);
          font-family: inherit;
        }
        .calendar-wrapper .fc-toolbar-title { font-size: 1rem; font-weight: 600; color: var(--color-foreground); }
        .calendar-wrapper .fc-button { background: var(--color-muted) !important; color: var(--color-foreground) !important; border: 1px solid var(--color-border) !important; border-radius: 0.5rem !important; font-size: 0.75rem !important; padding: 0.375rem 0.75rem !important; }
        .calendar-wrapper .fc-button:hover { background: var(--color-accent) !important; }
        .calendar-wrapper .fc-button-active { background: var(--color-primary) !important; color: var(--color-primary-foreground) !important; border-color: var(--color-primary) !important; }
        .calendar-wrapper .fc-event { cursor: pointer; border-radius: 4px; font-size: 0.7rem; padding: 1px 4px; }
        .calendar-wrapper .fc-daygrid-day-number { color: var(--color-foreground); font-size: 0.8rem; }
        .calendar-wrapper .fc-col-header-cell-cushion { color: var(--color-muted-foreground); font-size: 0.75rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.05em; }
      `}</style>

      <FullCalendar
        ref={calRef}
        plugins={[dayGridPlugin, timeGridPlugin, listPlugin, interactionPlugin, rrulePlugin]}
        initialView="dayGridMonth"
        headerToolbar={{
          left:   'prev,next today',
          center: 'title',
          right:  'dayGridMonth,timeGridWeek,listWeek',
        }}
        events={events}
        eventClick={handleEventClick}
        dateClick={handleDateClick}
        height="auto"
        dayMaxEvents={4}
        loading={isLoading}
        eventTimeFormat={{ hour: '2-digit', minute: '2-digit', meridiem: 'short' }}
      />
    </div>
  );
}

/** Convert a RRULE string into FullCalendar's rrule plugin object format */
function parseRRule(rrule: string): Record<string, unknown> {
  const parts: Record<string, string> = {};
  rrule.replace(/^RRULE:/, '').split(';').forEach(part => {
    const [k, v] = part.split('=');
    if (k && v) parts[k] = v;
  });

  return {
    freq:     (parts.FREQ ?? 'WEEKLY').toLowerCase(),
    interval: parts.INTERVAL ? parseInt(parts.INTERVAL) : undefined,
    byweekday: parts.BYDAY ? parts.BYDAY.split(',').map(d => d.toLowerCase().slice(0, 2)) : undefined,
    count:    parts.COUNT ? parseInt(parts.COUNT) : undefined,
    until:    parts.UNTIL ? parts.UNTIL : undefined,
  };
}
