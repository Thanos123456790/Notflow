import { create } from 'zustand';
import { Note } from '@/types/note';

interface NoteStore {
  selectedNote: Note | null;
  setSelectedNote: (note: Note | null) => void;
  sidebarOpen: boolean;
  setSidebarOpen: (open: boolean) => void;
  activeFolder: string | null;
  setActiveFolder: (id: string | null) => void;
  activeTags: string[];
  toggleTag: (tag: string) => void;
  clearTags: () => void;
}

export const useNoteStore = create<NoteStore>((set) => ({
  selectedNote: null,
  setSelectedNote: (note) => set({ selectedNote: note }),
  sidebarOpen: true,
  setSidebarOpen: (open) => set({ sidebarOpen: open }),
  activeFolder: null,
  setActiveFolder: (id) => set({ activeFolder: id }),
  activeTags: [],
  toggleTag: (tag) =>
    set((state) => ({
      activeTags: state.activeTags.includes(tag)
        ? state.activeTags.filter((t) => t !== tag)
        : [...state.activeTags, tag],
    })),
  clearTags: () => set({ activeTags: [] }),
}));
