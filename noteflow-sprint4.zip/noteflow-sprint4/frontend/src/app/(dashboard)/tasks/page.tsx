'use client';

import { useState } from 'react';
import { useTasks } from '@/hooks/useTasks';
import { KanbanBoard } from '@/components/tasks/KanbanBoard';
import { TaskCard } from '@/components/tasks/TaskCard';
import { TaskModal } from '@/components/tasks/TaskModal';
import { CalendarView } from '@/components/calendar/CalendarView';
import { RoutineManager } from '@/components/tasks/RoutineManager';
import { Task, TaskStatus } from '@/types/task';
import { Plus, LayoutGrid, List, Calendar, Clock } from 'lucide-react';
import { cn } from '@/lib/utils';
import { format } from 'date-fns';

type ViewMode = 'kanban' | 'list' | 'calendar';

const VIEW_TABS: { id: ViewMode; icon: React.ReactNode; label: string }[] = [
  { id: 'kanban',   icon: <LayoutGrid size={14} />, label: 'Board'    },
  { id: 'list',     icon: <List size={14} />,       label: 'List'     },
  { id: 'calendar', icon: <Calendar size={14} />,   label: 'Calendar' },
];

export default function TasksPage() {
  const [view,           setView]           = useState<ViewMode>('kanban');
  const [showModal,      setShowModal]      = useState(false);
  const [editingTask,    setEditingTask]    = useState<Task | null>(null);
  const [defaultStatus,  setDefaultStatus]  = useState<TaskStatus>('TODO');
  const [filterStatus,   setFilterStatus]   = useState('');
  const [showRoutines,   setShowRoutines]   = useState(false);

  const { tasks, total, isLoading } = useTasks({ status: filterStatus || undefined });

  const openCreate = (status: TaskStatus = 'TODO') => {
    setEditingTask(null);
    setDefaultStatus(status);
    setShowModal(true);
  };

  const openEdit = (task: Task) => {
    setEditingTask(task);
    setShowModal(true);
  };

  const handleCalendarDate = (dateStr: string) => {
    setEditingTask(null);
    setShowModal(true);
  };

  const todayTasks   = tasks.filter(t => t.dueDate && format(new Date(t.dueDate), 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd'));
  const overdueTasks = tasks.filter(t => t.dueDate && new Date(t.dueDate) < new Date() && t.status !== 'DONE');

  return (
    <div className="max-w-7xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[var(--color-foreground)]">Tasks</h1>
          <p className="text-sm text-[var(--color-muted-foreground)] mt-0.5">
            {total} tasks
            {overdueTasks.length > 0 && (
              <span className="ml-2 text-red-500 font-medium">· {overdueTasks.length} overdue</span>
            )}
            {todayTasks.length > 0 && (
              <span className="ml-2 text-amber-500 font-medium">· {todayTasks.length} due today</span>
            )}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowRoutines(v => !v)}
            className={cn(
              'flex items-center gap-1.5 px-3 py-2 rounded-lg border text-sm transition-colors',
              showRoutines
                ? 'border-[var(--color-primary)] bg-[var(--color-primary)]/10 text-[var(--color-primary)]'
                : 'border-[var(--color-border)] text-[var(--color-muted-foreground)] hover:border-[var(--color-primary)]/40'
            )}
          >
            <Clock size={14} />
            Routines
          </button>
          <button
            onClick={() => openCreate()}
            className="flex items-center gap-2 px-4 py-2 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
          >
            <Plus size={15} />
            New Task
          </button>
        </div>
      </div>

      <div className="flex gap-5">
        {/* Main content */}
        <div className="flex-1 min-w-0 space-y-4">
          {/* View toggle + filter */}
          <div className="flex items-center gap-3">
            <div className="flex items-center border border-[var(--color-border)] rounded-xl overflow-hidden">
              {VIEW_TABS.map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setView(tab.id)}
                  className={cn(
                    'flex items-center gap-1.5 px-3 py-2 text-xs font-medium transition-colors',
                    view === tab.id
                      ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)]'
                      : 'text-[var(--color-muted-foreground)] hover:bg-[var(--color-muted)]'
                  )}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>

            {/* Status filter (list view only) */}
            {view === 'list' && (
              <select
                value={filterStatus}
                onChange={e => setFilterStatus(e.target.value)}
                className="px-3 py-2 text-xs rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)]"
              >
                <option value="">All statuses</option>
                <option value="TODO">To Do</option>
                <option value="IN_PROGRESS">In Progress</option>
                <option value="DONE">Done</option>
              </select>
            )}
          </div>

          {/* Views */}
          {isLoading ? (
            <div className="grid grid-cols-3 gap-4">
              {[...Array(6)].map((_, i) => <div key={i} className="h-28 rounded-xl bg-[var(--color-muted)] animate-pulse" />)}
            </div>
          ) : view === 'kanban' ? (
            <KanbanBoard tasks={tasks} onCreateTask={openCreate} onEditTask={openEdit} />
          ) : view === 'list' ? (
            <div className="space-y-2">
              {tasks.length === 0
                ? <div className="flex flex-col items-center justify-center py-20 text-center">
                    <p className="text-[var(--color-muted-foreground)] text-sm">No tasks yet</p>
                    <button onClick={() => openCreate()} className="mt-4 flex items-center gap-2 px-4 py-2 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg text-sm hover:opacity-90">
                      <Plus size={14} /> Create Task
                    </button>
                  </div>
                : tasks.map(task => <TaskCard key={task.id} task={task} onEdit={openEdit} />)
              }
            </div>
          ) : (
            <CalendarView onTaskClick={openEdit} onDateClick={handleCalendarDate} />
          )}
        </div>

        {/* Routines sidebar */}
        {showRoutines && (
          <div className="w-72 flex-shrink-0">
            <div className="sticky top-4 p-4 rounded-2xl border border-[var(--color-border)] bg-[var(--color-card)]">
              <RoutineManager />
            </div>
          </div>
        )}
      </div>

      {/* Task modal */}
      {showModal && (
        <TaskModal
          task={editingTask}
          defaultStatus={defaultStatus}
          onClose={() => { setShowModal(false); setEditingTask(null); }}
        />
      )}
    </div>
  );
}
