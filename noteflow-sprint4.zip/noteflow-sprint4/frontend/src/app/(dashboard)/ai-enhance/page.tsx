'use client';

import { useState, useCallback, useEffect } from 'react';
import { useSearchParams, useRouter } from 'next/navigation';
import { useNotes, useNote, useUpdateNote } from '@/hooks/useNotes';
import { useAiRefactor } from '@/hooks/useAiRefactor';
import { ProviderSelector } from '@/components/ai/ProviderSelector';
import { RefactorOptionsPanel } from '@/components/ai/RefactorOptionsPanel';
import { StreamProgress } from '@/components/ai/StreamProgress';
import { ResultPanel } from '@/components/ai/ResultPanel';
import { JobHistory } from '@/components/ai/JobHistory';
import { AiJob, AiProvider, RefactorOptions } from '@/lib/aiApi';
import { Sparkles, ChevronDown, History, RotateCcw, Play } from 'lucide-react';
import { cn } from '@/lib/utils';

const DEFAULT_OPTIONS: RefactorOptions = {
  refactor: true,
  keyPoints: true,
  questions: true,
  suggestions: false,
};

export default function AIEnhancePage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const paramNoteId = searchParams.get('noteId');

  const [selectedNoteId, setSelectedNoteId] = useState<string>(paramNoteId ?? '');
  const [provider, setProvider] = useState<AiProvider>('GEMINI');
  const [options, setOptions] = useState<RefactorOptions>(DEFAULT_OPTIONS);
  const [showHistory, setShowHistory] = useState(false);
  const [selectedJob, setSelectedJob] = useState<AiJob | null>(null);

  const { notes } = useNotes({ limit: 100 });
  const { note } = useNote(selectedNoteId);
  const { updateNote } = useUpdateNote();
  const { status, rawBuffer, result, error, tokenCount, start, reset } = useAiRefactor();

  // Sync URL param
  useEffect(() => {
    if (paramNoteId) setSelectedNoteId(paramNoteId);
  }, [paramNoteId]);

  const handleRun = () => {
    if (!selectedNoteId) return;
    setSelectedJob(null);
    setShowHistory(false);
    start(selectedNoteId, provider, options);
  };

  const handleApplyToNote = useCallback(
    async (content: string) => {
      if (!selectedNoteId) return;
      await updateNote({ id: selectedNoteId, contentText: content });
    },
    [selectedNoteId, updateNote]
  );

  const handleJobSelect = (job: AiJob) => {
    setSelectedJob(job);
    reset();
  };

  const isStreaming = status === 'streaming';
  const showResult = status === 'done' && result;
  const showJobResult = selectedJob?.result && !showResult;

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex gap-6">
        {/* ── Left panel: controls ───────────────────────────── */}
        <div className="w-80 flex-shrink-0 space-y-5">
          {/* Header */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center">
              <Sparkles size={18} className="text-white" />
            </div>
            <div>
              <h1 className="text-lg font-semibold text-[var(--color-foreground)]">AI Enhance</h1>
              <p className="text-xs text-[var(--color-muted-foreground)]">Powered by Gemini 3.5 Flash & GPT-4.1 Mini</p>
            </div>
          </div>

          {/* Note picker */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">
              Select Note
            </label>
            <div className="relative">
              <select
                value={selectedNoteId}
                onChange={(e) => { setSelectedNoteId(e.target.value); reset(); }}
                disabled={isStreaming}
                className="w-full px-3 py-2 pr-8 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] appearance-none"
              >
                <option value="">— Choose a note —</option>
                {notes.map((n) => (
                  <option key={n.id} value={n.id}>{n.title || 'Untitled'}</option>
                ))}
              </select>
              <ChevronDown size={14} className="absolute right-2.5 top-1/2 -translate-y-1/2 text-[var(--color-muted-foreground)] pointer-events-none" />
            </div>
            {note && (
              <p className="text-xs text-[var(--color-muted-foreground)] mt-1.5 line-clamp-2 pl-1">
                {note.contentText?.slice(0, 100) ?? 'No content'}
              </p>
            )}
          </div>

          {/* Provider */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">
              AI Provider
            </label>
            <ProviderSelector value={provider} onChange={setProvider} disabled={isStreaming} />
          </div>

          {/* Options */}
          <div>
            <label className="text-xs font-medium text-[var(--color-muted-foreground)] uppercase tracking-wider mb-1.5 block">
              Analysis Modes
            </label>
            <RefactorOptionsPanel options={options} onChange={setOptions} disabled={isStreaming} />
          </div>

          {/* Run button */}
          <button
            onClick={handleRun}
            disabled={!selectedNoteId || isStreaming}
            className={cn(
              'w-full flex items-center justify-center gap-2 py-3 rounded-xl font-semibold text-sm transition-all',
              selectedNoteId && !isStreaming
                ? 'bg-gradient-to-r from-violet-600 to-purple-600 text-white hover:opacity-90 shadow-lg shadow-violet-500/20'
                : 'bg-[var(--color-muted)] text-[var(--color-muted-foreground)] cursor-not-allowed'
            )}
          >
            {isStreaming ? (
              <>
                <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Generating…
              </>
            ) : (
              <>
                <Play size={15} />
                Run AI Enhance
              </>
            )}
          </button>

          {status !== 'idle' && (
            <button
              onClick={reset}
              disabled={isStreaming}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-xl text-sm text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] border border-[var(--color-border)] hover:border-[var(--color-primary)]/40 transition-all"
            >
              <RotateCcw size={13} /> Reset
            </button>
          )}

          {/* History toggle */}
          <div>
            <button
              onClick={() => setShowHistory((v) => !v)}
              className="flex items-center gap-1.5 text-xs text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors"
            >
              <History size={12} />
              {showHistory ? 'Hide' : 'Show'} job history
            </button>
            {showHistory && (
              <div className="mt-2">
                <JobHistory
                  noteId={selectedNoteId || undefined}
                  onSelect={handleJobSelect}
                  selectedJobId={selectedJob?.id}
                />
              </div>
            )}
          </div>
        </div>

        {/* ── Right panel: results ───────────────────────────── */}
        <div className="flex-1 min-w-0 space-y-4">
          {/* Stream progress bar */}
          <StreamProgress
            status={status}
            charCount={rawBuffer.length}
            tokenCount={tokenCount}
            providerModel={result?.providerModel}
          />

          {/* Error */}
          {error && (
            <div className="p-4 rounded-xl border border-[var(--color-destructive)]/30 bg-[var(--color-destructive)]/5 text-sm text-[var(--color-destructive)]">
              <strong>Error:</strong> {error}
            </div>
          )}

          {/* Streaming raw buffer (live preview) */}
          {isStreaming && rawBuffer && (
            <div className="p-4 rounded-xl border border-[var(--color-border)] bg-[var(--color-muted)]/30">
              <p className="text-xs font-mono text-[var(--color-muted-foreground)] whitespace-pre-wrap break-all leading-relaxed">
                {rawBuffer}
                <span className="inline-block w-2 h-4 bg-[var(--color-primary)] ml-0.5 animate-pulse" />
              </p>
            </div>
          )}

          {/* Done result */}
          {showResult && (
            <ResultPanel
              result={result}
              onApply={selectedNoteId ? handleApplyToNote : undefined}
            />
          )}

          {/* Historical job result */}
          {showJobResult && (
            <div>
              <p className="text-xs text-[var(--color-muted-foreground)] mb-3">
                Showing result from {new Date(selectedJob!.createdAt).toLocaleString()} · {selectedJob!.providerModel}
              </p>
              <ResultPanel result={selectedJob!.result!} />
            </div>
          )}

          {/* Empty state */}
          {status === 'idle' && !selectedJob && (
            <div className="flex flex-col items-center justify-center py-24 text-center">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-violet-100 to-purple-100 dark:from-violet-950/40 dark:to-purple-950/40 flex items-center justify-center mb-4">
                <Sparkles size={28} className="text-violet-500" />
              </div>
              <h2 className="text-lg font-semibold text-[var(--color-foreground)] mb-2">
                AI Enhance your notes
              </h2>
              <p className="text-sm text-[var(--color-muted-foreground)] max-w-sm">
                Select a note, choose a provider, pick your analysis modes, then click Run.
                Results stream in real time.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
