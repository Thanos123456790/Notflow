'use client';

import { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { useNote, useUpdateNote, useDeleteNote } from '@/hooks/useNotes';
import { RichEditor } from '@/components/editor/RichEditor';
import { FileDropzone } from '@/components/upload/FileDropzone';
import { AttachmentList } from '@/components/upload/AttachmentList';
import { TagInput } from '@/components/tags/TagInput';
import { ArrowLeft, Trash2, Pin, Sparkles, Clock, PinOff, ChevronDown, ChevronUp } from 'lucide-react';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';
import { NoteAttachment } from '@/types/note';
import { cn } from '@/lib/utils';

export default function NoteDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const { note, isLoading } = useNote(id);
  const { updateNote, isUpdating } = useUpdateNote();
  const { deleteNote } = useDeleteNote();

  const [title, setTitle] = useState('');
  const [tags, setTags] = useState<string[]>([]);
  const [attachments, setAttachments] = useState<NoteAttachment[]>([]);
  const [isDirty, setIsDirty] = useState(false);
  const [showMeta, setShowMeta] = useState(false);
  const saveTimer = useRef<ReturnType<typeof setTimeout>>();
  const pendingContent = useRef<{ json: Record<string, unknown>; text: string } | null>(null);

  useEffect(() => {
    if (note) {
      setTitle(note.title || '');
      setTags(note.tags ?? []);
      setAttachments(note.attachments ?? []);
    }
  }, [note]);

  const scheduleSave = useCallback(
    (overrides?: { title?: string; tags?: string[]; content?: Record<string, unknown>; contentText?: string }) => {
      setIsDirty(true);
      clearTimeout(saveTimer.current);
      saveTimer.current = setTimeout(async () => {
        await updateNote({
          id,
          title: overrides?.title ?? title,
          tags: overrides?.tags ?? tags,
          content: overrides?.content ?? pendingContent.current?.json,
          contentText: overrides?.contentText ?? pendingContent.current?.text,
        });
        setIsDirty(false);
      }, 1500);
    },
    [id, title, tags, updateNote]
  );

  const handleTitleChange = (val: string) => {
    setTitle(val);
    scheduleSave({ title: val });
  };

  const handleTagsChange = (newTags: string[]) => {
    setTags(newTags);
    scheduleSave({ tags: newTags });
  };

  const handleEditorUpdate = useCallback(
    (content: Record<string, unknown>, text: string) => {
      pendingContent.current = { json: content, text };
      scheduleSave({ content, contentText: text });
    },
    [scheduleSave]
  );

  const handleDelete = async () => {
    if (confirm('Delete this note?')) {
      await deleteNote(id);
      router.push('/notes');
    }
  };

  const handleTogglePin = () => {
    updateNote({ id, isPinned: !(note?.isPinned) });
  };

  if (isLoading) {
    return (
      <div className="max-w-3xl mx-auto space-y-4 animate-pulse">
        <div className="h-8 bg-[var(--color-muted)] rounded w-48" />
        <div className="h-12 bg-[var(--color-muted)] rounded" />
        <div className="h-96 bg-[var(--color-muted)] rounded" />
      </div>
    );
  }

  if (!note) {
    return (
      <div className="text-center py-20">
        <p className="text-[var(--color-muted-foreground)]">Note not found.</p>
        <Link href="/notes">
          <button className="mt-4 text-sm text-[var(--color-primary)] hover:underline">Back to Notes</button>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto">
      {/* Top toolbar */}
      <div className="flex items-center justify-between mb-5">
        <Link href="/notes">
          <button className="flex items-center gap-1.5 text-sm text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors">
            <ArrowLeft size={15} />
            Notes
          </button>
        </Link>
        <div className="flex items-center gap-2">
          <span className="text-xs text-[var(--color-muted-foreground)] flex items-center gap-1">
            <Clock size={11} />
            {isDirty ? 'Saving…' : `Saved ${formatDistanceToNow(new Date(note.updatedAt), { addSuffix: true })}`}
          </span>
          <Link href={`/ai-enhance?noteId=${id}`}>
            <button className="flex items-center gap-1.5 px-3 py-1.5 text-xs border border-[var(--color-border)] rounded-lg hover:bg-[var(--color-muted)] transition-colors">
              <Sparkles size={13} className="text-violet-500" />
              AI Enhance
            </button>
          </Link>
          <button
            onClick={handleTogglePin}
            className={cn('p-1.5 rounded-lg border border-[var(--color-border)] hover:bg-[var(--color-muted)] transition-colors', note.isPinned && 'text-amber-500 border-amber-200')}
            title={note.isPinned ? 'Unpin' : 'Pin'}
          >
            {note.isPinned ? <PinOff size={14} /> : <Pin size={14} />}
          </button>
          <button
            onClick={handleDelete}
            className="p-1.5 rounded-lg border border-[var(--color-border)] hover:bg-[var(--color-destructive)]/10 hover:text-[var(--color-destructive)] hover:border-[var(--color-destructive)]/30 transition-colors text-[var(--color-muted-foreground)]"
          >
            <Trash2 size={14} />
          </button>
        </div>
      </div>

      {/* Title */}
      <input
        type="text"
        value={title}
        onChange={(e) => handleTitleChange(e.target.value)}
        placeholder="Untitled Note"
        className="w-full text-3xl font-bold text-[var(--color-foreground)] bg-transparent border-none outline-none placeholder:text-[var(--color-muted-foreground)]/40 mb-3"
      />

      {/* Collapsible meta: tags, attachments */}
      <div className="mb-4">
        <button
          onClick={() => setShowMeta((v) => !v)}
          className="flex items-center gap-1.5 text-xs text-[var(--color-muted-foreground)] hover:text-[var(--color-foreground)] transition-colors mb-2"
        >
          {showMeta ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          <span>
            {note.tags && note.tags.length > 0 ? note.tags.map(t => `#${t}`).join(' ') : 'Tags & attachments'}
          </span>
        </button>

        {showMeta && (
          <div className="space-y-3 p-3 rounded-xl border border-[var(--color-border)] bg-[var(--color-muted)]/30 mb-3">
            <div>
              <label className="text-xs font-medium text-[var(--color-muted-foreground)] mb-1.5 block">Tags</label>
              <TagInput tags={tags} onChange={handleTagsChange} />
            </div>
            <div>
              <label className="text-xs font-medium text-[var(--color-muted-foreground)] mb-1.5 block">Attachments</label>
              <AttachmentList attachments={attachments} />
              <div className="mt-2">
                <FileDropzone
                  noteId={id}
                  onUploaded={(a) => setAttachments((prev) => [...prev, a])}
                />
              </div>
            </div>
          </div>
        )}
      </div>

      <div className="border-t border-[var(--color-border)] pt-4">
        <RichEditor
          noteId={id}
          initialContent={note.content as Record<string, unknown> | null}
          initialText={note.contentText}
          onUpdate={handleEditorUpdate}
        />
      </div>
    </div>
  );
}
