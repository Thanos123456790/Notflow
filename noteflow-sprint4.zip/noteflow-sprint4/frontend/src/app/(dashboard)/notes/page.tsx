'use client';

import { useState } from 'react';
import { useNotes } from '@/hooks/useNotes';
import { useNoteStore } from '@/store/noteStore';
import { NoteCard } from '@/components/notes/NoteCard';
import { NoteCreateModal } from '@/components/notes/NoteCreateModal';
import { Plus, Search, Filter, FileText, Grid, List, SlidersHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';

export default function NotesPage() {
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const { activeFolder, activeTags } = useNoteStore();
  const { notes, isLoading, total } = useNotes({
    search,
    folderId: activeFolder ?? undefined,
    tags: activeTags.length > 0 ? activeTags : undefined,
  });

  return (
    <div className="max-w-6xl mx-auto space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-[var(--color-foreground)]">Notes</h1>
          <p className="text-sm text-[var(--color-muted-foreground)] mt-0.5">
            {total} {total === 1 ? 'note' : 'notes'}
            {activeFolder && ' in folder'}
            {activeTags.length > 0 && ` tagged ${activeTags.map(t => '#' + t).join(', ')}`}
          </p>
        </div>
        <button
          onClick={() => setShowCreateModal(true)}
          className="flex items-center gap-2 px-4 py-2 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
        >
          <Plus size={15} />
          New Note
        </button>
      </div>

      {/* Toolbar */}
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-md">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--color-muted-foreground)]" />
          <input
            placeholder="Search notes..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-sm rounded-lg border border-[var(--color-border)] bg-[var(--color-background)] text-[var(--color-foreground)] placeholder:text-[var(--color-muted-foreground)] focus:outline-none focus:ring-2 focus:ring-[var(--color-ring)] focus:ring-offset-2"
          />
        </div>

        {/* Active tag filters */}
        {activeTags.length > 0 && (
          <div className="flex gap-1.5">
            {activeTags.map(tag => (
              <span key={tag} className="text-xs bg-[var(--color-primary)]/10 text-[var(--color-primary)] px-2 py-1 rounded-full">
                #{tag}
              </span>
            ))}
          </div>
        )}

        {/* View toggle */}
        <div className="flex items-center border border-[var(--color-border)] rounded-lg overflow-hidden ml-auto">
          <button
            onClick={() => setViewMode('grid')}
            className={cn('p-2 transition-colors', viewMode === 'grid' ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)]' : 'hover:bg-[var(--color-muted)] text-[var(--color-muted-foreground)]')}
          >
            <Grid size={14} />
          </button>
          <button
            onClick={() => setViewMode('list')}
            className={cn('p-2 transition-colors', viewMode === 'list' ? 'bg-[var(--color-primary)] text-[var(--color-primary-foreground)]' : 'hover:bg-[var(--color-muted)] text-[var(--color-muted-foreground)]')}
          >
            <List size={14} />
          </button>
        </div>
      </div>

      {/* Notes Grid / List */}
      {isLoading ? (
        <div className={cn('grid gap-4', viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1')}>
          {[...Array(9)].map((_, i) => (
            <div key={i} className="h-36 rounded-xl bg-[var(--color-muted)] animate-pulse" />
          ))}
        </div>
      ) : notes.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-24 text-center">
          <FileText size={48} className="text-[var(--color-muted-foreground)]/30 mb-4" />
          <h3 className="text-lg font-medium text-[var(--color-foreground)] mb-1">
            {search ? 'No notes found' : 'No notes yet'}
          </h3>
          <p className="text-sm text-[var(--color-muted-foreground)] mb-6">
            {search ? 'Try a different search term' : 'Create your first note to get started'}
          </p>
          {!search && (
            <button
              onClick={() => setShowCreateModal(true)}
              className="flex items-center gap-2 px-4 py-2 bg-[var(--color-primary)] text-[var(--color-primary-foreground)] rounded-lg text-sm font-medium hover:opacity-90 transition-opacity"
            >
              <Plus size={15} />
              Create Note
            </button>
          )}
        </div>
      ) : (
        <div className={cn('grid gap-4', viewMode === 'grid' ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3' : 'grid-cols-1')}>
          {notes.map((note) => (
            <NoteCard key={note.id} note={note} viewMode={viewMode} />
          ))}
        </div>
      )}

      {showCreateModal && <NoteCreateModal onClose={() => setShowCreateModal(false)} />}
    </div>
  );
}
