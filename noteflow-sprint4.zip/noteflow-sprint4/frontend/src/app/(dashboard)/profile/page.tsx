'use client';

import { useUser } from '@clerk/nextjs';
import { User } from 'lucide-react';

export default function ProfilePage() {
  const { user } = useUser();

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-2xl font-semibold text-foreground">Profile</h1>
      <div className="flex items-center gap-4 p-6 rounded-xl border border-border bg-card">
        {user?.imageUrl ? (
          <img src={user.imageUrl} alt="Avatar" className="w-16 h-16 rounded-full" />
        ) : (
          <div className="w-16 h-16 rounded-full bg-muted flex items-center justify-center">
            <User className="w-8 h-8 text-muted-foreground" />
          </div>
        )}
        <div>
          <p className="text-lg font-semibold text-foreground">{user?.fullName || 'Anonymous'}</p>
          <p className="text-sm text-muted-foreground">{user?.primaryEmailAddress?.emailAddress}</p>
        </div>
      </div>
      <p className="text-sm text-muted-foreground text-center">
        Activity heatmap, streaks, and settings — coming in Sprint 6.
      </p>
    </div>
  );
}
