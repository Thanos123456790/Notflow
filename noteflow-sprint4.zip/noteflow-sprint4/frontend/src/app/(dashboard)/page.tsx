'use client';

import { useUser } from '@clerk/nextjs';
import { useNotes } from '@/hooks/useNotes';
import { NoteCard } from '@/components/notes/NoteCard';
import { Button } from '@/components/ui/button';
import { Plus, FileText, Sparkles, Calendar, Mic } from 'lucide-react';
import Link from 'next/link';
import { formatDistanceToNow } from 'date-fns';

const QUICK_ACTIONS = [
  { icon: FileText, label: 'New Note', href: '/notes', color: 'text-violet-600 bg-violet-50 dark:bg-violet-950/30' },
  { icon: Sparkles, label: 'AI Enhance', href: '/ai-enhance', color: 'text-amber-600 bg-amber-50 dark:bg-amber-950/30' },
  { icon: Calendar, label: 'Tasks', href: '/tasks', color: 'text-blue-600 bg-blue-50 dark:bg-blue-950/30' },
  { icon: Mic, label: 'Interview', href: '/interview', color: 'text-emerald-600 bg-emerald-50 dark:bg-emerald-950/30' },
];

export default function DashboardPage() {
  const { user } = useUser();
  const { notes, isLoading } = useNotes({ limit: 6 });

  const firstName = user?.firstName || 'there';
  const hour = new Date().getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 17 ? 'Good afternoon' : 'Good evening';

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-semibold text-foreground">
          {greeting}, {firstName} 👋
        </h1>
        <p className="text-sm text-muted-foreground mt-1">
          Here&apos;s what&apos;s happening with your workspace today.
        </p>
      </div>

      {/* Quick Actions */}
      <div>
        <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider mb-3">
          Quick Actions
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {QUICK_ACTIONS.map(({ icon: Icon, label, href, color }) => (
            <Link key={href} href={href}>
              <div className="flex flex-col items-center gap-2 p-4 rounded-xl border border-border hover:border-primary/40 hover:shadow-sm transition-all cursor-pointer group bg-card">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-sm font-medium text-foreground">{label}</span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      {/* Recent Notes */}
      <div>
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
            Recent Notes
          </h2>
          <Link href="/notes">
            <Button variant="ghost" size="sm" className="text-xs">
              View all →
            </Button>
          </Link>
        </div>

        {isLoading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="h-36 rounded-xl bg-muted animate-pulse" />
            ))}
          </div>
        ) : notes.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16 text-center border border-dashed border-border rounded-xl">
            <FileText className="w-10 h-10 text-muted-foreground/40 mb-3" />
            <p className="text-sm font-medium text-foreground">No notes yet</p>
            <p className="text-xs text-muted-foreground mt-1">Create your first note to get started</p>
            <Link href="/notes" className="mt-4">
              <Button size="sm">
                <Plus className="w-4 h-4 mr-1" />
                New Note
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {notes.map((note) => (
              <NoteCard key={note.id} note={note} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
