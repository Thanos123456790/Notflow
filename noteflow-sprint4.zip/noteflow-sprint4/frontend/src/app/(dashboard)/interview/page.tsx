'use client';

import { Mic } from 'lucide-react';

export default function InterviewPage() {
  return (
    <div className="max-w-4xl mx-auto flex flex-col items-center justify-center py-24 text-center">
      <div className="w-16 h-16 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 flex items-center justify-center mb-4">
        <Mic className="w-8 h-8 text-emerald-600" />
      </div>
      <h1 className="text-2xl font-semibold text-foreground mb-2">Interview Prep</h1>
      <p className="text-muted-foreground max-w-sm">
        AI question extraction and voice practice sessions — coming in Sprint 5.
      </p>
    </div>
  );
}
