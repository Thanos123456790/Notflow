import { SignUp } from '@clerk/nextjs';

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-50 via-white to-indigo-50 dark:from-zinc-950 dark:via-zinc-900 dark:to-zinc-950">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 mb-3">
            <div className="w-9 h-9 rounded-xl bg-violet-600 flex items-center justify-center">
              <span className="text-white text-lg font-bold">N</span>
            </div>
            <span className="text-2xl font-bold text-zinc-900 dark:text-white">NoteFlow AI</span>
          </div>
          <p className="text-sm text-zinc-500 dark:text-zinc-400">
            Create your AI-powered productivity workspace
          </p>
        </div>
        <SignUp />
      </div>
    </div>
  );
}
