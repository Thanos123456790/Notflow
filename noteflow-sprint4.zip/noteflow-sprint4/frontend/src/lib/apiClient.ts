import axios from 'axios';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080/api/v1';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

/**
 * Attach this interceptor in a Client Component that has access to Clerk's
 * useAuth hook. Call attachAuthInterceptor(getToken) once on mount.
 */
let authInterceptorId: number | null = null;

export function attachAuthInterceptor(getToken: () => Promise<string | null>) {
  if (authInterceptorId !== null) {
    apiClient.interceptors.request.eject(authInterceptorId);
  }

  authInterceptorId = apiClient.interceptors.request.use(async (config) => {
    const token = await getToken();
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  });
}

// Response interceptor — normalise errors
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const message =
      error?.response?.data?.message ||
      error?.response?.data?.error ||
      error.message ||
      'An unexpected error occurred';
    return Promise.reject(new Error(message));
  }
);
