import { apiClient } from '@/lib/apiClient';

export type AiProvider = 'GEMINI' | 'OPENAI';

export interface RefactorOptions {
  refactor: boolean;
  keyPoints: boolean;
  questions: boolean;
  suggestions: boolean;
}

export interface RefactorResult {
  refactoredContent?: string;
  keyPoints?: string[];
  questions?: string[];
  suggestions?: string[];
  inputTokens?: number;
  outputTokens?: number;
  providerModel?: string;
}

export interface StreamChunk {
  type: 'DELTA' | 'DONE' | 'ERROR';
  field?: string;
  delta?: string;
  error?: string;
}

export interface AiJob {
  id: string;
  noteId: string;
  provider: AiProvider;
  status: 'PENDING' | 'PROCESSING' | 'COMPLETED' | 'FAILED';
  inputTokens?: number;
  outputTokens?: number;
  providerModel?: string;
  errorMessage?: string;
  result?: RefactorResult;
  createdAt: string;
  completedAt?: string;
}

export interface StreamRefactorCallbacks {
  onDelta: (delta: string) => void;
  onDone: (result: RefactorResult) => void;
  onError: (error: string) => void;
}

const API_BASE = process.env.NEXT_PUBLIC_API_BASE_URL ?? 'http://localhost:8080/api/v1';

/**
 * Opens an SSE stream to the backend AI refactor endpoint.
 * Returns a cleanup function that aborts the connection.
 */
export function streamRefactor(
  noteId: string,
  provider: AiProvider,
  options: RefactorOptions,
  callbacks: StreamRefactorCallbacks,
  getToken: () => Promise<string | null>
): () => void {
  const controller = new AbortController();

  (async () => {
    const token = await getToken();
    const response = await fetch(`${API_BASE}/ai/refactor/stream`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({ noteId, provider, options }),
      signal: controller.signal,
    });

    if (!response.ok) {
      callbacks.onError(`HTTP ${response.status}: ${response.statusText}`);
      return;
    }

    const reader = response.body?.getReader();
    if (!reader) { callbacks.onError('No response body'); return; }

    const decoder = new TextDecoder();
    let buffer = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (line.startsWith('event:')) continue;
        if (!line.startsWith('data:')) continue;

        const jsonStr = line.slice(5).trim();
        if (!jsonStr) continue;

        try {
          const parsed = JSON.parse(jsonStr);

          // "done" event — full structured result
          if (parsed.refactoredContent !== undefined || parsed.keyPoints !== undefined) {
            callbacks.onDone(parsed as RefactorResult);
            return;
          }

          const chunk = parsed as StreamChunk;
          if (chunk.type === 'DELTA' && chunk.delta) {
            callbacks.onDelta(chunk.delta);
          } else if (chunk.type === 'ERROR') {
            callbacks.onError(chunk.error ?? 'Unknown error');
            return;
          }
        } catch {
          // Ignore malformed SSE lines
        }
      }
    }
  })().catch((err) => {
    if (err.name !== 'AbortError') {
      callbacks.onError(err.message ?? 'Stream error');
    }
  });

  return () => controller.abort();
}

export const aiApi = {
  listJobs: async (noteId?: string): Promise<AiJob[]> => {
    const params = noteId ? `?noteId=${noteId}` : '';
    const { data } = await apiClient.get<AiJob[]>(`/ai/jobs${params}`);
    return data;
  },
  getJob: async (jobId: string): Promise<AiJob> => {
    const { data } = await apiClient.get<AiJob>(`/ai/jobs/${jobId}`);
    return data;
  },
};
