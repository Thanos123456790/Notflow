import { apiClient } from '@/lib/apiClient';
import {
  Task,
  TasksResponse,
  CreateTaskRequest,
  UpdateTaskRequest,
  Routine,
  CreateRoutineRequest,
} from '@/types/task';

export interface GetTasksParams {
  status?: string;
  page?: number;
  size?: number;
}

export const tasksApi = {
  // ── Tasks ────────────────────────────────────────────────────
  list: async (params: GetTasksParams = {}): Promise<TasksResponse> => {
    const { data } = await apiClient.get<TasksResponse>('/tasks', { params });
    return data;
  },

  calendar: async (from: string, to: string): Promise<Task[]> => {
    const { data } = await apiClient.get<Task[]>('/tasks/calendar', { params: { from, to } });
    return data;
  },

  get: async (id: string): Promise<Task> => {
    const { data } = await apiClient.get<Task>(`/tasks/${id}`);
    return data;
  },

  create: async (payload: CreateTaskRequest): Promise<Task> => {
    const { data } = await apiClient.post<Task>('/tasks', payload);
    return data;
  },

  update: async ({ id, ...payload }: UpdateTaskRequest): Promise<Task> => {
    const { data } = await apiClient.put<Task>(`/tasks/${id}`, payload);
    return data;
  },

  updateStatus: async (id: string, status: string): Promise<Task> => {
    const { data } = await apiClient.patch<Task>(`/tasks/${id}/status`, { status });
    return data;
  },

  delete: async (id: string): Promise<void> => {
    await apiClient.delete(`/tasks/${id}`);
  },

  toggleSubtask: async (taskId: string, subtaskId: string): Promise<Task> => {
    const { data } = await apiClient.post<Task>(`/tasks/${taskId}/subtasks/${subtaskId}/toggle`);
    return data;
  },

  reorder: async (orderedIds: string[]): Promise<void> => {
    await apiClient.post('/tasks/reorder', { orderedIds });
  },

  // ── Routines ─────────────────────────────────────────────────
  listRoutines: async (): Promise<Routine[]> => {
    const { data } = await apiClient.get<Routine[]>('/routines');
    return data;
  },

  createRoutine: async (payload: CreateRoutineRequest): Promise<Routine> => {
    const { data } = await apiClient.post<Routine>('/routines', payload);
    return data;
  },

  updateRoutine: async (id: string, payload: Partial<CreateRoutineRequest> & { active?: boolean }): Promise<Routine> => {
    const { data } = await apiClient.put<Routine>(`/routines/${id}`, payload);
    return data;
  },

  deleteRoutine: async (id: string): Promise<void> => {
    await apiClient.delete(`/routines/${id}`);
  },
};
