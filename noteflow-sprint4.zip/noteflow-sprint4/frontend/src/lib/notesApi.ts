import { apiClient } from '@/lib/apiClient';
import {
  Note,
  NotesResponse,
  CreateNoteRequest,
  UpdateNoteRequest,
  PresignRequest,
  PresignResponse,
} from '@/types/note';

export interface GetNotesParams {
  search?: string;
  tags?: string[];
  folderId?: string;
  isPinned?: boolean;
  isArchived?: boolean;
  page?: number;
  limit?: number;
}

export const notesApi = {
  list: async (params: GetNotesParams = {}): Promise<NotesResponse> => {
    const { tags, ...rest } = params;
    const qp: Record<string, unknown> = { ...rest };
    if (tags && tags.length > 0) qp.tags = tags.join(',');
    const { data } = await apiClient.get<NotesResponse>('/notes', { params: qp });
    return data;
  },

  get: async (id: string): Promise<Note> => {
    const { data } = await apiClient.get<Note>(`/notes/${id}`);
    return data;
  },

  create: async (payload: CreateNoteRequest): Promise<Note> => {
    const { data } = await apiClient.post<Note>('/notes', payload);
    return data;
  },

  update: async ({ id, ...payload }: UpdateNoteRequest): Promise<Note> => {
    const { data } = await apiClient.put<Note>(`/notes/${id}`, payload);
    return data;
  },

  delete: async (id: string): Promise<void> => {
    await apiClient.delete(`/notes/${id}`);
  },

  togglePin: async (id: string): Promise<Note> => {
    const { data } = await apiClient.post<Note>(`/notes/${id}/pin`);
    return data;
  },

  presignAttachment: async (payload: PresignRequest): Promise<PresignResponse> => {
    const { data } = await apiClient.post<PresignResponse>('/notes/attachments/presign', payload);
    return data;
  },

  confirmAttachment: async (attachmentId: string, fileKey: string): Promise<void> => {
    await apiClient.post('/notes/attachments/confirm', { attachmentId, fileKey });
  },

  uploadToS3: async (presignedUrl: string, file: File): Promise<void> => {
    await fetch(presignedUrl, {
      method: 'PUT',
      headers: { 'Content-Type': file.type },
      body: file,
    });
  },
};
